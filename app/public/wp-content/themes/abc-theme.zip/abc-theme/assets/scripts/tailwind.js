"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(self["webpackChunkmicrofrontend"] = self["webpackChunkmicrofrontend"] || []).push([[642],{

/***/ "./src/vendors/tailwindcss/style.scss":
/*!********************************************!*\
  !*** ./src/vendors/tailwindcss/style.scss ***!
  \********************************************/
/***/ (function() {

eval("// extracted by mini-css-extract-plugin\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvdmVuZG9ycy90YWlsd2luZGNzcy9zdHlsZS5zY3NzLmpzIiwibWFwcGluZ3MiOiJBQUFBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbWljcm9mcm9udGVuZC8uL3NyYy92ZW5kb3JzL3RhaWx3aW5kY3NzL3N0eWxlLnNjc3M/YzhkNiJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBleHRyYWN0ZWQgYnkgbWluaS1jc3MtZXh0cmFjdC1wbHVnaW5cbmV4cG9ydCB7fTsiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/vendors/tailwindcss/style.scss\n");

/***/ }),

/***/ "./src/vendors/tailwindcss/index.js":
/*!******************************************!*\
  !*** ./src/vendors/tailwindcss/index.js ***!
  \******************************************/
/***/ (function(__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) {

/* harmony import */ var _style__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./style */ "./src/vendors/tailwindcss/style.scss");


/***/ })

}]);