<?wp_nav_menu( array( 'theme_location' => 'primary_menu', 'container_class' => 'nav_menu_class' ) ); ?>
