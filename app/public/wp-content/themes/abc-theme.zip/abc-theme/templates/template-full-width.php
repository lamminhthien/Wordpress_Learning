<?php
/**
 * Template Name: Full Width Template
 * Template Post Type: post, page
 *
 * @package ABC_WP
 * @subpackage CDE_Theme
 * @since CD Theme 1.0
 */

get_template_part( 'singular' );
