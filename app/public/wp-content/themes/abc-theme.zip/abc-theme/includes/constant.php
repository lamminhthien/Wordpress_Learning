<?php

// Define global constants
if ( !defined( 'POST_PER_PAGE' ) ) {
  define( 'POST_PER_PAGE', 3 );
}
?>
