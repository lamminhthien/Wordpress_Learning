-- MySQL dump 10.13  Distrib 8.0.16, for Win64 (x86_64)
--
-- Host: ::1    Database: local
-- ------------------------------------------------------
-- Server version	8.0.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8mb4 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `wp_commentmeta`
--

DROP TABLE IF EXISTS `wp_commentmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_commentmeta`
--

LOCK TABLES `wp_commentmeta` WRITE;
/*!40000 ALTER TABLE `wp_commentmeta` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_commentmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_comments`
--

DROP TABLE IF EXISTS `wp_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_comments`
--

LOCK TABLES `wp_comments` WRITE;
/*!40000 ALTER TABLE `wp_comments` DISABLE KEYS */;
INSERT INTO `wp_comments` VALUES (1,1,'A WordPress Commenter','wapuu@wordpress.example','https://wordpress.org/','','2022-07-29 15:14:18','2022-07-29 15:14:18','Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://en.gravatar.com/\">Gravatar</a>.',0,'post-trashed','','comment',0,0);
/*!40000 ALTER TABLE `wp_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_db7_forms`
--

DROP TABLE IF EXISTS `wp_db7_forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_db7_forms` (
  `form_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `form_post_id` bigint(20) NOT NULL,
  `form_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `form_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_db7_forms`
--

LOCK TABLES `wp_db7_forms` WRITE;
/*!40000 ALTER TABLE `wp_db7_forms` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_db7_forms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_links`
--

DROP TABLE IF EXISTS `wp_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_links`
--

LOCK TABLES `wp_links` WRITE;
/*!40000 ALTER TABLE `wp_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_options`
--

DROP TABLE IF EXISTS `wp_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=1273 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_options`
--

LOCK TABLES `wp_options` WRITE;
/*!40000 ALTER TABLE `wp_options` DISABLE KEYS */;
INSERT INTO `wp_options` VALUES (1,'siteurl','http://lamminhthien.local','yes');
INSERT INTO `wp_options` VALUES (2,'home','http://lamminhthien.local','yes');
INSERT INTO `wp_options` VALUES (3,'blogname','lamminhthien.com','yes');
INSERT INTO `wp_options` VALUES (4,'blogdescription','Just another WordPress site','yes');
INSERT INTO `wp_options` VALUES (5,'users_can_register','0','yes');
INSERT INTO `wp_options` VALUES (6,'admin_email','phamthilinhlinh2000@gmail.com','yes');
INSERT INTO `wp_options` VALUES (7,'start_of_week','1','yes');
INSERT INTO `wp_options` VALUES (8,'use_balanceTags','0','yes');
INSERT INTO `wp_options` VALUES (9,'use_smilies','1','yes');
INSERT INTO `wp_options` VALUES (10,'require_name_email','1','yes');
INSERT INTO `wp_options` VALUES (11,'comments_notify','1','yes');
INSERT INTO `wp_options` VALUES (12,'posts_per_rss','10','yes');
INSERT INTO `wp_options` VALUES (13,'rss_use_excerpt','0','yes');
INSERT INTO `wp_options` VALUES (14,'mailserver_url','mail.example.com','yes');
INSERT INTO `wp_options` VALUES (15,'mailserver_login','login@example.com','yes');
INSERT INTO `wp_options` VALUES (16,'mailserver_pass','password','yes');
INSERT INTO `wp_options` VALUES (17,'mailserver_port','110','yes');
INSERT INTO `wp_options` VALUES (18,'default_category','1','yes');
INSERT INTO `wp_options` VALUES (19,'default_comment_status','open','yes');
INSERT INTO `wp_options` VALUES (20,'default_ping_status','open','yes');
INSERT INTO `wp_options` VALUES (21,'default_pingback_flag','1','yes');
INSERT INTO `wp_options` VALUES (22,'posts_per_page','10','yes');
INSERT INTO `wp_options` VALUES (23,'date_format','F j, Y','yes');
INSERT INTO `wp_options` VALUES (24,'time_format','g:i a','yes');
INSERT INTO `wp_options` VALUES (25,'links_updated_date_format','F j, Y g:i a','yes');
INSERT INTO `wp_options` VALUES (26,'comment_moderation','0','yes');
INSERT INTO `wp_options` VALUES (27,'moderation_notify','1','yes');
INSERT INTO `wp_options` VALUES (28,'permalink_structure','/%postname%/','yes');
INSERT INTO `wp_options` VALUES (29,'rewrite_rules','a:94:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:17:\"^wp-sitemap\\.xml$\";s:23:\"index.php?sitemap=index\";s:17:\"^wp-sitemap\\.xsl$\";s:36:\"index.php?sitemap-stylesheet=sitemap\";s:23:\"^wp-sitemap-index\\.xsl$\";s:34:\"index.php?sitemap-stylesheet=index\";s:48:\"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$\";s:75:\"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]\";s:34:\"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$\";s:47:\"index.php?sitemap=$matches[1]&paged=$matches[2]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:13:\"favicon\\.ico$\";s:19:\"index.php?favicon=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:39:\"index.php?&page_id=28&cpage=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}','yes');
INSERT INTO `wp_options` VALUES (30,'hack_file','0','yes');
INSERT INTO `wp_options` VALUES (31,'blog_charset','UTF-8','yes');
INSERT INTO `wp_options` VALUES (32,'moderation_keys','','no');
INSERT INTO `wp_options` VALUES (33,'active_plugins','a:5:{i:0;s:61:\"acf-field-for-contact-form-7/acf-field-for-contact-form-7.php\";i:1;s:34:\"advanced-custom-fields-pro/acf.php\";i:2;s:36:\"contact-form-7/wp-contact-form-7.php\";i:3;s:42:\"contact-form-cfdb7/contact-form-cfdb-7.php\";i:4;s:27:\"svg-support/svg-support.php\";}','yes');
INSERT INTO `wp_options` VALUES (34,'category_base','','yes');
INSERT INTO `wp_options` VALUES (35,'ping_sites','http://rpc.pingomatic.com/','yes');
INSERT INTO `wp_options` VALUES (36,'comment_max_links','2','yes');
INSERT INTO `wp_options` VALUES (37,'gmt_offset','7','yes');
INSERT INTO `wp_options` VALUES (38,'default_email_category','1','yes');
INSERT INTO `wp_options` VALUES (39,'recently_edited','a:2:{i:0;s:107:\"C:\\Users\\DELL\\Local Sites\\phamthiutlinhcom\\app\\public/wp-content/plugins/advanced-custom-fields-pro/acf.php\";i:1;s:0:\"\";}','no');
INSERT INTO `wp_options` VALUES (40,'template','abc-demo','yes');
INSERT INTO `wp_options` VALUES (41,'stylesheet','abc-demo','yes');
INSERT INTO `wp_options` VALUES (42,'comment_registration','0','yes');
INSERT INTO `wp_options` VALUES (43,'html_type','text/html','yes');
INSERT INTO `wp_options` VALUES (44,'use_trackback','0','yes');
INSERT INTO `wp_options` VALUES (45,'default_role','subscriber','yes');
INSERT INTO `wp_options` VALUES (46,'db_version','53496','yes');
INSERT INTO `wp_options` VALUES (47,'uploads_use_yearmonth_folders','1','yes');
INSERT INTO `wp_options` VALUES (48,'upload_path','','yes');
INSERT INTO `wp_options` VALUES (49,'blog_public','1','yes');
INSERT INTO `wp_options` VALUES (50,'default_link_category','2','yes');
INSERT INTO `wp_options` VALUES (51,'show_on_front','page','yes');
INSERT INTO `wp_options` VALUES (52,'tag_base','','yes');
INSERT INTO `wp_options` VALUES (53,'show_avatars','1','yes');
INSERT INTO `wp_options` VALUES (54,'avatar_rating','G','yes');
INSERT INTO `wp_options` VALUES (55,'upload_url_path','','yes');
INSERT INTO `wp_options` VALUES (56,'thumbnail_size_w','150','yes');
INSERT INTO `wp_options` VALUES (57,'thumbnail_size_h','150','yes');
INSERT INTO `wp_options` VALUES (58,'thumbnail_crop','1','yes');
INSERT INTO `wp_options` VALUES (59,'medium_size_w','300','yes');
INSERT INTO `wp_options` VALUES (60,'medium_size_h','300','yes');
INSERT INTO `wp_options` VALUES (61,'avatar_default','mystery','yes');
INSERT INTO `wp_options` VALUES (62,'large_size_w','1024','yes');
INSERT INTO `wp_options` VALUES (63,'large_size_h','1024','yes');
INSERT INTO `wp_options` VALUES (64,'image_default_link_type','none','yes');
INSERT INTO `wp_options` VALUES (65,'image_default_size','','yes');
INSERT INTO `wp_options` VALUES (66,'image_default_align','','yes');
INSERT INTO `wp_options` VALUES (67,'close_comments_for_old_posts','0','yes');
INSERT INTO `wp_options` VALUES (68,'close_comments_days_old','14','yes');
INSERT INTO `wp_options` VALUES (69,'thread_comments','1','yes');
INSERT INTO `wp_options` VALUES (70,'thread_comments_depth','5','yes');
INSERT INTO `wp_options` VALUES (71,'page_comments','0','yes');
INSERT INTO `wp_options` VALUES (72,'comments_per_page','50','yes');
INSERT INTO `wp_options` VALUES (73,'default_comments_page','newest','yes');
INSERT INTO `wp_options` VALUES (74,'comment_order','asc','yes');
INSERT INTO `wp_options` VALUES (75,'sticky_posts','a:0:{}','yes');
INSERT INTO `wp_options` VALUES (76,'widget_categories','a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (77,'widget_text','a:3:{i:2;a:4:{s:5:\"title\";s:15:\"About This Site\";s:4:\"text\";s:85:\"This may be a good place to introduce yourself and your site or include some credits.\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}i:3;a:4:{s:5:\"title\";s:7:\"Find Us\";s:4:\"text\";s:168:\"<strong>Address</strong>\n123 Main Street\nNew York, NY 10001\n\n<strong>Hours</strong>\nMonday&ndash;Friday: 9:00AM&ndash;5:00PM\nSaturday &amp; Sunday: 11:00AM&ndash;3:00PM\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (78,'widget_rss','a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (79,'uninstall_plugins','a:0:{}','no');
INSERT INTO `wp_options` VALUES (80,'timezone_string','','yes');
INSERT INTO `wp_options` VALUES (81,'page_for_posts','0','yes');
INSERT INTO `wp_options` VALUES (82,'page_on_front','28','yes');
INSERT INTO `wp_options` VALUES (83,'default_post_format','0','yes');
INSERT INTO `wp_options` VALUES (84,'link_manager_enabled','0','yes');
INSERT INTO `wp_options` VALUES (85,'finished_splitting_shared_terms','1','yes');
INSERT INTO `wp_options` VALUES (86,'site_icon','0','yes');
INSERT INTO `wp_options` VALUES (87,'medium_large_size_w','768','yes');
INSERT INTO `wp_options` VALUES (88,'medium_large_size_h','0','yes');
INSERT INTO `wp_options` VALUES (89,'wp_page_for_privacy_policy','3','yes');
INSERT INTO `wp_options` VALUES (90,'show_comments_cookies_opt_in','1','yes');
INSERT INTO `wp_options` VALUES (91,'admin_email_lifespan','1674659657','yes');
INSERT INTO `wp_options` VALUES (92,'disallowed_keys','','no');
INSERT INTO `wp_options` VALUES (93,'comment_previously_approved','1','yes');
INSERT INTO `wp_options` VALUES (94,'auto_plugin_theme_update_emails','a:0:{}','no');
INSERT INTO `wp_options` VALUES (95,'auto_update_core_dev','enabled','yes');
INSERT INTO `wp_options` VALUES (96,'auto_update_core_minor','enabled','yes');
INSERT INTO `wp_options` VALUES (97,'auto_update_core_major','enabled','yes');
INSERT INTO `wp_options` VALUES (98,'wp_force_deactivated_plugins','a:0:{}','yes');
INSERT INTO `wp_options` VALUES (99,'initial_db_version','53496','yes');
INSERT INTO `wp_options` VALUES (100,'wp_user_roles','a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:62:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:12:\"cfdb7_access\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}','yes');
INSERT INTO `wp_options` VALUES (101,'fresh_site','0','yes');
INSERT INTO `wp_options` VALUES (102,'user_count','1','no');
INSERT INTO `wp_options` VALUES (103,'widget_block','a:6:{i:2;a:1:{s:7:\"content\";s:19:\"<!-- wp:search /-->\";}i:3;a:1:{s:7:\"content\";s:154:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Recent Posts</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->\";}i:4;a:1:{s:7:\"content\";s:227:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Recent Comments</h2><!-- /wp:heading --><!-- wp:latest-comments {\"displayAvatar\":false,\"displayDate\":false,\"displayExcerpt\":false} /--></div><!-- /wp:group -->\";}i:5;a:1:{s:7:\"content\";s:146:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Archives</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->\";}i:6;a:1:{s:7:\"content\";s:150:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Categories</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->\";}s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (104,'sidebars_widgets','a:4:{s:19:\"wp_inactive_widgets\";a:2:{i:0;s:6:\"text-2\";i:1;s:6:\"text-3\";}s:9:\"sidebar-1\";a:3:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";}s:9:\"sidebar-2\";a:2:{i:0;s:7:\"block-5\";i:1;s:7:\"block-6\";}s:13:\"array_version\";i:3;}','yes');
INSERT INTO `wp_options` VALUES (105,'cron','a:8:{i:1661732059;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1661738836;a:1:{s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1661742859;a:4:{s:18:\"wp_https_detection\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1661742888;a:1:{s:21:\"wp_update_user_counts\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1661786088;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1661786089;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1662218059;a:1:{s:30:\"wp_site_health_scheduled_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}s:7:\"version\";i:2;}','yes');
INSERT INTO `wp_options` VALUES (106,'widget_pages','a:1:{s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (107,'widget_calendar','a:1:{s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (108,'widget_archives','a:1:{s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (109,'widget_media_audio','a:1:{s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (110,'widget_media_image','a:1:{s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (111,'widget_media_gallery','a:1:{s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (112,'widget_media_video','a:1:{s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (113,'widget_meta','a:1:{s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (114,'widget_search','a:1:{s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (115,'nonce_key','#Tk`g{oVSE#M#ZyG&}<(fucPdUN1A%;HD` t-gXW}FV.$^e iO$g3^$<3&Bc}$64','no');
INSERT INTO `wp_options` VALUES (116,'nonce_salt','e?Y?>n8SBO{myR4H*3,7)fnPB]~7F!&nrorYwItImF1[m8I98X?s3G(y:pZO*iZ,','no');
INSERT INTO `wp_options` VALUES (117,'widget_tag_cloud','a:1:{s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (118,'widget_nav_menu','a:1:{s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (119,'widget_custom_html','a:1:{s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (121,'recovery_keys','a:0:{}','yes');
INSERT INTO `wp_options` VALUES (124,'theme_mods_twentytwentytwo','a:3:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1661570360;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:2:{i:0;s:6:\"text-2\";i:1;s:6:\"text-3\";}s:9:\"sidebar-1\";a:3:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";}s:9:\"sidebar-2\";a:2:{i:0;s:7:\"block-5\";i:1;s:7:\"block-6\";}}}s:18:\"nav_menu_locations\";a:0:{}}','yes');
INSERT INTO `wp_options` VALUES (127,'https_detection_errors','a:1:{s:20:\"https_request_failed\";a:1:{i:0;s:21:\"HTTPS request failed.\";}}','yes');
INSERT INTO `wp_options` VALUES (128,'_site_transient_update_core','O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-6.0.1.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-6.0.1.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-6.0.1-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-6.0.1-new-bundled.zip\";s:7:\"partial\";s:0:\"\";s:8:\"rollback\";s:0:\"\";}s:7:\"current\";s:5:\"6.0.1\";s:7:\"version\";s:5:\"6.0.1\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.9\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1661730287;s:15:\"version_checked\";s:5:\"6.0.1\";s:12:\"translations\";a:0:{}}','no');
INSERT INTO `wp_options` VALUES (133,'_site_transient_update_themes','O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1661726282;s:7:\"checked\";a:1:{s:8:\"abc-demo\";s:3:\"2.0\";}s:8:\"response\";a:0:{}s:9:\"no_update\";a:0:{}s:12:\"translations\";a:0:{}}','no');
INSERT INTO `wp_options` VALUES (134,'auth_key','6sw|:G.3.Ipww18^RJC?AX[gRMPIQJc19lK{}.3{9p:pAAM%RIir(b kzFV5jfeQ','no');
INSERT INTO `wp_options` VALUES (135,'auth_salt','[>Fs|2%|_T|^yr@JCD6}8=tc6Xs1e]%{8+5)2QDL~?{r)SDX5w*<WcHTxPx#n}Cs','no');
INSERT INTO `wp_options` VALUES (136,'logged_in_key','v(h*cng4[cZ&HTt9^8_3^p&PUo;7({kJO[IRC*BA^*Tcjwqipb8?2Y1z.zpl(c_A','no');
INSERT INTO `wp_options` VALUES (137,'logged_in_salt','99DdcHw]S^)!@rmWNpG/ga7/M2H|2pqn<Z5RH4S*[kN|RJ6h (Ppi0YjW8uQ|2O^','no');
INSERT INTO `wp_options` VALUES (155,'can_compress_scripts','1','no');
INSERT INTO `wp_options` VALUES (158,'finished_updating_comment_type','1','yes');
INSERT INTO `wp_options` VALUES (163,'recently_activated','a:0:{}','yes');
INSERT INTO `wp_options` VALUES (176,'current_theme','ABC Theme','yes');
INSERT INTO `wp_options` VALUES (177,'theme_mods_code-theme','a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1659699743;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:2:{i:0;s:6:\"text-2\";i:1;s:6:\"text-3\";}s:9:\"sidebar-1\";a:3:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";}s:9:\"sidebar-2\";a:2:{i:0;s:7:\"block-5\";i:1;s:7:\"block-6\";}}}}','yes');
INSERT INTO `wp_options` VALUES (178,'theme_switched','','yes');
INSERT INTO `wp_options` VALUES (181,'widget_recent-comments','a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (182,'widget_recent-posts','a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (234,'_transient_health-check-site-status-result','{\"good\":14,\"recommended\":4,\"critical\":0}','yes');
INSERT INTO `wp_options` VALUES (311,'theme_mods_abc-demo','a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:11:\"header_menu\";i:8;}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1660966111;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:2:{i:0;s:6:\"text-2\";i:1;s:6:\"text-3\";}s:9:\"sidebar-1\";a:3:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";}s:9:\"sidebar-2\";a:2:{i:0;s:7:\"block-5\";i:1;s:7:\"block-6\";}}}}','yes');
INSERT INTO `wp_options` VALUES (318,'recovery_mode_email_last_sent','1660962965','yes');
INSERT INTO `wp_options` VALUES (457,'wp_calendar_block_has_published_posts','1','yes');
INSERT INTO `wp_options` VALUES (500,'nav_menu_options','a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}','yes');
INSERT INTO `wp_options` VALUES (559,'category_children','a:0:{}','yes');
INSERT INTO `wp_options` VALUES (946,'acf_version','5.12.2','yes');
INSERT INTO `wp_options` VALUES (961,'bodhi_svgs_plugin_version','2.4.2','yes');
INSERT INTO `wp_options` VALUES (995,'theme_mods_abc-huy/abc','a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:2:{s:11:\"footer_menu\";i:8;s:12:\"primary_menu\";i:6;}s:18:\"custom_css_post_id\";i:-1;}','yes');
INSERT INTO `wp_options` VALUES (1000,'theme_mods_abc-huy','a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1661570357;s:4:\"data\";a:1:{s:19:\"wp_inactive_widgets\";a:7:{i:0;s:6:\"text-2\";i:1;s:6:\"text-3\";i:2;s:7:\"block-2\";i:3;s:7:\"block-3\";i:4;s:7:\"block-4\";i:5;s:7:\"block-5\";i:6;s:7:\"block-6\";}}}}','yes');
INSERT INTO `wp_options` VALUES (1014,'_site_transient_timeout_php_check_12edeb5890095749089987982a1404ce','1662174878','no');
INSERT INTO `wp_options` VALUES (1015,'_site_transient_php_check_12edeb5890095749089987982a1404ce','a:5:{s:19:\"recommended_version\";s:3:\"7.4\";s:15:\"minimum_version\";s:6:\"5.6.20\";s:12:\"is_supported\";b:1;s:9:\"is_secure\";b:1;s:13:\"is_acceptable\";b:1;}','no');
INSERT INTO `wp_options` VALUES (1017,'_transient_timeout_acf_plugin_updates','1661742894','no');
INSERT INTO `wp_options` VALUES (1018,'_transient_acf_plugin_updates','a:4:{s:7:\"plugins\";a:1:{s:34:\"advanced-custom-fields-pro/acf.php\";a:8:{s:4:\"slug\";s:26:\"advanced-custom-fields-pro\";s:6:\"plugin\";s:34:\"advanced-custom-fields-pro/acf.php\";s:11:\"new_version\";s:6:\"5.12.3\";s:3:\"url\";s:36:\"https://www.advancedcustomfields.com\";s:6:\"tested\";s:5:\"6.0.1\";s:7:\"package\";s:0:\"\";s:5:\"icons\";a:1:{s:7:\"default\";s:63:\"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png\";}s:7:\"banners\";a:2:{s:3:\"low\";s:77:\"https://ps.w.org/advanced-custom-fields/assets/banner-772x250.jpg?rev=1729102\";s:4:\"high\";s:78:\"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg?rev=1729099\";}}}s:10:\"expiration\";i:172800;s:6:\"status\";i:1;s:7:\"checked\";a:1:{s:34:\"advanced-custom-fields-pro/acf.php\";s:6:\"5.12.2\";}}','no');
INSERT INTO `wp_options` VALUES (1020,'_site_transient_timeout_browser_b20f96e5878b0a47ff8626c8f757e35b','1662175044','no');
INSERT INTO `wp_options` VALUES (1021,'_site_transient_browser_b20f96e5878b0a47ff8626c8f757e35b','a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:9:\"104.0.0.0\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}','no');
INSERT INTO `wp_options` VALUES (1022,'_site_transient_timeout_community-events-d41d8cd98f00b204e9800998ecf8427e','1661733937','no');
INSERT INTO `wp_options` VALUES (1023,'_site_transient_community-events-d41d8cd98f00b204e9800998ecf8427e','a:4:{s:9:\"sandboxed\";b:0;s:5:\"error\";N;s:8:\"location\";a:1:{s:2:\"ip\";b:0;}s:6:\"events\";a:0:{}}','no');
INSERT INTO `wp_options` VALUES (1042,'theme_mods_abc','a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1661672275;s:4:\"data\";a:1:{s:19:\"wp_inactive_widgets\";a:7:{i:0;s:6:\"text-2\";i:1;s:6:\"text-3\";i:2;s:7:\"block-2\";i:3;s:7:\"block-3\";i:4;s:7:\"block-4\";i:5;s:7:\"block-5\";i:6;s:7:\"block-6\";}}}}','yes');
INSERT INTO `wp_options` VALUES (1053,'_site_transient_update_plugins','O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1661726280;s:8:\"response\";a:2:{s:27:\"svg-support/svg-support.php\";O:8:\"stdClass\":13:{s:2:\"id\";s:25:\"w.org/plugins/svg-support\";s:4:\"slug\";s:11:\"svg-support\";s:6:\"plugin\";s:27:\"svg-support/svg-support.php\";s:11:\"new_version\";s:3:\"2.5\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/svg-support/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/plugin/svg-support.2.5.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:64:\"https://ps.w.org/svg-support/assets/icon-256x256.png?rev=1417738\";s:2:\"1x\";s:56:\"https://ps.w.org/svg-support/assets/icon.svg?rev=1417738\";s:3:\"svg\";s:56:\"https://ps.w.org/svg-support/assets/icon.svg?rev=1417738\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/svg-support/assets/banner-1544x500.jpg?rev=1215377\";s:2:\"1x\";s:66:\"https://ps.w.org/svg-support/assets/banner-772x250.jpg?rev=1215377\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.8\";s:6:\"tested\";s:5:\"6.0.1\";s:12:\"requires_php\";s:3:\"7.2\";s:14:\"upgrade_notice\";s:110:\"<p>Adds new features and addresses a number of recent issues raised. Please take a backup before updating!</p>\";}s:34:\"advanced-custom-fields-pro/acf.php\";O:8:\"stdClass\":8:{s:4:\"slug\";s:26:\"advanced-custom-fields-pro\";s:6:\"plugin\";s:34:\"advanced-custom-fields-pro/acf.php\";s:11:\"new_version\";s:6:\"5.12.3\";s:3:\"url\";s:36:\"https://www.advancedcustomfields.com\";s:6:\"tested\";s:5:\"6.0.1\";s:7:\"package\";s:0:\"\";s:5:\"icons\";a:1:{s:7:\"default\";s:63:\"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png\";}s:7:\"banners\";a:2:{s:3:\"low\";s:77:\"https://ps.w.org/advanced-custom-fields/assets/banner-772x250.jpg?rev=1729102\";s:4:\"high\";s:78:\"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg?rev=1729099\";}}}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:3:{s:61:\"acf-field-for-contact-form-7/acf-field-for-contact-form-7.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:42:\"w.org/plugins/acf-field-for-contact-form-7\";s:4:\"slug\";s:28:\"acf-field-for-contact-form-7\";s:6:\"plugin\";s:61:\"acf-field-for-contact-form-7/acf-field-for-contact-form-7.php\";s:11:\"new_version\";s:3:\"1.6\";s:3:\"url\";s:59:\"https://wordpress.org/plugins/acf-field-for-contact-form-7/\";s:7:\"package\";s:75:\"https://downloads.wordpress.org/plugin/acf-field-for-contact-form-7.1.6.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:81:\"https://ps.w.org/acf-field-for-contact-form-7/assets/icon-256x256.jpg?rev=1887400\";s:2:\"1x\";s:81:\"https://ps.w.org/acf-field-for-contact-form-7/assets/icon-128x128.jpg?rev=1887400\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:84:\"https://ps.w.org/acf-field-for-contact-form-7/assets/banner-1544x500.jpg?rev=1887400\";s:2:\"1x\";s:83:\"https://ps.w.org/acf-field-for-contact-form-7/assets/banner-772x250.jpg?rev=1887400\";}s:11:\"banners_rtl\";a:2:{s:2:\"2x\";s:88:\"https://ps.w.org/acf-field-for-contact-form-7/assets/banner-1544x500-rtl.jpg?rev=1887400\";s:2:\"1x\";s:87:\"https://ps.w.org/acf-field-for-contact-form-7/assets/banner-772x250-rtl.jpg?rev=1887400\";}s:8:\"requires\";s:3:\"4.4\";}s:36:\"contact-form-7/wp-contact-form-7.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:28:\"w.org/plugins/contact-form-7\";s:4:\"slug\";s:14:\"contact-form-7\";s:6:\"plugin\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:11:\"new_version\";s:5:\"5.6.2\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/contact-form-7/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/contact-form-7.5.6.2.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:67:\"https://ps.w.org/contact-form-7/assets/icon-256x256.png?rev=2279696\";s:2:\"1x\";s:59:\"https://ps.w.org/contact-form-7/assets/icon.svg?rev=2339255\";s:3:\"svg\";s:59:\"https://ps.w.org/contact-form-7/assets/icon.svg?rev=2339255\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/contact-form-7/assets/banner-1544x500.png?rev=860901\";s:2:\"1x\";s:68:\"https://ps.w.org/contact-form-7/assets/banner-772x250.png?rev=880427\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"5.9\";}s:42:\"contact-form-cfdb7/contact-form-cfdb-7.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:32:\"w.org/plugins/contact-form-cfdb7\";s:4:\"slug\";s:18:\"contact-form-cfdb7\";s:6:\"plugin\";s:42:\"contact-form-cfdb7/contact-form-cfdb-7.php\";s:11:\"new_version\";s:7:\"1.2.6.4\";s:3:\"url\";s:49:\"https://wordpress.org/plugins/contact-form-cfdb7/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/contact-form-cfdb7.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:71:\"https://ps.w.org/contact-form-cfdb7/assets/icon-256x256.png?rev=1619878\";s:2:\"1x\";s:71:\"https://ps.w.org/contact-form-cfdb7/assets/icon-128x128.png?rev=1619878\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:73:\"https://ps.w.org/contact-form-cfdb7/assets/banner-772x250.png?rev=1619902\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.8\";}}}','no');
INSERT INTO `wp_options` VALUES (1186,'wpcf7','a:2:{s:7:\"version\";s:5:\"5.6.2\";s:13:\"bulk_validate\";a:4:{s:9:\"timestamp\";i:1661681677;s:7:\"version\";s:5:\"5.6.2\";s:11:\"count_valid\";i:1;s:13:\"count_invalid\";i:0;}}','yes');
INSERT INTO `wp_options` VALUES (1187,'cfdb7_view_install_date','2022-08-28 10:14:42','yes');
INSERT INTO `wp_options` VALUES (1203,'WPLANG','','yes');
INSERT INTO `wp_options` VALUES (1204,'new_admin_email','lamminhthien02012000@gmail.com','yes');
INSERT INTO `wp_options` VALUES (1205,'adminhash','a:2:{s:4:\"hash\";s:32:\"eeac385d266eafb8f4ddb12652c05031\";s:8:\"newemail\";s:30:\"lamminhthien02012000@gmail.com\";}','yes');
INSERT INTO `wp_options` VALUES (1216,'_site_transient_timeout_theme_roots','1661728081','no');
INSERT INTO `wp_options` VALUES (1217,'_site_transient_theme_roots','a:1:{s:8:\"abc-demo\";s:7:\"/themes\";}','no');
INSERT INTO `wp_options` VALUES (1271,'_transient_timeout_global_styles_abc-demo','1661730335','no');
INSERT INTO `wp_options` VALUES (1272,'_transient_global_styles_abc-demo','body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--duotone--dark-grayscale: url(\'#wp-duotone-dark-grayscale\');--wp--preset--duotone--grayscale: url(\'#wp-duotone-grayscale\');--wp--preset--duotone--purple-yellow: url(\'#wp-duotone-purple-yellow\');--wp--preset--duotone--blue-red: url(\'#wp-duotone-blue-red\');--wp--preset--duotone--midnight: url(\'#wp-duotone-midnight\');--wp--preset--duotone--magenta-yellow: url(\'#wp-duotone-magenta-yellow\');--wp--preset--duotone--purple-green: url(\'#wp-duotone-purple-green\');--wp--preset--duotone--blue-orange: url(\'#wp-duotone-blue-orange\');--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}','no');
/*!40000 ALTER TABLE `wp_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_postmeta`
--

DROP TABLE IF EXISTS `wp_postmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=1626 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_postmeta`
--

LOCK TABLES `wp_postmeta` WRITE;
/*!40000 ALTER TABLE `wp_postmeta` DISABLE KEYS */;
INSERT INTO `wp_postmeta` VALUES (1,2,'_wp_page_template','default');
INSERT INTO `wp_postmeta` VALUES (2,3,'_wp_page_template','default');
INSERT INTO `wp_postmeta` VALUES (3,5,'_edit_lock','1659108562:1');
INSERT INTO `wp_postmeta` VALUES (4,7,'_wp_attached_file','2022/07/12.gif');
INSERT INTO `wp_postmeta` VALUES (5,7,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:356;s:6:\"height\";i:286;s:4:\"file\";s:14:\"2022/07/12.gif\";s:8:\"filesize\";i:227500;s:5:\"sizes\";a:2:{s:6:\"medium\";a:5:{s:4:\"file\";s:14:\"12-300x241.gif\";s:5:\"width\";i:300;s:6:\"height\";i:241;s:9:\"mime-type\";s:9:\"image/gif\";s:8:\"filesize\";i:21202;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:14:\"12-150x150.gif\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/gif\";s:8:\"filesize\";i:9485;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (6,5,'_wp_trash_meta_status','draft');
INSERT INTO `wp_postmeta` VALUES (7,5,'_wp_trash_meta_time','1659147757');
INSERT INTO `wp_postmeta` VALUES (8,5,'_wp_desired_post_slug','');
INSERT INTO `wp_postmeta` VALUES (9,3,'_wp_trash_meta_status','draft');
INSERT INTO `wp_postmeta` VALUES (10,3,'_wp_trash_meta_time','1659147757');
INSERT INTO `wp_postmeta` VALUES (11,3,'_wp_desired_post_slug','privacy-policy');
INSERT INTO `wp_postmeta` VALUES (12,2,'_wp_trash_meta_status','publish');
INSERT INTO `wp_postmeta` VALUES (13,2,'_wp_trash_meta_time','1659147757');
INSERT INTO `wp_postmeta` VALUES (14,2,'_wp_desired_post_slug','sample-page');
INSERT INTO `wp_postmeta` VALUES (33,27,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (34,27,'_edit_lock','1660357414:1');
INSERT INTO `wp_postmeta` VALUES (35,28,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (36,28,'_wp_page_template','default');
INSERT INTO `wp_postmeta` VALUES (37,28,'_edit_lock','1661728090:1');
INSERT INTO `wp_postmeta` VALUES (38,32,'_wp_attached_file','2022/08/13.gif');
INSERT INTO `wp_postmeta` VALUES (39,32,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:500;s:6:\"height\";i:500;s:4:\"file\";s:14:\"2022/08/13.gif\";s:8:\"filesize\";i:247350;s:5:\"sizes\";a:2:{s:6:\"medium\";a:5:{s:4:\"file\";s:14:\"13-300x300.gif\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/gif\";s:8:\"filesize\";i:11572;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:14:\"13-150x150.gif\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/gif\";s:8:\"filesize\";i:5059;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (41,39,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (42,39,'_wp_page_template','default');
INSERT INTO `wp_postmeta` VALUES (43,39,'_edit_lock','1660899398:1');
INSERT INTO `wp_postmeta` VALUES (44,39,'intro_text','Lorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.R');
INSERT INTO `wp_postmeta` VALUES (45,39,'intro_text_2','Test 2');
INSERT INTO `wp_postmeta` VALUES (46,39,'_thumbnail_id','7');
INSERT INTO `wp_postmeta` VALUES (47,43,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (48,43,'_wp_page_template','default');
INSERT INTO `wp_postmeta` VALUES (49,43,'_edit_lock','1660903936:1');
INSERT INTO `wp_postmeta` VALUES (50,45,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (51,45,'_wp_page_template','templates/template-what-we-do.php');
INSERT INTO `wp_postmeta` VALUES (52,45,'_edit_lock','1660903910:1');
INSERT INTO `wp_postmeta` VALUES (53,47,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (54,47,'_wp_page_template','default');
INSERT INTO `wp_postmeta` VALUES (55,47,'_edit_lock','1660903945:1');
INSERT INTO `wp_postmeta` VALUES (56,49,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (57,49,'_wp_page_template','default');
INSERT INTO `wp_postmeta` VALUES (58,49,'_edit_lock','1660903902:1');
INSERT INTO `wp_postmeta` VALUES (59,51,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (60,51,'_wp_page_template','default');
INSERT INTO `wp_postmeta` VALUES (61,51,'_edit_lock','1660904026:1');
INSERT INTO `wp_postmeta` VALUES (62,53,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (63,53,'_wp_page_template','default');
INSERT INTO `wp_postmeta` VALUES (64,53,'_edit_lock','1660904181:1');
INSERT INTO `wp_postmeta` VALUES (77,45,'_thumbnail_id','7');
INSERT INTO `wp_postmeta` VALUES (86,55,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (87,55,'_edit_lock','1660903756:1');
INSERT INTO `wp_postmeta` VALUES (88,55,'_wp_page_template','default');
INSERT INTO `wp_postmeta` VALUES (91,57,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (92,57,'_edit_lock','1660903746:1');
INSERT INTO `wp_postmeta` VALUES (93,57,'_wp_page_template','default');
INSERT INTO `wp_postmeta` VALUES (96,59,'_menu_item_type','post_type');
INSERT INTO `wp_postmeta` VALUES (97,59,'_menu_item_menu_item_parent','0');
INSERT INTO `wp_postmeta` VALUES (98,59,'_menu_item_object_id','39');
INSERT INTO `wp_postmeta` VALUES (99,59,'_menu_item_object','page');
INSERT INTO `wp_postmeta` VALUES (100,59,'_menu_item_target','');
INSERT INTO `wp_postmeta` VALUES (101,59,'_menu_item_classes','a:1:{i:0;s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (102,59,'_menu_item_xfn','');
INSERT INTO `wp_postmeta` VALUES (103,59,'_menu_item_url','');
INSERT INTO `wp_postmeta` VALUES (150,66,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (151,66,'_edit_lock','1661728028:1');
INSERT INTO `wp_postmeta` VALUES (153,66,'_wp_page_template','templates/template-home.php');
INSERT INTO `wp_postmeta` VALUES (154,66,'intro_text','');
INSERT INTO `wp_postmeta` VALUES (155,66,'intro_text_2','');
INSERT INTO `wp_postmeta` VALUES (156,68,'_wp_attached_file','2022/08/anh-anime-nu-7.jpeg');
INSERT INTO `wp_postmeta` VALUES (157,68,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:900;s:6:\"height\";i:1273;s:4:\"file\";s:27:\"2022/08/anh-anime-nu-7.jpeg\";s:8:\"filesize\";i:124683;s:5:\"sizes\";a:4:{s:6:\"medium\";a:5:{s:4:\"file\";s:27:\"anh-anime-nu-7-212x300.jpeg\";s:5:\"width\";i:212;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:15568;}s:5:\"large\";a:5:{s:4:\"file\";s:28:\"anh-anime-nu-7-724x1024.jpeg\";s:5:\"width\";i:724;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:109742;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:27:\"anh-anime-nu-7-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:6930;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:28:\"anh-anime-nu-7-768x1086.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:1086;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:119793;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (158,69,'_wp_attached_file','2022/08/anime-chibi-6.jpg');
INSERT INTO `wp_postmeta` VALUES (159,69,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:25:\"2022/08/anime-chibi-6.jpg\";s:8:\"filesize\";i:46956;s:5:\"sizes\";a:3:{s:6:\"medium\";a:5:{s:4:\"file\";s:25:\"anime-chibi-6-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:7764;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:25:\"anime-chibi-6-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4340;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:25:\"anime-chibi-6-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:29126;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (162,43,'_thumbnail_id','7');
INSERT INTO `wp_postmeta` VALUES (169,47,'_oembed_d97d9362cd084b0e0a4a866523e46d89','<blockquote class=\"wp-embedded-content\" data-secret=\"K6eKYG6UlM\"><a href=\"http://lamminhthien.local/post-8/\">Post 8</a></blockquote><iframe class=\"wp-embedded-content\" sandbox=\"allow-scripts\" security=\"restricted\" style=\"position: absolute; clip: rect(1px, 1px, 1px, 1px);\" title=\"&#8220;Post 8&#8221; &#8212; phamthiutlinh.com\" src=\"http://lamminhthien.local/post-8/embed/#?secret=7uLmsCqKf0#?secret=K6eKYG6UlM\" data-secret=\"K6eKYG6UlM\" width=\"600\" height=\"338\" frameborder=\"0\" marginwidth=\"0\" marginheight=\"0\" scrolling=\"no\"></iframe>');
INSERT INTO `wp_postmeta` VALUES (170,47,'_oembed_time_d97d9362cd084b0e0a4a866523e46d89','1660830070');
INSERT INTO `wp_postmeta` VALUES (171,47,'_thumbnail_id','69');
INSERT INTO `wp_postmeta` VALUES (174,49,'_thumbnail_id','69');
INSERT INTO `wp_postmeta` VALUES (177,57,'_thumbnail_id','7');
INSERT INTO `wp_postmeta` VALUES (180,55,'_thumbnail_id','7');
INSERT INTO `wp_postmeta` VALUES (183,51,'_thumbnail_id','69');
INSERT INTO `wp_postmeta` VALUES (186,53,'_thumbnail_id','69');
INSERT INTO `wp_postmeta` VALUES (194,80,'_menu_item_type','taxonomy');
INSERT INTO `wp_postmeta` VALUES (195,80,'_menu_item_menu_item_parent','0');
INSERT INTO `wp_postmeta` VALUES (196,80,'_menu_item_object_id','5');
INSERT INTO `wp_postmeta` VALUES (197,80,'_menu_item_object','category');
INSERT INTO `wp_postmeta` VALUES (198,80,'_menu_item_target','');
INSERT INTO `wp_postmeta` VALUES (199,80,'_menu_item_classes','a:1:{i:0;s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (200,80,'_menu_item_xfn','');
INSERT INTO `wp_postmeta` VALUES (201,80,'_menu_item_url','');
INSERT INTO `wp_postmeta` VALUES (202,80,'_menu_item_orphaned','1660884246');
INSERT INTO `wp_postmeta` VALUES (212,59,'_wp_old_date','2022-08-13');
INSERT INTO `wp_postmeta` VALUES (214,28,'intro_text','');
INSERT INTO `wp_postmeta` VALUES (215,28,'intro_text_2','');
INSERT INTO `wp_postmeta` VALUES (216,27,'_wp_trash_meta_status','draft');
INSERT INTO `wp_postmeta` VALUES (217,27,'_wp_trash_meta_time','1660884695');
INSERT INTO `wp_postmeta` VALUES (218,27,'_wp_desired_post_slug','');
INSERT INTO `wp_postmeta` VALUES (219,86,'_wp_attached_file','2022/08/anime-chibi-6-1.jpg');
INSERT INTO `wp_postmeta` VALUES (220,86,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:27:\"2022/08/anime-chibi-6-1.jpg\";s:8:\"filesize\";i:46956;s:5:\"sizes\";a:3:{s:6:\"medium\";a:5:{s:4:\"file\";s:27:\"anime-chibi-6-1-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:7764;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:27:\"anime-chibi-6-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4340;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:27:\"anime-chibi-6-1-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:29126;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (221,88,'_menu_item_type','post_type');
INSERT INTO `wp_postmeta` VALUES (222,88,'_menu_item_menu_item_parent','0');
INSERT INTO `wp_postmeta` VALUES (223,88,'_menu_item_object_id','66');
INSERT INTO `wp_postmeta` VALUES (224,88,'_menu_item_object','page');
INSERT INTO `wp_postmeta` VALUES (225,88,'_menu_item_target','');
INSERT INTO `wp_postmeta` VALUES (226,88,'_menu_item_classes','a:1:{i:0;s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (227,88,'_menu_item_xfn','');
INSERT INTO `wp_postmeta` VALUES (228,88,'_menu_item_url','');
INSERT INTO `wp_postmeta` VALUES (240,1,'_wp_trash_meta_status','publish');
INSERT INTO `wp_postmeta` VALUES (241,1,'_wp_trash_meta_time','1660897570');
INSERT INTO `wp_postmeta` VALUES (242,1,'_wp_desired_post_slug','hello-world');
INSERT INTO `wp_postmeta` VALUES (243,1,'_wp_trash_meta_comments_status','a:1:{i:1;s:1:\"1\";}');
INSERT INTO `wp_postmeta` VALUES (248,90,'_menu_item_type','post_type');
INSERT INTO `wp_postmeta` VALUES (249,90,'_menu_item_menu_item_parent','0');
INSERT INTO `wp_postmeta` VALUES (250,90,'_menu_item_object_id','66');
INSERT INTO `wp_postmeta` VALUES (251,90,'_menu_item_object','page');
INSERT INTO `wp_postmeta` VALUES (252,90,'_menu_item_target','');
INSERT INTO `wp_postmeta` VALUES (253,90,'_menu_item_classes','a:1:{i:0;s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (254,90,'_menu_item_xfn','');
INSERT INTO `wp_postmeta` VALUES (255,90,'_menu_item_url','');
INSERT INTO `wp_postmeta` VALUES (257,91,'_menu_item_type','post_type');
INSERT INTO `wp_postmeta` VALUES (258,91,'_menu_item_menu_item_parent','0');
INSERT INTO `wp_postmeta` VALUES (259,91,'_menu_item_object_id','28');
INSERT INTO `wp_postmeta` VALUES (260,91,'_menu_item_object','page');
INSERT INTO `wp_postmeta` VALUES (261,91,'_menu_item_target','');
INSERT INTO `wp_postmeta` VALUES (262,91,'_menu_item_classes','a:1:{i:0;s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (263,91,'_menu_item_xfn','');
INSERT INTO `wp_postmeta` VALUES (264,91,'_menu_item_url','');
INSERT INTO `wp_postmeta` VALUES (266,92,'_menu_item_type','post_type');
INSERT INTO `wp_postmeta` VALUES (267,92,'_menu_item_menu_item_parent','0');
INSERT INTO `wp_postmeta` VALUES (268,92,'_menu_item_object_id','39');
INSERT INTO `wp_postmeta` VALUES (269,92,'_menu_item_object','page');
INSERT INTO `wp_postmeta` VALUES (270,92,'_menu_item_target','');
INSERT INTO `wp_postmeta` VALUES (271,92,'_menu_item_classes','a:1:{i:0;s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (272,92,'_menu_item_xfn','');
INSERT INTO `wp_postmeta` VALUES (273,92,'_menu_item_url','');
INSERT INTO `wp_postmeta` VALUES (275,93,'_menu_item_type','taxonomy');
INSERT INTO `wp_postmeta` VALUES (276,93,'_menu_item_menu_item_parent','0');
INSERT INTO `wp_postmeta` VALUES (277,93,'_menu_item_object_id','5');
INSERT INTO `wp_postmeta` VALUES (278,93,'_menu_item_object','category');
INSERT INTO `wp_postmeta` VALUES (279,93,'_menu_item_target','');
INSERT INTO `wp_postmeta` VALUES (280,93,'_menu_item_classes','a:1:{i:0;s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (281,93,'_menu_item_xfn','');
INSERT INTO `wp_postmeta` VALUES (282,93,'_menu_item_url','');
INSERT INTO `wp_postmeta` VALUES (300,103,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (301,103,'_edit_lock','1660963949:1');
INSERT INTO `wp_postmeta` VALUES (302,105,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (303,105,'_edit_lock','1661730191:1');
INSERT INTO `wp_postmeta` VALUES (304,103,'_wp_trash_meta_status','publish');
INSERT INTO `wp_postmeta` VALUES (305,103,'_wp_trash_meta_time','1660964094');
INSERT INTO `wp_postmeta` VALUES (306,103,'_wp_desired_post_slug','group_63004a8f7900f');
INSERT INTO `wp_postmeta` VALUES (307,104,'_wp_trash_meta_status','publish');
INSERT INTO `wp_postmeta` VALUES (308,104,'_wp_trash_meta_time','1660964094');
INSERT INTO `wp_postmeta` VALUES (309,104,'_wp_desired_post_slug','field_63004ab48119c');
INSERT INTO `wp_postmeta` VALUES (310,28,'flexible_content_0_title','ABC Software Solutions');
INSERT INTO `wp_postmeta` VALUES (311,28,'_flexible_content_0_title','field_63004ba19c354');
INSERT INTO `wp_postmeta` VALUES (312,28,'flexible_content_0_headine','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.                     Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.');
INSERT INTO `wp_postmeta` VALUES (313,28,'_flexible_content_0_headine','field_63004c3f9c355');
INSERT INTO `wp_postmeta` VALUES (314,28,'flexible_content_0_link','htttps://google.com');
INSERT INTO `wp_postmeta` VALUES (315,28,'_flexible_content_0_link','field_63004c4b9c356');
INSERT INTO `wp_postmeta` VALUES (316,28,'flexible_content_0_logo','112');
INSERT INTO `wp_postmeta` VALUES (317,28,'_flexible_content_0_logo','field_63004c5c9c357');
INSERT INTO `wp_postmeta` VALUES (318,28,'flexible_content','a:6:{i:0;s:6:\"banner\";i:1;s:14:\"who_trusted_us\";i:2;s:12:\"who_we_serve\";i:3;s:8:\"services\";i:4;s:12:\"work_with_us\";i:5;s:8:\"articles\";}');
INSERT INTO `wp_postmeta` VALUES (319,28,'_flexible_content','field_63004ae978f3c');
INSERT INTO `wp_postmeta` VALUES (320,111,'flexible_content_0_title','ABC Software Solutions');
INSERT INTO `wp_postmeta` VALUES (321,111,'_flexible_content_0_title','field_63004ba19c354');
INSERT INTO `wp_postmeta` VALUES (322,111,'flexible_content_0_headine','Resolving problems by simple solutions.');
INSERT INTO `wp_postmeta` VALUES (323,111,'_flexible_content_0_headine','field_63004c3f9c355');
INSERT INTO `wp_postmeta` VALUES (324,111,'flexible_content_0_link','htttps://google.com');
INSERT INTO `wp_postmeta` VALUES (325,111,'_flexible_content_0_link','field_63004c4b9c356');
INSERT INTO `wp_postmeta` VALUES (326,111,'flexible_content_0_logo','69');
INSERT INTO `wp_postmeta` VALUES (327,111,'_flexible_content_0_logo','field_63004c5c9c357');
INSERT INTO `wp_postmeta` VALUES (328,111,'flexible_content','a:1:{i:0;s:6:\"banner\";}');
INSERT INTO `wp_postmeta` VALUES (329,111,'_flexible_content','field_63004ae978f3c');
INSERT INTO `wp_postmeta` VALUES (330,112,'_wp_attached_file','2022/08/logo-abc.svg');
INSERT INTO `wp_postmeta` VALUES (331,112,'_wp_attachment_metadata','a:4:{s:5:\"width\";i:735;s:6:\"height\";i:673;s:4:\"file\";s:12:\"logo-abc.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";d:138;s:4:\"crop\";b:0;s:4:\"file\";s:12:\"logo-abc.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";d:275;s:4:\"crop\";b:0;s:4:\"file\";s:12:\"logo-abc.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";d:705;s:4:\"crop\";b:0;s:4:\"file\";s:12:\"logo-abc.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";d:939;s:4:\"crop\";b:0;s:4:\"file\";s:12:\"logo-abc.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:12:\"logo-abc.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:12:\"logo-abc.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}');
INSERT INTO `wp_postmeta` VALUES (332,113,'flexible_content_0_title','ABC Software Solutions');
INSERT INTO `wp_postmeta` VALUES (333,113,'_flexible_content_0_title','field_63004ba19c354');
INSERT INTO `wp_postmeta` VALUES (334,113,'flexible_content_0_headine','Resolving problems by simple solutions.');
INSERT INTO `wp_postmeta` VALUES (335,113,'_flexible_content_0_headine','field_63004c3f9c355');
INSERT INTO `wp_postmeta` VALUES (336,113,'flexible_content_0_link','htttps://google.com');
INSERT INTO `wp_postmeta` VALUES (337,113,'_flexible_content_0_link','field_63004c4b9c356');
INSERT INTO `wp_postmeta` VALUES (338,113,'flexible_content_0_logo','112');
INSERT INTO `wp_postmeta` VALUES (339,113,'_flexible_content_0_logo','field_63004c5c9c357');
INSERT INTO `wp_postmeta` VALUES (340,113,'flexible_content','a:1:{i:0;s:6:\"banner\";}');
INSERT INTO `wp_postmeta` VALUES (341,113,'_flexible_content','field_63004ae978f3c');
INSERT INTO `wp_postmeta` VALUES (342,28,'inline_featured_image','0');
INSERT INTO `wp_postmeta` VALUES (344,114,'flexible_content_0_title','ABC Software Solutions');
INSERT INTO `wp_postmeta` VALUES (345,114,'_flexible_content_0_title','field_63004ba19c354');
INSERT INTO `wp_postmeta` VALUES (346,114,'flexible_content_0_headine','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.                     Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.');
INSERT INTO `wp_postmeta` VALUES (347,114,'_flexible_content_0_headine','field_63004c3f9c355');
INSERT INTO `wp_postmeta` VALUES (348,114,'flexible_content_0_link','htttps://google.com');
INSERT INTO `wp_postmeta` VALUES (349,114,'_flexible_content_0_link','field_63004c4b9c356');
INSERT INTO `wp_postmeta` VALUES (350,114,'flexible_content_0_logo','112');
INSERT INTO `wp_postmeta` VALUES (351,114,'_flexible_content_0_logo','field_63004c5c9c357');
INSERT INTO `wp_postmeta` VALUES (352,114,'flexible_content','a:1:{i:0;s:6:\"banner\";}');
INSERT INTO `wp_postmeta` VALUES (353,114,'_flexible_content','field_63004ae978f3c');
INSERT INTO `wp_postmeta` VALUES (354,28,'flexible_content_0_headline','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.  Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.');
INSERT INTO `wp_postmeta` VALUES (355,28,'_flexible_content_0_headline','field_63004c3f9c355');
INSERT INTO `wp_postmeta` VALUES (356,116,'flexible_content_0_title','ABC Software Solutions fdasfasf');
INSERT INTO `wp_postmeta` VALUES (357,116,'_flexible_content_0_title','field_63004ba19c354');
INSERT INTO `wp_postmeta` VALUES (358,116,'flexible_content_0_headine','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.                     Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.');
INSERT INTO `wp_postmeta` VALUES (359,116,'_flexible_content_0_headine','field_63004c3f9c355');
INSERT INTO `wp_postmeta` VALUES (360,116,'flexible_content_0_link','htttps://google.com');
INSERT INTO `wp_postmeta` VALUES (361,116,'_flexible_content_0_link','field_63004c4b9c356');
INSERT INTO `wp_postmeta` VALUES (362,116,'flexible_content_0_logo','112');
INSERT INTO `wp_postmeta` VALUES (363,116,'_flexible_content_0_logo','field_63004c5c9c357');
INSERT INTO `wp_postmeta` VALUES (364,116,'flexible_content','a:1:{i:0;s:6:\"banner\";}');
INSERT INTO `wp_postmeta` VALUES (365,116,'_flexible_content','field_63004ae978f3c');
INSERT INTO `wp_postmeta` VALUES (366,116,'flexible_content_0_headline','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.  Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.');
INSERT INTO `wp_postmeta` VALUES (367,116,'_flexible_content_0_headline','field_63004c3f9c355');
INSERT INTO `wp_postmeta` VALUES (368,121,'_wp_attached_file','2022/08/company-1.svg');
INSERT INTO `wp_postmeta` VALUES (369,121,'_wp_attachment_metadata','a:4:{s:5:\"width\";i:83;s:6:\"height\";i:83;s:4:\"file\";s:13:\"company-1.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";d:150;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"company-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";d:300;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"company-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";d:768;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"company-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";d:1024;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"company-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"company-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"company-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}');
INSERT INTO `wp_postmeta` VALUES (370,122,'_wp_attached_file','2022/08/company-2.svg');
INSERT INTO `wp_postmeta` VALUES (371,122,'_wp_attachment_metadata','a:4:{s:5:\"width\";i:84;s:6:\"height\";i:84;s:4:\"file\";s:13:\"company-2.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";d:150;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"company-2.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";d:300;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"company-2.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";d:768;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"company-2.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";d:1024;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"company-2.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"company-2.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"company-2.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}');
INSERT INTO `wp_postmeta` VALUES (372,123,'_wp_attached_file','2022/08/company-3.svg');
INSERT INTO `wp_postmeta` VALUES (373,123,'_wp_attachment_metadata','a:4:{s:5:\"width\";i:83;s:6:\"height\";i:83;s:4:\"file\";s:13:\"company-3.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";d:150;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"company-3.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";d:300;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"company-3.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";d:768;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"company-3.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";d:1024;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"company-3.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"company-3.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"company-3.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}');
INSERT INTO `wp_postmeta` VALUES (374,124,'_wp_attached_file','2022/08/company-4.svg');
INSERT INTO `wp_postmeta` VALUES (375,124,'_wp_attachment_metadata','a:4:{s:5:\"width\";i:83;s:6:\"height\";i:83;s:4:\"file\";s:13:\"company-4.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";d:150;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"company-4.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";d:300;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"company-4.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";d:768;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"company-4.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";d:1024;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"company-4.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"company-4.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"company-4.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}');
INSERT INTO `wp_postmeta` VALUES (376,125,'_wp_attached_file','2022/08/company-5.svg');
INSERT INTO `wp_postmeta` VALUES (377,125,'_wp_attachment_metadata','a:4:{s:5:\"width\";i:83;s:6:\"height\";i:83;s:4:\"file\";s:13:\"company-5.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";d:150;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"company-5.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";d:300;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"company-5.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";d:768;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"company-5.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";d:1024;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"company-5.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"company-5.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"company-5.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}');
INSERT INTO `wp_postmeta` VALUES (378,126,'_wp_attached_file','2022/08/company-6.svg');
INSERT INTO `wp_postmeta` VALUES (379,126,'_wp_attachment_metadata','a:4:{s:5:\"width\";i:83;s:6:\"height\";i:83;s:4:\"file\";s:13:\"company-6.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";d:150;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"company-6.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";d:300;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"company-6.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";d:768;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"company-6.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";d:1024;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"company-6.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"company-6.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"company-6.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}');
INSERT INTO `wp_postmeta` VALUES (380,28,'flexible_content_1_title','Who Trusted Us');
INSERT INTO `wp_postmeta` VALUES (381,28,'_flexible_content_1_title','field_630b24fc6d745');
INSERT INTO `wp_postmeta` VALUES (382,28,'flexible_content_1_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum.');
INSERT INTO `wp_postmeta` VALUES (383,28,'_flexible_content_1_headline','field_630b25016d746');
INSERT INTO `wp_postmeta` VALUES (384,28,'flexible_content_1_partner_0_logo','121');
INSERT INTO `wp_postmeta` VALUES (385,28,'_flexible_content_1_partner_0_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (386,28,'flexible_content_1_partner_1_logo','122');
INSERT INTO `wp_postmeta` VALUES (387,28,'_flexible_content_1_partner_1_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (388,28,'flexible_content_1_partner_2_logo','123');
INSERT INTO `wp_postmeta` VALUES (389,28,'_flexible_content_1_partner_2_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (390,28,'flexible_content_1_partner_3_logo','124');
INSERT INTO `wp_postmeta` VALUES (391,28,'_flexible_content_1_partner_3_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (392,28,'flexible_content_1_partner_4_logo','125');
INSERT INTO `wp_postmeta` VALUES (393,28,'_flexible_content_1_partner_4_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (394,28,'flexible_content_1_partner_5_logo','126');
INSERT INTO `wp_postmeta` VALUES (395,28,'_flexible_content_1_partner_5_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (396,28,'flexible_content_1_partner','6');
INSERT INTO `wp_postmeta` VALUES (397,28,'_flexible_content_1_partner','field_630b250d6d747');
INSERT INTO `wp_postmeta` VALUES (398,127,'flexible_content_0_title','ABC Software Solutions fdasfasf');
INSERT INTO `wp_postmeta` VALUES (399,127,'_flexible_content_0_title','field_63004ba19c354');
INSERT INTO `wp_postmeta` VALUES (400,127,'flexible_content_0_headine','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.                     Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.');
INSERT INTO `wp_postmeta` VALUES (401,127,'_flexible_content_0_headine','field_63004c3f9c355');
INSERT INTO `wp_postmeta` VALUES (402,127,'flexible_content_0_link','htttps://google.com');
INSERT INTO `wp_postmeta` VALUES (403,127,'_flexible_content_0_link','field_63004c4b9c356');
INSERT INTO `wp_postmeta` VALUES (404,127,'flexible_content_0_logo','112');
INSERT INTO `wp_postmeta` VALUES (405,127,'_flexible_content_0_logo','field_63004c5c9c357');
INSERT INTO `wp_postmeta` VALUES (406,127,'flexible_content','a:2:{i:0;s:6:\"banner\";i:1;s:14:\"who_trusted_us\";}');
INSERT INTO `wp_postmeta` VALUES (407,127,'_flexible_content','field_63004ae978f3c');
INSERT INTO `wp_postmeta` VALUES (408,127,'flexible_content_0_headline','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.  Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.');
INSERT INTO `wp_postmeta` VALUES (409,127,'_flexible_content_0_headline','field_63004c3f9c355');
INSERT INTO `wp_postmeta` VALUES (410,127,'flexible_content_1_title','Who Trusted Us');
INSERT INTO `wp_postmeta` VALUES (411,127,'_flexible_content_1_title','field_630b24fc6d745');
INSERT INTO `wp_postmeta` VALUES (412,127,'flexible_content_1_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum.');
INSERT INTO `wp_postmeta` VALUES (413,127,'_flexible_content_1_headline','field_630b25016d746');
INSERT INTO `wp_postmeta` VALUES (414,127,'flexible_content_1_partner_0_logo','121');
INSERT INTO `wp_postmeta` VALUES (415,127,'_flexible_content_1_partner_0_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (416,127,'flexible_content_1_partner_1_logo','122');
INSERT INTO `wp_postmeta` VALUES (417,127,'_flexible_content_1_partner_1_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (418,127,'flexible_content_1_partner_2_logo','123');
INSERT INTO `wp_postmeta` VALUES (419,127,'_flexible_content_1_partner_2_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (420,127,'flexible_content_1_partner_3_logo','124');
INSERT INTO `wp_postmeta` VALUES (421,127,'_flexible_content_1_partner_3_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (422,127,'flexible_content_1_partner_4_logo','125');
INSERT INTO `wp_postmeta` VALUES (423,127,'_flexible_content_1_partner_4_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (424,127,'flexible_content_1_partner_5_logo','126');
INSERT INTO `wp_postmeta` VALUES (425,127,'_flexible_content_1_partner_5_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (426,127,'flexible_content_1_partner','6');
INSERT INTO `wp_postmeta` VALUES (427,127,'_flexible_content_1_partner','field_630b250d6d747');
INSERT INTO `wp_postmeta` VALUES (428,132,'_wp_attached_file','2022/08/service-1.svg');
INSERT INTO `wp_postmeta` VALUES (429,132,'_wp_attachment_metadata','a:4:{s:5:\"width\";i:252;s:6:\"height\";i:253;s:4:\"file\";s:13:\"service-1.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";d:150;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"service-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";d:300;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"service-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";d:768;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"service-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";d:1024;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"service-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"service-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"service-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}');
INSERT INTO `wp_postmeta` VALUES (430,133,'_wp_attached_file','2022/08/service-2.svg');
INSERT INTO `wp_postmeta` VALUES (431,133,'_wp_attachment_metadata','a:4:{s:5:\"width\";i:252;s:6:\"height\";i:253;s:4:\"file\";s:13:\"service-2.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";d:150;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"service-2.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";d:300;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"service-2.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";d:768;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"service-2.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";d:1024;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"service-2.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"service-2.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"service-2.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}');
INSERT INTO `wp_postmeta` VALUES (432,134,'_wp_attached_file','2022/08/service-3.svg');
INSERT INTO `wp_postmeta` VALUES (433,134,'_wp_attachment_metadata','a:4:{s:5:\"width\";i:252;s:6:\"height\";i:254;s:4:\"file\";s:13:\"service-3.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";d:152;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"service-3.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";d:303;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"service-3.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";d:776;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"service-3.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";d:1034;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"service-3.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"service-3.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"service-3.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}');
INSERT INTO `wp_postmeta` VALUES (434,135,'_wp_attached_file','2022/08/service-4.svg');
INSERT INTO `wp_postmeta` VALUES (435,135,'_wp_attachment_metadata','a:4:{s:5:\"width\";i:252;s:6:\"height\";i:253;s:4:\"file\";s:13:\"service-4.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";d:150;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"service-4.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";d:300;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"service-4.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";d:768;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"service-4.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";d:1024;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"service-4.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"service-4.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:13:\"service-4.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}');
INSERT INTO `wp_postmeta` VALUES (436,121,'_wp_attachment_image_alt','Logo1 Text');
INSERT INTO `wp_postmeta` VALUES (451,136,'flexible_content_0_title','ABC Software Solutions fdasfasf');
INSERT INTO `wp_postmeta` VALUES (452,136,'_flexible_content_0_title','field_63004ba19c354');
INSERT INTO `wp_postmeta` VALUES (453,136,'flexible_content_0_headine','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.                     Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.');
INSERT INTO `wp_postmeta` VALUES (454,136,'_flexible_content_0_headine','field_63004c3f9c355');
INSERT INTO `wp_postmeta` VALUES (455,136,'flexible_content_0_link','htttps://google.com');
INSERT INTO `wp_postmeta` VALUES (456,136,'_flexible_content_0_link','field_63004c4b9c356');
INSERT INTO `wp_postmeta` VALUES (457,136,'flexible_content_0_logo','112');
INSERT INTO `wp_postmeta` VALUES (458,136,'_flexible_content_0_logo','field_63004c5c9c357');
INSERT INTO `wp_postmeta` VALUES (459,136,'flexible_content','a:3:{i:0;s:6:\"banner\";i:1;s:14:\"who_trusted_us\";i:2;s:8:\"services\";}');
INSERT INTO `wp_postmeta` VALUES (460,136,'_flexible_content','field_63004ae978f3c');
INSERT INTO `wp_postmeta` VALUES (461,136,'flexible_content_0_headline','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.  Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.');
INSERT INTO `wp_postmeta` VALUES (462,136,'_flexible_content_0_headline','field_63004c3f9c355');
INSERT INTO `wp_postmeta` VALUES (463,136,'flexible_content_1_title','Who Trusted Us');
INSERT INTO `wp_postmeta` VALUES (464,136,'_flexible_content_1_title','field_630b24fc6d745');
INSERT INTO `wp_postmeta` VALUES (465,136,'flexible_content_1_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum.');
INSERT INTO `wp_postmeta` VALUES (466,136,'_flexible_content_1_headline','field_630b25016d746');
INSERT INTO `wp_postmeta` VALUES (467,136,'flexible_content_1_partner_0_logo','121');
INSERT INTO `wp_postmeta` VALUES (468,136,'_flexible_content_1_partner_0_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (469,136,'flexible_content_1_partner_1_logo','122');
INSERT INTO `wp_postmeta` VALUES (470,136,'_flexible_content_1_partner_1_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (471,136,'flexible_content_1_partner_2_logo','123');
INSERT INTO `wp_postmeta` VALUES (472,136,'_flexible_content_1_partner_2_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (473,136,'flexible_content_1_partner_3_logo','124');
INSERT INTO `wp_postmeta` VALUES (474,136,'_flexible_content_1_partner_3_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (475,136,'flexible_content_1_partner_4_logo','125');
INSERT INTO `wp_postmeta` VALUES (476,136,'_flexible_content_1_partner_4_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (477,136,'flexible_content_1_partner_5_logo','126');
INSERT INTO `wp_postmeta` VALUES (478,136,'_flexible_content_1_partner_5_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (479,136,'flexible_content_1_partner','6');
INSERT INTO `wp_postmeta` VALUES (480,136,'_flexible_content_1_partner','field_630b250d6d747');
INSERT INTO `wp_postmeta` VALUES (481,136,'flexible_content_2_title','Services');
INSERT INTO `wp_postmeta` VALUES (482,136,'_flexible_content_2_title','field_630b29518b3e2');
INSERT INTO `wp_postmeta` VALUES (483,136,'flexible_content_2_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum maximus. Pellentesque et neque rhoncus, sagittis ex eu, tincidunt leo');
INSERT INTO `wp_postmeta` VALUES (484,136,'_flexible_content_2_headline','field_630b29638b3e3');
INSERT INTO `wp_postmeta` VALUES (485,136,'flexible_content_2_services_0_logo','132');
INSERT INTO `wp_postmeta` VALUES (486,136,'_flexible_content_2_services_0_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (487,136,'flexible_content_2_services_1_logo','133');
INSERT INTO `wp_postmeta` VALUES (488,136,'_flexible_content_2_services_1_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (489,136,'flexible_content_2_services_2_logo','134');
INSERT INTO `wp_postmeta` VALUES (490,136,'_flexible_content_2_services_2_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (491,136,'flexible_content_2_services_3_logo','135');
INSERT INTO `wp_postmeta` VALUES (492,136,'_flexible_content_2_services_3_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (493,136,'flexible_content_2_services','4');
INSERT INTO `wp_postmeta` VALUES (494,136,'_flexible_content_2_services','field_630b297c8b3e4');
INSERT INTO `wp_postmeta` VALUES (495,137,'flexible_content_0_title','ABC Software Solutions fdasfasf');
INSERT INTO `wp_postmeta` VALUES (496,137,'_flexible_content_0_title','field_63004ba19c354');
INSERT INTO `wp_postmeta` VALUES (497,137,'flexible_content_0_headine','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.                     Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.');
INSERT INTO `wp_postmeta` VALUES (498,137,'_flexible_content_0_headine','field_63004c3f9c355');
INSERT INTO `wp_postmeta` VALUES (499,137,'flexible_content_0_link','htttps://google.com');
INSERT INTO `wp_postmeta` VALUES (500,137,'_flexible_content_0_link','field_63004c4b9c356');
INSERT INTO `wp_postmeta` VALUES (501,137,'flexible_content_0_logo','112');
INSERT INTO `wp_postmeta` VALUES (502,137,'_flexible_content_0_logo','field_63004c5c9c357');
INSERT INTO `wp_postmeta` VALUES (503,137,'flexible_content','a:3:{i:0;s:6:\"banner\";i:1;s:14:\"who_trusted_us\";i:2;s:8:\"services\";}');
INSERT INTO `wp_postmeta` VALUES (504,137,'_flexible_content','field_63004ae978f3c');
INSERT INTO `wp_postmeta` VALUES (505,137,'flexible_content_0_headline','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.  Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.');
INSERT INTO `wp_postmeta` VALUES (506,137,'_flexible_content_0_headline','field_63004c3f9c355');
INSERT INTO `wp_postmeta` VALUES (507,137,'flexible_content_1_title','Who Trusted Us');
INSERT INTO `wp_postmeta` VALUES (508,137,'_flexible_content_1_title','field_630b24fc6d745');
INSERT INTO `wp_postmeta` VALUES (509,137,'flexible_content_1_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum.');
INSERT INTO `wp_postmeta` VALUES (510,137,'_flexible_content_1_headline','field_630b25016d746');
INSERT INTO `wp_postmeta` VALUES (511,137,'flexible_content_1_partner_0_logo','121');
INSERT INTO `wp_postmeta` VALUES (512,137,'_flexible_content_1_partner_0_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (513,137,'flexible_content_1_partner_1_logo','122');
INSERT INTO `wp_postmeta` VALUES (514,137,'_flexible_content_1_partner_1_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (515,137,'flexible_content_1_partner_2_logo','123');
INSERT INTO `wp_postmeta` VALUES (516,137,'_flexible_content_1_partner_2_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (517,137,'flexible_content_1_partner_3_logo','124');
INSERT INTO `wp_postmeta` VALUES (518,137,'_flexible_content_1_partner_3_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (519,137,'flexible_content_1_partner_4_logo','125');
INSERT INTO `wp_postmeta` VALUES (520,137,'_flexible_content_1_partner_4_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (521,137,'flexible_content_1_partner_5_logo','126');
INSERT INTO `wp_postmeta` VALUES (522,137,'_flexible_content_1_partner_5_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (523,137,'flexible_content_1_partner','6');
INSERT INTO `wp_postmeta` VALUES (524,137,'_flexible_content_1_partner','field_630b250d6d747');
INSERT INTO `wp_postmeta` VALUES (525,137,'flexible_content_2_title','Services');
INSERT INTO `wp_postmeta` VALUES (526,137,'_flexible_content_2_title','field_630b29518b3e2');
INSERT INTO `wp_postmeta` VALUES (527,137,'flexible_content_2_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum maximus. Pellentesque et neque rhoncus, sagittis ex eu, tincidunt leo');
INSERT INTO `wp_postmeta` VALUES (528,137,'_flexible_content_2_headline','field_630b29638b3e3');
INSERT INTO `wp_postmeta` VALUES (529,137,'flexible_content_2_services_0_logo','132');
INSERT INTO `wp_postmeta` VALUES (530,137,'_flexible_content_2_services_0_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (531,137,'flexible_content_2_services_1_logo','133');
INSERT INTO `wp_postmeta` VALUES (532,137,'_flexible_content_2_services_1_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (533,137,'flexible_content_2_services_2_logo','134');
INSERT INTO `wp_postmeta` VALUES (534,137,'_flexible_content_2_services_2_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (535,137,'flexible_content_2_services_3_logo','135');
INSERT INTO `wp_postmeta` VALUES (536,137,'_flexible_content_2_services_3_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (537,137,'flexible_content_2_services','4');
INSERT INTO `wp_postmeta` VALUES (538,137,'_flexible_content_2_services','field_630b297c8b3e4');
INSERT INTO `wp_postmeta` VALUES (539,138,'flexible_content_0_title','ABC Software Solutions fdasfasf');
INSERT INTO `wp_postmeta` VALUES (540,138,'_flexible_content_0_title','field_63004ba19c354');
INSERT INTO `wp_postmeta` VALUES (541,138,'flexible_content_0_headine','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.                     Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.');
INSERT INTO `wp_postmeta` VALUES (542,138,'_flexible_content_0_headine','field_63004c3f9c355');
INSERT INTO `wp_postmeta` VALUES (543,138,'flexible_content_0_link','htttps://google.com');
INSERT INTO `wp_postmeta` VALUES (544,138,'_flexible_content_0_link','field_63004c4b9c356');
INSERT INTO `wp_postmeta` VALUES (545,138,'flexible_content_0_logo','112');
INSERT INTO `wp_postmeta` VALUES (546,138,'_flexible_content_0_logo','field_63004c5c9c357');
INSERT INTO `wp_postmeta` VALUES (547,138,'flexible_content','a:3:{i:0;s:6:\"banner\";i:1;s:14:\"who_trusted_us\";i:2;s:8:\"services\";}');
INSERT INTO `wp_postmeta` VALUES (548,138,'_flexible_content','field_63004ae978f3c');
INSERT INTO `wp_postmeta` VALUES (549,138,'flexible_content_0_headline','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.  Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.');
INSERT INTO `wp_postmeta` VALUES (550,138,'_flexible_content_0_headline','field_63004c3f9c355');
INSERT INTO `wp_postmeta` VALUES (551,138,'flexible_content_1_title','Who Trusted Us');
INSERT INTO `wp_postmeta` VALUES (552,138,'_flexible_content_1_title','field_630b24fc6d745');
INSERT INTO `wp_postmeta` VALUES (553,138,'flexible_content_1_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum.');
INSERT INTO `wp_postmeta` VALUES (554,138,'_flexible_content_1_headline','field_630b25016d746');
INSERT INTO `wp_postmeta` VALUES (555,138,'flexible_content_1_partner_0_logo','121');
INSERT INTO `wp_postmeta` VALUES (556,138,'_flexible_content_1_partner_0_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (557,138,'flexible_content_1_partner_1_logo','122');
INSERT INTO `wp_postmeta` VALUES (558,138,'_flexible_content_1_partner_1_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (559,138,'flexible_content_1_partner_2_logo','123');
INSERT INTO `wp_postmeta` VALUES (560,138,'_flexible_content_1_partner_2_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (561,138,'flexible_content_1_partner_3_logo','124');
INSERT INTO `wp_postmeta` VALUES (562,138,'_flexible_content_1_partner_3_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (563,138,'flexible_content_1_partner_4_logo','125');
INSERT INTO `wp_postmeta` VALUES (564,138,'_flexible_content_1_partner_4_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (565,138,'flexible_content_1_partner_5_logo','126');
INSERT INTO `wp_postmeta` VALUES (566,138,'_flexible_content_1_partner_5_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (567,138,'flexible_content_1_partner','6');
INSERT INTO `wp_postmeta` VALUES (568,138,'_flexible_content_1_partner','field_630b250d6d747');
INSERT INTO `wp_postmeta` VALUES (569,138,'flexible_content_2_title','Services');
INSERT INTO `wp_postmeta` VALUES (570,138,'_flexible_content_2_title','field_630b29518b3e2');
INSERT INTO `wp_postmeta` VALUES (571,138,'flexible_content_2_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum maximus. Pellentesque et neque rhoncus, sagittis ex eu, tincidunt leo');
INSERT INTO `wp_postmeta` VALUES (572,138,'_flexible_content_2_headline','field_630b29638b3e3');
INSERT INTO `wp_postmeta` VALUES (573,138,'flexible_content_2_services_0_logo','132');
INSERT INTO `wp_postmeta` VALUES (574,138,'_flexible_content_2_services_0_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (575,138,'flexible_content_2_services_1_logo','133');
INSERT INTO `wp_postmeta` VALUES (576,138,'_flexible_content_2_services_1_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (577,138,'flexible_content_2_services_2_logo','134');
INSERT INTO `wp_postmeta` VALUES (578,138,'_flexible_content_2_services_2_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (579,138,'flexible_content_2_services_3_logo','135');
INSERT INTO `wp_postmeta` VALUES (580,138,'_flexible_content_2_services_3_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (581,138,'flexible_content_2_services','4');
INSERT INTO `wp_postmeta` VALUES (582,138,'_flexible_content_2_services','field_630b297c8b3e4');
INSERT INTO `wp_postmeta` VALUES (583,139,'flexible_content_0_title','ABC Software Solutions');
INSERT INTO `wp_postmeta` VALUES (584,139,'_flexible_content_0_title','field_63004ba19c354');
INSERT INTO `wp_postmeta` VALUES (585,139,'flexible_content_0_headine','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.                     Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.');
INSERT INTO `wp_postmeta` VALUES (586,139,'_flexible_content_0_headine','field_63004c3f9c355');
INSERT INTO `wp_postmeta` VALUES (587,139,'flexible_content_0_link','htttps://google.com');
INSERT INTO `wp_postmeta` VALUES (588,139,'_flexible_content_0_link','field_63004c4b9c356');
INSERT INTO `wp_postmeta` VALUES (589,139,'flexible_content_0_logo','112');
INSERT INTO `wp_postmeta` VALUES (590,139,'_flexible_content_0_logo','field_63004c5c9c357');
INSERT INTO `wp_postmeta` VALUES (591,139,'flexible_content','a:3:{i:0;s:6:\"banner\";i:1;s:14:\"who_trusted_us\";i:2;s:8:\"services\";}');
INSERT INTO `wp_postmeta` VALUES (592,139,'_flexible_content','field_63004ae978f3c');
INSERT INTO `wp_postmeta` VALUES (593,139,'flexible_content_0_headline','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.  Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.');
INSERT INTO `wp_postmeta` VALUES (594,139,'_flexible_content_0_headline','field_63004c3f9c355');
INSERT INTO `wp_postmeta` VALUES (595,139,'flexible_content_1_title','Who Trusted Us');
INSERT INTO `wp_postmeta` VALUES (596,139,'_flexible_content_1_title','field_630b24fc6d745');
INSERT INTO `wp_postmeta` VALUES (597,139,'flexible_content_1_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum.');
INSERT INTO `wp_postmeta` VALUES (598,139,'_flexible_content_1_headline','field_630b25016d746');
INSERT INTO `wp_postmeta` VALUES (599,139,'flexible_content_1_partner_0_logo','121');
INSERT INTO `wp_postmeta` VALUES (600,139,'_flexible_content_1_partner_0_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (601,139,'flexible_content_1_partner_1_logo','122');
INSERT INTO `wp_postmeta` VALUES (602,139,'_flexible_content_1_partner_1_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (603,139,'flexible_content_1_partner_2_logo','123');
INSERT INTO `wp_postmeta` VALUES (604,139,'_flexible_content_1_partner_2_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (605,139,'flexible_content_1_partner_3_logo','124');
INSERT INTO `wp_postmeta` VALUES (606,139,'_flexible_content_1_partner_3_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (607,139,'flexible_content_1_partner_4_logo','125');
INSERT INTO `wp_postmeta` VALUES (608,139,'_flexible_content_1_partner_4_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (609,139,'flexible_content_1_partner_5_logo','126');
INSERT INTO `wp_postmeta` VALUES (610,139,'_flexible_content_1_partner_5_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (611,139,'flexible_content_1_partner','6');
INSERT INTO `wp_postmeta` VALUES (612,139,'_flexible_content_1_partner','field_630b250d6d747');
INSERT INTO `wp_postmeta` VALUES (613,139,'flexible_content_2_title','Services');
INSERT INTO `wp_postmeta` VALUES (614,139,'_flexible_content_2_title','field_630b29518b3e2');
INSERT INTO `wp_postmeta` VALUES (615,139,'flexible_content_2_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum maximus. Pellentesque et neque rhoncus, sagittis ex eu, tincidunt leo');
INSERT INTO `wp_postmeta` VALUES (616,139,'_flexible_content_2_headline','field_630b29638b3e3');
INSERT INTO `wp_postmeta` VALUES (617,139,'flexible_content_2_services_0_logo','132');
INSERT INTO `wp_postmeta` VALUES (618,139,'_flexible_content_2_services_0_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (619,139,'flexible_content_2_services_1_logo','133');
INSERT INTO `wp_postmeta` VALUES (620,139,'_flexible_content_2_services_1_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (621,139,'flexible_content_2_services_2_logo','134');
INSERT INTO `wp_postmeta` VALUES (622,139,'_flexible_content_2_services_2_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (623,139,'flexible_content_2_services_3_logo','135');
INSERT INTO `wp_postmeta` VALUES (624,139,'_flexible_content_2_services_3_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (625,139,'flexible_content_2_services','4');
INSERT INTO `wp_postmeta` VALUES (626,139,'_flexible_content_2_services','field_630b297c8b3e4');
INSERT INTO `wp_postmeta` VALUES (627,28,'flexible_content_2_title','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.');
INSERT INTO `wp_postmeta` VALUES (628,28,'_flexible_content_2_title','field_630b33abc7a8e');
INSERT INTO `wp_postmeta` VALUES (629,28,'flexible_content_2_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum maximus. Pellentesque et neque rhoncus, sagittis ex eu, tincidunt leo. Donec eu placerat orci, nec congue lacus. Maecenas pellentesque orci risus, sed mollis nisl pellentesque porttitor. Donec eget dolor laoreet, sagittis orci nec, scelerisque lorem.');
INSERT INTO `wp_postmeta` VALUES (630,28,'_flexible_content_2_headline','field_630b33bdc7a8f');
INSERT INTO `wp_postmeta` VALUES (631,28,'flexible_content_2_link','https://www.abcsoftwarecompany.com/');
INSERT INTO `wp_postmeta` VALUES (632,28,'_flexible_content_2_link','field_630b33efc7a90');
INSERT INTO `wp_postmeta` VALUES (633,28,'flexible_content_3_title','Services');
INSERT INTO `wp_postmeta` VALUES (634,28,'_flexible_content_3_title','field_630b29518b3e2');
INSERT INTO `wp_postmeta` VALUES (635,28,'flexible_content_3_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum maximus. Pellentesque et neque rhoncus, sagittis ex eu, tincidunt leo');
INSERT INTO `wp_postmeta` VALUES (636,28,'_flexible_content_3_headline','field_630b29638b3e3');
INSERT INTO `wp_postmeta` VALUES (637,28,'flexible_content_3_services_0_logo','132');
INSERT INTO `wp_postmeta` VALUES (638,28,'_flexible_content_3_services_0_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (639,28,'flexible_content_3_services_1_logo','133');
INSERT INTO `wp_postmeta` VALUES (640,28,'_flexible_content_3_services_1_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (641,28,'flexible_content_3_services_2_logo','134');
INSERT INTO `wp_postmeta` VALUES (642,28,'_flexible_content_3_services_2_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (643,28,'flexible_content_3_services_3_logo','135');
INSERT INTO `wp_postmeta` VALUES (644,28,'_flexible_content_3_services_3_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (645,28,'flexible_content_3_services','4');
INSERT INTO `wp_postmeta` VALUES (646,28,'_flexible_content_3_services','field_630b297c8b3e4');
INSERT INTO `wp_postmeta` VALUES (647,143,'flexible_content_0_title','ABC Software Solutions');
INSERT INTO `wp_postmeta` VALUES (648,143,'_flexible_content_0_title','field_63004ba19c354');
INSERT INTO `wp_postmeta` VALUES (649,143,'flexible_content_0_headine','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.                     Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.');
INSERT INTO `wp_postmeta` VALUES (650,143,'_flexible_content_0_headine','field_63004c3f9c355');
INSERT INTO `wp_postmeta` VALUES (651,143,'flexible_content_0_link','htttps://google.com');
INSERT INTO `wp_postmeta` VALUES (652,143,'_flexible_content_0_link','field_63004c4b9c356');
INSERT INTO `wp_postmeta` VALUES (653,143,'flexible_content_0_logo','112');
INSERT INTO `wp_postmeta` VALUES (654,143,'_flexible_content_0_logo','field_63004c5c9c357');
INSERT INTO `wp_postmeta` VALUES (655,143,'flexible_content','a:4:{i:0;s:6:\"banner\";i:1;s:14:\"who_trusted_us\";i:2;s:12:\"who_we_serve\";i:3;s:8:\"services\";}');
INSERT INTO `wp_postmeta` VALUES (656,143,'_flexible_content','field_63004ae978f3c');
INSERT INTO `wp_postmeta` VALUES (657,143,'flexible_content_0_headline','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.  Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.');
INSERT INTO `wp_postmeta` VALUES (658,143,'_flexible_content_0_headline','field_63004c3f9c355');
INSERT INTO `wp_postmeta` VALUES (659,143,'flexible_content_1_title','Who Trusted Us');
INSERT INTO `wp_postmeta` VALUES (660,143,'_flexible_content_1_title','field_630b24fc6d745');
INSERT INTO `wp_postmeta` VALUES (661,143,'flexible_content_1_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum.');
INSERT INTO `wp_postmeta` VALUES (662,143,'_flexible_content_1_headline','field_630b25016d746');
INSERT INTO `wp_postmeta` VALUES (663,143,'flexible_content_1_partner_0_logo','121');
INSERT INTO `wp_postmeta` VALUES (664,143,'_flexible_content_1_partner_0_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (665,143,'flexible_content_1_partner_1_logo','122');
INSERT INTO `wp_postmeta` VALUES (666,143,'_flexible_content_1_partner_1_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (667,143,'flexible_content_1_partner_2_logo','123');
INSERT INTO `wp_postmeta` VALUES (668,143,'_flexible_content_1_partner_2_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (669,143,'flexible_content_1_partner_3_logo','124');
INSERT INTO `wp_postmeta` VALUES (670,143,'_flexible_content_1_partner_3_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (671,143,'flexible_content_1_partner_4_logo','125');
INSERT INTO `wp_postmeta` VALUES (672,143,'_flexible_content_1_partner_4_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (673,143,'flexible_content_1_partner_5_logo','126');
INSERT INTO `wp_postmeta` VALUES (674,143,'_flexible_content_1_partner_5_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (675,143,'flexible_content_1_partner','6');
INSERT INTO `wp_postmeta` VALUES (676,143,'_flexible_content_1_partner','field_630b250d6d747');
INSERT INTO `wp_postmeta` VALUES (677,143,'flexible_content_2_title','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.');
INSERT INTO `wp_postmeta` VALUES (678,143,'_flexible_content_2_title','field_630b33abc7a8e');
INSERT INTO `wp_postmeta` VALUES (679,143,'flexible_content_2_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum maximus. Pellentesque et neque rhoncus, sagittis ex eu, tincidunt leo. Donec eu placerat orci, nec congue lacus. Maecenas pellentesque orci risus, sed mollis nisl pellentesque porttitor. Donec eget dolor laoreet, sagittis orci nec, scelerisque lorem.');
INSERT INTO `wp_postmeta` VALUES (680,143,'_flexible_content_2_headline','field_630b33bdc7a8f');
INSERT INTO `wp_postmeta` VALUES (681,143,'flexible_content_2_link','');
INSERT INTO `wp_postmeta` VALUES (682,143,'_flexible_content_2_link','field_630b33efc7a90');
INSERT INTO `wp_postmeta` VALUES (683,143,'flexible_content_3_title','Services');
INSERT INTO `wp_postmeta` VALUES (684,143,'_flexible_content_3_title','field_630b29518b3e2');
INSERT INTO `wp_postmeta` VALUES (685,143,'flexible_content_3_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum maximus. Pellentesque et neque rhoncus, sagittis ex eu, tincidunt leo');
INSERT INTO `wp_postmeta` VALUES (686,143,'_flexible_content_3_headline','field_630b29638b3e3');
INSERT INTO `wp_postmeta` VALUES (687,143,'flexible_content_3_services_0_logo','132');
INSERT INTO `wp_postmeta` VALUES (688,143,'_flexible_content_3_services_0_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (689,143,'flexible_content_3_services_1_logo','133');
INSERT INTO `wp_postmeta` VALUES (690,143,'_flexible_content_3_services_1_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (691,143,'flexible_content_3_services_2_logo','134');
INSERT INTO `wp_postmeta` VALUES (692,143,'_flexible_content_3_services_2_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (693,143,'flexible_content_3_services_3_logo','135');
INSERT INTO `wp_postmeta` VALUES (694,143,'_flexible_content_3_services_3_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (695,143,'flexible_content_3_services','4');
INSERT INTO `wp_postmeta` VALUES (696,143,'_flexible_content_3_services','field_630b297c8b3e4');
INSERT INTO `wp_postmeta` VALUES (697,145,'_wp_attached_file','2022/08/btn-discover-who-we-serve.svg');
INSERT INTO `wp_postmeta` VALUES (698,145,'_wp_attachment_metadata','a:4:{s:5:\"width\";i:436;s:6:\"height\";i:423;s:4:\"file\";s:29:\"btn-discover-who-we-serve.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";d:146;s:4:\"crop\";b:0;s:4:\"file\";s:29:\"btn-discover-who-we-serve.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";d:291;s:4:\"crop\";b:0;s:4:\"file\";s:29:\"btn-discover-who-we-serve.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";d:746;s:4:\"crop\";b:0;s:4:\"file\";s:29:\"btn-discover-who-we-serve.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";d:994;s:4:\"crop\";b:0;s:4:\"file\";s:29:\"btn-discover-who-we-serve.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:29:\"btn-discover-who-we-serve.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:29:\"btn-discover-who-we-serve.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}');
INSERT INTO `wp_postmeta` VALUES (699,28,'flexible_content_2_logo','145');
INSERT INTO `wp_postmeta` VALUES (700,28,'_flexible_content_2_logo','field_630b369948254');
INSERT INTO `wp_postmeta` VALUES (701,146,'flexible_content_0_title','ABC Software Solutions');
INSERT INTO `wp_postmeta` VALUES (702,146,'_flexible_content_0_title','field_63004ba19c354');
INSERT INTO `wp_postmeta` VALUES (703,146,'flexible_content_0_headine','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.                     Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.');
INSERT INTO `wp_postmeta` VALUES (704,146,'_flexible_content_0_headine','field_63004c3f9c355');
INSERT INTO `wp_postmeta` VALUES (705,146,'flexible_content_0_link','htttps://google.com');
INSERT INTO `wp_postmeta` VALUES (706,146,'_flexible_content_0_link','field_63004c4b9c356');
INSERT INTO `wp_postmeta` VALUES (707,146,'flexible_content_0_logo','112');
INSERT INTO `wp_postmeta` VALUES (708,146,'_flexible_content_0_logo','field_63004c5c9c357');
INSERT INTO `wp_postmeta` VALUES (709,146,'flexible_content','a:4:{i:0;s:6:\"banner\";i:1;s:14:\"who_trusted_us\";i:2;s:12:\"who_we_serve\";i:3;s:8:\"services\";}');
INSERT INTO `wp_postmeta` VALUES (710,146,'_flexible_content','field_63004ae978f3c');
INSERT INTO `wp_postmeta` VALUES (711,146,'flexible_content_0_headline','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.  Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.');
INSERT INTO `wp_postmeta` VALUES (712,146,'_flexible_content_0_headline','field_63004c3f9c355');
INSERT INTO `wp_postmeta` VALUES (713,146,'flexible_content_1_title','Who Trusted Us');
INSERT INTO `wp_postmeta` VALUES (714,146,'_flexible_content_1_title','field_630b24fc6d745');
INSERT INTO `wp_postmeta` VALUES (715,146,'flexible_content_1_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum.');
INSERT INTO `wp_postmeta` VALUES (716,146,'_flexible_content_1_headline','field_630b25016d746');
INSERT INTO `wp_postmeta` VALUES (717,146,'flexible_content_1_partner_0_logo','121');
INSERT INTO `wp_postmeta` VALUES (718,146,'_flexible_content_1_partner_0_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (719,146,'flexible_content_1_partner_1_logo','122');
INSERT INTO `wp_postmeta` VALUES (720,146,'_flexible_content_1_partner_1_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (721,146,'flexible_content_1_partner_2_logo','123');
INSERT INTO `wp_postmeta` VALUES (722,146,'_flexible_content_1_partner_2_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (723,146,'flexible_content_1_partner_3_logo','124');
INSERT INTO `wp_postmeta` VALUES (724,146,'_flexible_content_1_partner_3_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (725,146,'flexible_content_1_partner_4_logo','125');
INSERT INTO `wp_postmeta` VALUES (726,146,'_flexible_content_1_partner_4_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (727,146,'flexible_content_1_partner_5_logo','126');
INSERT INTO `wp_postmeta` VALUES (728,146,'_flexible_content_1_partner_5_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (729,146,'flexible_content_1_partner','6');
INSERT INTO `wp_postmeta` VALUES (730,146,'_flexible_content_1_partner','field_630b250d6d747');
INSERT INTO `wp_postmeta` VALUES (731,146,'flexible_content_2_title','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.');
INSERT INTO `wp_postmeta` VALUES (732,146,'_flexible_content_2_title','field_630b33abc7a8e');
INSERT INTO `wp_postmeta` VALUES (733,146,'flexible_content_2_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum maximus. Pellentesque et neque rhoncus, sagittis ex eu, tincidunt leo. Donec eu placerat orci, nec congue lacus. Maecenas pellentesque orci risus, sed mollis nisl pellentesque porttitor. Donec eget dolor laoreet, sagittis orci nec, scelerisque lorem.');
INSERT INTO `wp_postmeta` VALUES (734,146,'_flexible_content_2_headline','field_630b33bdc7a8f');
INSERT INTO `wp_postmeta` VALUES (735,146,'flexible_content_2_link','');
INSERT INTO `wp_postmeta` VALUES (736,146,'_flexible_content_2_link','field_630b33efc7a90');
INSERT INTO `wp_postmeta` VALUES (737,146,'flexible_content_3_title','Services');
INSERT INTO `wp_postmeta` VALUES (738,146,'_flexible_content_3_title','field_630b29518b3e2');
INSERT INTO `wp_postmeta` VALUES (739,146,'flexible_content_3_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum maximus. Pellentesque et neque rhoncus, sagittis ex eu, tincidunt leo');
INSERT INTO `wp_postmeta` VALUES (740,146,'_flexible_content_3_headline','field_630b29638b3e3');
INSERT INTO `wp_postmeta` VALUES (741,146,'flexible_content_3_services_0_logo','132');
INSERT INTO `wp_postmeta` VALUES (742,146,'_flexible_content_3_services_0_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (743,146,'flexible_content_3_services_1_logo','133');
INSERT INTO `wp_postmeta` VALUES (744,146,'_flexible_content_3_services_1_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (745,146,'flexible_content_3_services_2_logo','134');
INSERT INTO `wp_postmeta` VALUES (746,146,'_flexible_content_3_services_2_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (747,146,'flexible_content_3_services_3_logo','135');
INSERT INTO `wp_postmeta` VALUES (748,146,'_flexible_content_3_services_3_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (749,146,'flexible_content_3_services','4');
INSERT INTO `wp_postmeta` VALUES (750,146,'_flexible_content_3_services','field_630b297c8b3e4');
INSERT INTO `wp_postmeta` VALUES (751,146,'flexible_content_2_logo','145');
INSERT INTO `wp_postmeta` VALUES (752,146,'_flexible_content_2_logo','field_630b369948254');
INSERT INTO `wp_postmeta` VALUES (753,28,'flexible_content_2_link_title','Discover Who We Serve');
INSERT INTO `wp_postmeta` VALUES (754,28,'_flexible_content_2_link_title','field_630b3872d34f9');
INSERT INTO `wp_postmeta` VALUES (755,148,'flexible_content_0_title','ABC Software Solutions');
INSERT INTO `wp_postmeta` VALUES (756,148,'_flexible_content_0_title','field_63004ba19c354');
INSERT INTO `wp_postmeta` VALUES (757,148,'flexible_content_0_headine','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.                     Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.');
INSERT INTO `wp_postmeta` VALUES (758,148,'_flexible_content_0_headine','field_63004c3f9c355');
INSERT INTO `wp_postmeta` VALUES (759,148,'flexible_content_0_link','htttps://google.com');
INSERT INTO `wp_postmeta` VALUES (760,148,'_flexible_content_0_link','field_63004c4b9c356');
INSERT INTO `wp_postmeta` VALUES (761,148,'flexible_content_0_logo','112');
INSERT INTO `wp_postmeta` VALUES (762,148,'_flexible_content_0_logo','field_63004c5c9c357');
INSERT INTO `wp_postmeta` VALUES (763,148,'flexible_content','a:4:{i:0;s:6:\"banner\";i:1;s:14:\"who_trusted_us\";i:2;s:12:\"who_we_serve\";i:3;s:8:\"services\";}');
INSERT INTO `wp_postmeta` VALUES (764,148,'_flexible_content','field_63004ae978f3c');
INSERT INTO `wp_postmeta` VALUES (765,148,'flexible_content_0_headline','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.  Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.');
INSERT INTO `wp_postmeta` VALUES (766,148,'_flexible_content_0_headline','field_63004c3f9c355');
INSERT INTO `wp_postmeta` VALUES (767,148,'flexible_content_1_title','Who Trusted Us');
INSERT INTO `wp_postmeta` VALUES (768,148,'_flexible_content_1_title','field_630b24fc6d745');
INSERT INTO `wp_postmeta` VALUES (769,148,'flexible_content_1_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum.');
INSERT INTO `wp_postmeta` VALUES (770,148,'_flexible_content_1_headline','field_630b25016d746');
INSERT INTO `wp_postmeta` VALUES (771,148,'flexible_content_1_partner_0_logo','121');
INSERT INTO `wp_postmeta` VALUES (772,148,'_flexible_content_1_partner_0_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (773,148,'flexible_content_1_partner_1_logo','122');
INSERT INTO `wp_postmeta` VALUES (774,148,'_flexible_content_1_partner_1_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (775,148,'flexible_content_1_partner_2_logo','123');
INSERT INTO `wp_postmeta` VALUES (776,148,'_flexible_content_1_partner_2_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (777,148,'flexible_content_1_partner_3_logo','124');
INSERT INTO `wp_postmeta` VALUES (778,148,'_flexible_content_1_partner_3_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (779,148,'flexible_content_1_partner_4_logo','125');
INSERT INTO `wp_postmeta` VALUES (780,148,'_flexible_content_1_partner_4_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (781,148,'flexible_content_1_partner_5_logo','126');
INSERT INTO `wp_postmeta` VALUES (782,148,'_flexible_content_1_partner_5_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (783,148,'flexible_content_1_partner','6');
INSERT INTO `wp_postmeta` VALUES (784,148,'_flexible_content_1_partner','field_630b250d6d747');
INSERT INTO `wp_postmeta` VALUES (785,148,'flexible_content_2_title','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.');
INSERT INTO `wp_postmeta` VALUES (786,148,'_flexible_content_2_title','field_630b33abc7a8e');
INSERT INTO `wp_postmeta` VALUES (787,148,'flexible_content_2_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum maximus. Pellentesque et neque rhoncus, sagittis ex eu, tincidunt leo. Donec eu placerat orci, nec congue lacus. Maecenas pellentesque orci risus, sed mollis nisl pellentesque porttitor. Donec eget dolor laoreet, sagittis orci nec, scelerisque lorem.');
INSERT INTO `wp_postmeta` VALUES (788,148,'_flexible_content_2_headline','field_630b33bdc7a8f');
INSERT INTO `wp_postmeta` VALUES (789,148,'flexible_content_2_link','');
INSERT INTO `wp_postmeta` VALUES (790,148,'_flexible_content_2_link','field_630b33efc7a90');
INSERT INTO `wp_postmeta` VALUES (791,148,'flexible_content_3_title','Services');
INSERT INTO `wp_postmeta` VALUES (792,148,'_flexible_content_3_title','field_630b29518b3e2');
INSERT INTO `wp_postmeta` VALUES (793,148,'flexible_content_3_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum maximus. Pellentesque et neque rhoncus, sagittis ex eu, tincidunt leo');
INSERT INTO `wp_postmeta` VALUES (794,148,'_flexible_content_3_headline','field_630b29638b3e3');
INSERT INTO `wp_postmeta` VALUES (795,148,'flexible_content_3_services_0_logo','132');
INSERT INTO `wp_postmeta` VALUES (796,148,'_flexible_content_3_services_0_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (797,148,'flexible_content_3_services_1_logo','133');
INSERT INTO `wp_postmeta` VALUES (798,148,'_flexible_content_3_services_1_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (799,148,'flexible_content_3_services_2_logo','134');
INSERT INTO `wp_postmeta` VALUES (800,148,'_flexible_content_3_services_2_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (801,148,'flexible_content_3_services_3_logo','135');
INSERT INTO `wp_postmeta` VALUES (802,148,'_flexible_content_3_services_3_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (803,148,'flexible_content_3_services','4');
INSERT INTO `wp_postmeta` VALUES (804,148,'_flexible_content_3_services','field_630b297c8b3e4');
INSERT INTO `wp_postmeta` VALUES (805,148,'flexible_content_2_logo','145');
INSERT INTO `wp_postmeta` VALUES (806,148,'_flexible_content_2_logo','field_630b369948254');
INSERT INTO `wp_postmeta` VALUES (807,148,'flexible_content_2_link_title','Discover Who We Serve');
INSERT INTO `wp_postmeta` VALUES (808,148,'_flexible_content_2_link_title','field_630b3872d34f9');
INSERT INTO `wp_postmeta` VALUES (809,149,'flexible_content_0_title','ABC Software Solutions');
INSERT INTO `wp_postmeta` VALUES (810,149,'_flexible_content_0_title','field_63004ba19c354');
INSERT INTO `wp_postmeta` VALUES (811,149,'flexible_content_0_headine','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.                     Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.');
INSERT INTO `wp_postmeta` VALUES (812,149,'_flexible_content_0_headine','field_63004c3f9c355');
INSERT INTO `wp_postmeta` VALUES (813,149,'flexible_content_0_link','htttps://google.com');
INSERT INTO `wp_postmeta` VALUES (814,149,'_flexible_content_0_link','field_63004c4b9c356');
INSERT INTO `wp_postmeta` VALUES (815,149,'flexible_content_0_logo','112');
INSERT INTO `wp_postmeta` VALUES (816,149,'_flexible_content_0_logo','field_63004c5c9c357');
INSERT INTO `wp_postmeta` VALUES (817,149,'flexible_content','a:4:{i:0;s:6:\"banner\";i:1;s:14:\"who_trusted_us\";i:2;s:12:\"who_we_serve\";i:3;s:8:\"services\";}');
INSERT INTO `wp_postmeta` VALUES (818,149,'_flexible_content','field_63004ae978f3c');
INSERT INTO `wp_postmeta` VALUES (819,149,'flexible_content_0_headline','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.  Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.');
INSERT INTO `wp_postmeta` VALUES (820,149,'_flexible_content_0_headline','field_63004c3f9c355');
INSERT INTO `wp_postmeta` VALUES (821,149,'flexible_content_1_title','Who Trusted Us');
INSERT INTO `wp_postmeta` VALUES (822,149,'_flexible_content_1_title','field_630b24fc6d745');
INSERT INTO `wp_postmeta` VALUES (823,149,'flexible_content_1_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum.');
INSERT INTO `wp_postmeta` VALUES (824,149,'_flexible_content_1_headline','field_630b25016d746');
INSERT INTO `wp_postmeta` VALUES (825,149,'flexible_content_1_partner_0_logo','121');
INSERT INTO `wp_postmeta` VALUES (826,149,'_flexible_content_1_partner_0_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (827,149,'flexible_content_1_partner_1_logo','122');
INSERT INTO `wp_postmeta` VALUES (828,149,'_flexible_content_1_partner_1_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (829,149,'flexible_content_1_partner_2_logo','123');
INSERT INTO `wp_postmeta` VALUES (830,149,'_flexible_content_1_partner_2_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (831,149,'flexible_content_1_partner_3_logo','124');
INSERT INTO `wp_postmeta` VALUES (832,149,'_flexible_content_1_partner_3_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (833,149,'flexible_content_1_partner_4_logo','125');
INSERT INTO `wp_postmeta` VALUES (834,149,'_flexible_content_1_partner_4_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (835,149,'flexible_content_1_partner_5_logo','126');
INSERT INTO `wp_postmeta` VALUES (836,149,'_flexible_content_1_partner_5_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (837,149,'flexible_content_1_partner','6');
INSERT INTO `wp_postmeta` VALUES (838,149,'_flexible_content_1_partner','field_630b250d6d747');
INSERT INTO `wp_postmeta` VALUES (839,149,'flexible_content_2_title','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.');
INSERT INTO `wp_postmeta` VALUES (840,149,'_flexible_content_2_title','field_630b33abc7a8e');
INSERT INTO `wp_postmeta` VALUES (841,149,'flexible_content_2_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum maximus. Pellentesque et neque rhoncus, sagittis ex eu, tincidunt leo. Donec eu placerat orci, nec congue lacus. Maecenas pellentesque orci risus, sed mollis nisl pellentesque porttitor. Donec eget dolor laoreet, sagittis orci nec, scelerisque lorem.');
INSERT INTO `wp_postmeta` VALUES (842,149,'_flexible_content_2_headline','field_630b33bdc7a8f');
INSERT INTO `wp_postmeta` VALUES (843,149,'flexible_content_2_link','https://www.abcsoftwarecompany.com/');
INSERT INTO `wp_postmeta` VALUES (844,149,'_flexible_content_2_link','field_630b33efc7a90');
INSERT INTO `wp_postmeta` VALUES (845,149,'flexible_content_3_title','Services');
INSERT INTO `wp_postmeta` VALUES (846,149,'_flexible_content_3_title','field_630b29518b3e2');
INSERT INTO `wp_postmeta` VALUES (847,149,'flexible_content_3_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum maximus. Pellentesque et neque rhoncus, sagittis ex eu, tincidunt leo');
INSERT INTO `wp_postmeta` VALUES (848,149,'_flexible_content_3_headline','field_630b29638b3e3');
INSERT INTO `wp_postmeta` VALUES (849,149,'flexible_content_3_services_0_logo','132');
INSERT INTO `wp_postmeta` VALUES (850,149,'_flexible_content_3_services_0_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (851,149,'flexible_content_3_services_1_logo','133');
INSERT INTO `wp_postmeta` VALUES (852,149,'_flexible_content_3_services_1_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (853,149,'flexible_content_3_services_2_logo','134');
INSERT INTO `wp_postmeta` VALUES (854,149,'_flexible_content_3_services_2_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (855,149,'flexible_content_3_services_3_logo','135');
INSERT INTO `wp_postmeta` VALUES (856,149,'_flexible_content_3_services_3_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (857,149,'flexible_content_3_services','4');
INSERT INTO `wp_postmeta` VALUES (858,149,'_flexible_content_3_services','field_630b297c8b3e4');
INSERT INTO `wp_postmeta` VALUES (859,149,'flexible_content_2_logo','145');
INSERT INTO `wp_postmeta` VALUES (860,149,'_flexible_content_2_logo','field_630b369948254');
INSERT INTO `wp_postmeta` VALUES (861,149,'flexible_content_2_link_title','Discover Who We Serve');
INSERT INTO `wp_postmeta` VALUES (862,149,'_flexible_content_2_link_title','field_630b3872d34f9');
INSERT INTO `wp_postmeta` VALUES (863,155,'_wp_attached_file','2022/08/work-with-us.png');
INSERT INTO `wp_postmeta` VALUES (864,155,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:540;s:6:\"height\";i:610;s:4:\"file\";s:24:\"2022/08/work-with-us.png\";s:8:\"filesize\";i:415446;s:5:\"sizes\";a:2:{s:6:\"medium\";a:5:{s:4:\"file\";s:24:\"work-with-us-266x300.png\";s:5:\"width\";i:266;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:108996;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:24:\"work-with-us-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:36324;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (865,28,'flexible_content_4_title','We create amazing digital products');
INSERT INTO `wp_postmeta` VALUES (866,28,'_flexible_content_4_title','field_630b39b92a1e2');
INSERT INTO `wp_postmeta` VALUES (867,28,'flexible_content_4_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum maximus. Pellentesque et neque rhoncus, sagittis ex eu, tincidunt leo. Donec eu placerat orci, nec congue lacus. Maecenas pellentesque orci risus, sed mollis nisl pellentesque porttitor. Donec eget dolor laoreet, sagittis orci nec, scelerisque lorem.');
INSERT INTO `wp_postmeta` VALUES (868,28,'_flexible_content_4_headline','field_630b3a0e2a1e3');
INSERT INTO `wp_postmeta` VALUES (869,28,'flexible_content_4_logo','155');
INSERT INTO `wp_postmeta` VALUES (870,28,'_flexible_content_4_logo','field_630b3a202a1e4');
INSERT INTO `wp_postmeta` VALUES (871,28,'flexible_content_4_link','https://www.abcsoftwarecompany.com/');
INSERT INTO `wp_postmeta` VALUES (872,28,'_flexible_content_4_link','field_630b3a302a1e5');
INSERT INTO `wp_postmeta` VALUES (873,28,'flexible_content_4_link_title','Work with us');
INSERT INTO `wp_postmeta` VALUES (874,28,'_flexible_content_4_link_title','field_630b3a3b2a1e6');
INSERT INTO `wp_postmeta` VALUES (875,156,'flexible_content_0_title','ABC Software Solutions');
INSERT INTO `wp_postmeta` VALUES (876,156,'_flexible_content_0_title','field_63004ba19c354');
INSERT INTO `wp_postmeta` VALUES (877,156,'flexible_content_0_headine','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.                     Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.');
INSERT INTO `wp_postmeta` VALUES (878,156,'_flexible_content_0_headine','field_63004c3f9c355');
INSERT INTO `wp_postmeta` VALUES (879,156,'flexible_content_0_link','htttps://google.com');
INSERT INTO `wp_postmeta` VALUES (880,156,'_flexible_content_0_link','field_63004c4b9c356');
INSERT INTO `wp_postmeta` VALUES (881,156,'flexible_content_0_logo','112');
INSERT INTO `wp_postmeta` VALUES (882,156,'_flexible_content_0_logo','field_63004c5c9c357');
INSERT INTO `wp_postmeta` VALUES (883,156,'flexible_content','a:5:{i:0;s:6:\"banner\";i:1;s:14:\"who_trusted_us\";i:2;s:12:\"who_we_serve\";i:3;s:8:\"services\";i:4;s:12:\"work_with_us\";}');
INSERT INTO `wp_postmeta` VALUES (884,156,'_flexible_content','field_63004ae978f3c');
INSERT INTO `wp_postmeta` VALUES (885,156,'flexible_content_0_headline','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.  Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.');
INSERT INTO `wp_postmeta` VALUES (886,156,'_flexible_content_0_headline','field_63004c3f9c355');
INSERT INTO `wp_postmeta` VALUES (887,156,'flexible_content_1_title','Who Trusted Us');
INSERT INTO `wp_postmeta` VALUES (888,156,'_flexible_content_1_title','field_630b24fc6d745');
INSERT INTO `wp_postmeta` VALUES (889,156,'flexible_content_1_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum.');
INSERT INTO `wp_postmeta` VALUES (890,156,'_flexible_content_1_headline','field_630b25016d746');
INSERT INTO `wp_postmeta` VALUES (891,156,'flexible_content_1_partner_0_logo','121');
INSERT INTO `wp_postmeta` VALUES (892,156,'_flexible_content_1_partner_0_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (893,156,'flexible_content_1_partner_1_logo','122');
INSERT INTO `wp_postmeta` VALUES (894,156,'_flexible_content_1_partner_1_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (895,156,'flexible_content_1_partner_2_logo','123');
INSERT INTO `wp_postmeta` VALUES (896,156,'_flexible_content_1_partner_2_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (897,156,'flexible_content_1_partner_3_logo','124');
INSERT INTO `wp_postmeta` VALUES (898,156,'_flexible_content_1_partner_3_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (899,156,'flexible_content_1_partner_4_logo','125');
INSERT INTO `wp_postmeta` VALUES (900,156,'_flexible_content_1_partner_4_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (901,156,'flexible_content_1_partner_5_logo','126');
INSERT INTO `wp_postmeta` VALUES (902,156,'_flexible_content_1_partner_5_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (903,156,'flexible_content_1_partner','6');
INSERT INTO `wp_postmeta` VALUES (904,156,'_flexible_content_1_partner','field_630b250d6d747');
INSERT INTO `wp_postmeta` VALUES (905,156,'flexible_content_2_title','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.');
INSERT INTO `wp_postmeta` VALUES (906,156,'_flexible_content_2_title','field_630b33abc7a8e');
INSERT INTO `wp_postmeta` VALUES (907,156,'flexible_content_2_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum maximus. Pellentesque et neque rhoncus, sagittis ex eu, tincidunt leo. Donec eu placerat orci, nec congue lacus. Maecenas pellentesque orci risus, sed mollis nisl pellentesque porttitor. Donec eget dolor laoreet, sagittis orci nec, scelerisque lorem.');
INSERT INTO `wp_postmeta` VALUES (908,156,'_flexible_content_2_headline','field_630b33bdc7a8f');
INSERT INTO `wp_postmeta` VALUES (909,156,'flexible_content_2_link','https://www.abcsoftwarecompany.com/');
INSERT INTO `wp_postmeta` VALUES (910,156,'_flexible_content_2_link','field_630b33efc7a90');
INSERT INTO `wp_postmeta` VALUES (911,156,'flexible_content_3_title','Services');
INSERT INTO `wp_postmeta` VALUES (912,156,'_flexible_content_3_title','field_630b29518b3e2');
INSERT INTO `wp_postmeta` VALUES (913,156,'flexible_content_3_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum maximus. Pellentesque et neque rhoncus, sagittis ex eu, tincidunt leo');
INSERT INTO `wp_postmeta` VALUES (914,156,'_flexible_content_3_headline','field_630b29638b3e3');
INSERT INTO `wp_postmeta` VALUES (915,156,'flexible_content_3_services_0_logo','132');
INSERT INTO `wp_postmeta` VALUES (916,156,'_flexible_content_3_services_0_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (917,156,'flexible_content_3_services_1_logo','133');
INSERT INTO `wp_postmeta` VALUES (918,156,'_flexible_content_3_services_1_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (919,156,'flexible_content_3_services_2_logo','134');
INSERT INTO `wp_postmeta` VALUES (920,156,'_flexible_content_3_services_2_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (921,156,'flexible_content_3_services_3_logo','135');
INSERT INTO `wp_postmeta` VALUES (922,156,'_flexible_content_3_services_3_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (923,156,'flexible_content_3_services','4');
INSERT INTO `wp_postmeta` VALUES (924,156,'_flexible_content_3_services','field_630b297c8b3e4');
INSERT INTO `wp_postmeta` VALUES (925,156,'flexible_content_2_logo','145');
INSERT INTO `wp_postmeta` VALUES (926,156,'_flexible_content_2_logo','field_630b369948254');
INSERT INTO `wp_postmeta` VALUES (927,156,'flexible_content_2_link_title','Discover Who We Serve');
INSERT INTO `wp_postmeta` VALUES (928,156,'_flexible_content_2_link_title','field_630b3872d34f9');
INSERT INTO `wp_postmeta` VALUES (929,156,'flexible_content_4_title','We create amazing digital products');
INSERT INTO `wp_postmeta` VALUES (930,156,'_flexible_content_4_title','field_630b39b92a1e2');
INSERT INTO `wp_postmeta` VALUES (931,156,'flexible_content_4_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum maximus. Pellentesque et neque rhoncus, sagittis ex eu, tincidunt leo. Donec eu placerat orci, nec congue lacus. Maecenas pellentesque orci risus, sed mollis nisl pellentesque porttitor. Donec eget dolor laoreet, sagittis orci nec, scelerisque lorem.');
INSERT INTO `wp_postmeta` VALUES (932,156,'_flexible_content_4_headline','field_630b3a0e2a1e3');
INSERT INTO `wp_postmeta` VALUES (933,156,'flexible_content_4_logo','155');
INSERT INTO `wp_postmeta` VALUES (934,156,'_flexible_content_4_logo','field_630b3a202a1e4');
INSERT INTO `wp_postmeta` VALUES (935,156,'flexible_content_4_link','https://www.abcsoftwarecompany.com/');
INSERT INTO `wp_postmeta` VALUES (936,156,'_flexible_content_4_link','field_630b3a302a1e5');
INSERT INTO `wp_postmeta` VALUES (937,156,'flexible_content_4_link_title','Work with us');
INSERT INTO `wp_postmeta` VALUES (938,156,'_flexible_content_4_link_title','field_630b3a3b2a1e6');
INSERT INTO `wp_postmeta` VALUES (939,90,'_wp_old_date','2022-08-19');
INSERT INTO `wp_postmeta` VALUES (940,91,'_wp_old_date','2022-08-19');
INSERT INTO `wp_postmeta` VALUES (941,92,'_wp_old_date','2022-08-19');
INSERT INTO `wp_postmeta` VALUES (942,93,'_wp_old_date','2022-08-19');
INSERT INTO `wp_postmeta` VALUES (943,88,'_wp_old_date','2022-08-19');
INSERT INTO `wp_postmeta` VALUES (944,59,'_wp_old_date','2022-08-19');
INSERT INTO `wp_postmeta` VALUES (945,157,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (946,157,'_edit_lock','1661730219:1');
INSERT INTO `wp_postmeta` VALUES (947,157,'_wp_page_template','default');
INSERT INTO `wp_postmeta` VALUES (948,157,'flexible_content','');
INSERT INTO `wp_postmeta` VALUES (949,157,'_flexible_content','field_63004ae978f3c');
INSERT INTO `wp_postmeta` VALUES (950,158,'flexible_content','');
INSERT INTO `wp_postmeta` VALUES (951,158,'_flexible_content','field_63004ae978f3c');
INSERT INTO `wp_postmeta` VALUES (952,157,'inline_featured_image','0');
INSERT INTO `wp_postmeta` VALUES (953,168,'_form','<label> Your name\n    [text* your-name] </label>\n\n<label> Your email\n    [email* your-email] </label>\n\n<label> Subject\n    [text* your-subject] </label>\n\n<label> Your message (optional)\n    [textarea your-message] </label>\n\n[submit \"Submit\"]');
INSERT INTO `wp_postmeta` VALUES (954,168,'_mail','a:8:{s:7:\"subject\";s:30:\"[_site_title] \"[your-subject]\"\";s:6:\"sender\";s:48:\"[_site_title] <wordpress@phamthiutlinhcom.local>\";s:4:\"body\";s:163:\"From: [your-name] <[your-email]>\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on [_site_title] ([_site_url])\";s:9:\"recipient\";s:19:\"[_site_admin_email]\";s:18:\"additional_headers\";s:22:\"Reply-To: [your-email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";i:0;s:13:\"exclude_blank\";i:0;}');
INSERT INTO `wp_postmeta` VALUES (955,168,'_mail_2','a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:30:\"[_site_title] \"[your-subject]\"\";s:6:\"sender\";s:48:\"[_site_title] <wordpress@phamthiutlinhcom.local>\";s:4:\"body\";s:105:\"Message Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on [_site_title] ([_site_url])\";s:9:\"recipient\";s:12:\"[your-email]\";s:18:\"additional_headers\";s:29:\"Reply-To: [_site_admin_email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";i:0;s:13:\"exclude_blank\";i:0;}');
INSERT INTO `wp_postmeta` VALUES (956,168,'_messages','a:12:{s:12:\"mail_sent_ok\";s:45:\"Thank you for your message. It has been sent.\";s:12:\"mail_sent_ng\";s:71:\"There was an error trying to send your message. Please try again later.\";s:16:\"validation_error\";s:61:\"One or more fields have an error. Please check and try again.\";s:4:\"spam\";s:71:\"There was an error trying to send your message. Please try again later.\";s:12:\"accept_terms\";s:69:\"You must accept the terms and conditions before sending your message.\";s:16:\"invalid_required\";s:27:\"Please fill out this field.\";s:16:\"invalid_too_long\";s:32:\"This field has a too long input.\";s:17:\"invalid_too_short\";s:33:\"This field has a too short input.\";s:13:\"upload_failed\";s:46:\"There was an unknown error uploading the file.\";s:24:\"upload_file_type_invalid\";s:49:\"You are not allowed to upload files of this type.\";s:21:\"upload_file_too_large\";s:31:\"The uploaded file is too large.\";s:23:\"upload_failed_php_error\";s:38:\"There was an error uploading the file.\";}');
INSERT INTO `wp_postmeta` VALUES (957,168,'_additional_settings','');
INSERT INTO `wp_postmeta` VALUES (958,168,'_locale','en_US');
INSERT INTO `wp_postmeta` VALUES (959,157,'flexible_contact_content_0_contact_form','168');
INSERT INTO `wp_postmeta` VALUES (960,157,'_flexible_contact_content_0_contact_form','field_630b3f9e56f5b');
INSERT INTO `wp_postmeta` VALUES (963,157,'flexible_contact_content','a:2:{i:0;s:14:\"contact_banner\";i:1;s:12:\"contact_form\";}');
INSERT INTO `wp_postmeta` VALUES (964,157,'_flexible_contact_content','field_630b3f3756f43');
INSERT INTO `wp_postmeta` VALUES (965,170,'flexible_content','');
INSERT INTO `wp_postmeta` VALUES (966,170,'_flexible_content','field_63004ae978f3c');
INSERT INTO `wp_postmeta` VALUES (967,170,'flexible_contact_content_0_contact_form','168');
INSERT INTO `wp_postmeta` VALUES (968,170,'_flexible_contact_content_0_contact_form','field_630b3f9e56f5b');
INSERT INTO `wp_postmeta` VALUES (969,170,'flexible_contact_content_0_','rwrwqrwqr');
INSERT INTO `wp_postmeta` VALUES (970,170,'_flexible_contact_content_0_','field_630b4065a1106');
INSERT INTO `wp_postmeta` VALUES (971,170,'flexible_contact_content','a:1:{i:0;s:4:\"form\";}');
INSERT INTO `wp_postmeta` VALUES (972,170,'_flexible_contact_content','field_630b3f3756f43');
INSERT INTO `wp_postmeta` VALUES (981,171,'flexible_content','');
INSERT INTO `wp_postmeta` VALUES (982,171,'_flexible_content','field_63004ae978f3c');
INSERT INTO `wp_postmeta` VALUES (983,171,'flexible_contact_content_0_contact_form','168');
INSERT INTO `wp_postmeta` VALUES (984,171,'_flexible_contact_content_0_contact_form','field_630b3f9e56f5b');
INSERT INTO `wp_postmeta` VALUES (985,171,'flexible_contact_content_0_','');
INSERT INTO `wp_postmeta` VALUES (986,171,'_flexible_contact_content_0_','field_630b4065a1106');
INSERT INTO `wp_postmeta` VALUES (987,171,'flexible_contact_content','a:2:{i:0;s:4:\"form\";i:1;s:6:\"banner\";}');
INSERT INTO `wp_postmeta` VALUES (988,171,'_flexible_contact_content','field_630b3f3756f43');
INSERT INTO `wp_postmeta` VALUES (989,171,'flexible_contact_content_1_title','');
INSERT INTO `wp_postmeta` VALUES (990,171,'_flexible_contact_content_1_title','field_630b3f3756f44');
INSERT INTO `wp_postmeta` VALUES (991,171,'flexible_contact_content_1_headline','');
INSERT INTO `wp_postmeta` VALUES (992,171,'_flexible_contact_content_1_headline','field_630b3f3756f45');
INSERT INTO `wp_postmeta` VALUES (993,171,'flexible_contact_content_1_link','');
INSERT INTO `wp_postmeta` VALUES (994,171,'_flexible_contact_content_1_link','field_630b3f3756f46');
INSERT INTO `wp_postmeta` VALUES (995,171,'flexible_contact_content_1_logo','');
INSERT INTO `wp_postmeta` VALUES (996,171,'_flexible_contact_content_1_logo','field_630b3f3756f47');
INSERT INTO `wp_postmeta` VALUES (997,157,'flexible_contact_content_0_title','Get In Touch!');
INSERT INTO `wp_postmeta` VALUES (998,157,'_flexible_contact_content_0_title','field_630b3f3756f44');
INSERT INTO `wp_postmeta` VALUES (999,157,'flexible_contact_content_0_headline','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.');
INSERT INTO `wp_postmeta` VALUES (1000,157,'_flexible_contact_content_0_headline','field_630b3f3756f45');
INSERT INTO `wp_postmeta` VALUES (1001,157,'flexible_contact_content_0_link','');
INSERT INTO `wp_postmeta` VALUES (1002,157,'_flexible_contact_content_0_link','field_630b3f3756f46');
INSERT INTO `wp_postmeta` VALUES (1003,157,'flexible_contact_content_0_logo','');
INSERT INTO `wp_postmeta` VALUES (1004,157,'_flexible_contact_content_0_logo','field_630b3f3756f47');
INSERT INTO `wp_postmeta` VALUES (1009,172,'flexible_content','');
INSERT INTO `wp_postmeta` VALUES (1010,172,'_flexible_content','field_63004ae978f3c');
INSERT INTO `wp_postmeta` VALUES (1011,172,'flexible_contact_content_0_contact_form','168');
INSERT INTO `wp_postmeta` VALUES (1012,172,'_flexible_contact_content_0_contact_form','field_630b3f9e56f5b');
INSERT INTO `wp_postmeta` VALUES (1013,172,'flexible_contact_content_0_','');
INSERT INTO `wp_postmeta` VALUES (1014,172,'_flexible_contact_content_0_','field_630b4065a1106');
INSERT INTO `wp_postmeta` VALUES (1015,172,'flexible_contact_content','a:2:{i:0;s:6:\"banner\";i:1;s:12:\"contact_form\";}');
INSERT INTO `wp_postmeta` VALUES (1016,172,'_flexible_contact_content','field_630b3f3756f43');
INSERT INTO `wp_postmeta` VALUES (1017,172,'flexible_contact_content_0_title','Title');
INSERT INTO `wp_postmeta` VALUES (1018,172,'_flexible_contact_content_0_title','field_630b3f3756f44');
INSERT INTO `wp_postmeta` VALUES (1019,172,'flexible_contact_content_0_headline','');
INSERT INTO `wp_postmeta` VALUES (1020,172,'_flexible_contact_content_0_headline','field_630b3f3756f45');
INSERT INTO `wp_postmeta` VALUES (1021,172,'flexible_contact_content_0_link','');
INSERT INTO `wp_postmeta` VALUES (1022,172,'_flexible_contact_content_0_link','field_630b3f3756f46');
INSERT INTO `wp_postmeta` VALUES (1023,172,'flexible_contact_content_0_logo','');
INSERT INTO `wp_postmeta` VALUES (1024,172,'_flexible_contact_content_0_logo','field_630b3f3756f47');
INSERT INTO `wp_postmeta` VALUES (1025,172,'flexible_contact_content_1_form','168');
INSERT INTO `wp_postmeta` VALUES (1026,172,'_flexible_contact_content_1_form','field_630b3f9e56f5b');
INSERT INTO `wp_postmeta` VALUES (1027,172,'flexible_contact_content_1_','fasfasfasfasfas');
INSERT INTO `wp_postmeta` VALUES (1028,172,'_flexible_contact_content_1_','field_630b4065a1106');
INSERT INTO `wp_postmeta` VALUES (1029,177,'_wp_attached_file','2022/08/article-banner-3.png');
INSERT INTO `wp_postmeta` VALUES (1030,177,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:468;s:6:\"height\";i:400;s:4:\"file\";s:28:\"2022/08/article-banner-3.png\";s:8:\"filesize\";i:102181;s:5:\"sizes\";a:2:{s:6:\"medium\";a:5:{s:4:\"file\";s:28:\"article-banner-3-300x256.png\";s:5:\"width\";i:300;s:6:\"height\";i:256;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:124971;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:28:\"article-banner-3-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:42161;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (1031,178,'_wp_attached_file','2022/08/article-banner-4.png');
INSERT INTO `wp_postmeta` VALUES (1032,178,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:468;s:6:\"height\";i:400;s:4:\"file\";s:28:\"2022/08/article-banner-4.png\";s:8:\"filesize\";i:57652;s:5:\"sizes\";a:2:{s:6:\"medium\";a:5:{s:4:\"file\";s:28:\"article-banner-4-300x256.png\";s:5:\"width\";i:300;s:6:\"height\";i:256;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:64826;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:28:\"article-banner-4-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:21909;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (1033,179,'_wp_attached_file','2022/08/article-banner-5.png');
INSERT INTO `wp_postmeta` VALUES (1034,179,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:906;s:6:\"height\";i:400;s:4:\"file\";s:28:\"2022/08/article-banner-5.png\";s:8:\"filesize\";i:123099;s:5:\"sizes\";a:3:{s:6:\"medium\";a:5:{s:4:\"file\";s:28:\"article-banner-5-300x132.png\";s:5:\"width\";i:300;s:6:\"height\";i:132;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:48680;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:28:\"article-banner-5-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:30623;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:28:\"article-banner-5-768x339.png\";s:5:\"width\";i:768;s:6:\"height\";i:339;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:278542;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (1035,180,'_wp_attached_file','2022/08/article-detail.jpg');
INSERT INTO `wp_postmeta` VALUES (1036,180,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:900;s:6:\"height\";i:390;s:4:\"file\";s:26:\"2022/08/article-detail.jpg\";s:8:\"filesize\";i:329288;s:5:\"sizes\";a:3:{s:6:\"medium\";a:5:{s:4:\"file\";s:26:\"article-detail-300x130.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:130;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:12096;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:26:\"article-detail-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:6954;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:26:\"article-detail-768x333.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:333;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:51880;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (1037,181,'_wp_attached_file','2022/08/article-represent-face.png');
INSERT INTO `wp_postmeta` VALUES (1038,181,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:110;s:6:\"height\";i:110;s:4:\"file\";s:34:\"2022/08/article-represent-face.png\";s:8:\"filesize\";i:17213;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (1039,182,'_wp_attached_file','2022/08/article-banner-1.png');
INSERT INTO `wp_postmeta` VALUES (1040,182,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:906;s:6:\"height\";i:400;s:4:\"file\";s:28:\"2022/08/article-banner-1.png\";s:8:\"filesize\";i:198134;s:5:\"sizes\";a:3:{s:6:\"medium\";a:5:{s:4:\"file\";s:28:\"article-banner-1-300x132.png\";s:5:\"width\";i:300;s:6:\"height\";i:132;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:62872;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:28:\"article-banner-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:35352;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:28:\"article-banner-1-768x339.png\";s:5:\"width\";i:768;s:6:\"height\";i:339;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:360795;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (1041,183,'_wp_attached_file','2022/08/article-banner-2.png');
INSERT INTO `wp_postmeta` VALUES (1042,183,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:710;s:6:\"height\";i:400;s:4:\"file\";s:28:\"2022/08/article-banner-2.png\";s:8:\"filesize\";i:165164;s:5:\"sizes\";a:2:{s:6:\"medium\";a:5:{s:4:\"file\";s:28:\"article-banner-2-300x169.png\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:65385;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:28:\"article-banner-2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:30378;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (1043,184,'_wp_attached_file','2022/08/detail-banner.jpg');
INSERT INTO `wp_postmeta` VALUES (1044,184,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1920;s:6:\"height\";i:1281;s:4:\"file\";s:25:\"2022/08/detail-banner.jpg\";s:8:\"filesize\";i:207775;s:5:\"sizes\";a:5:{s:6:\"medium\";a:5:{s:4:\"file\";s:25:\"detail-banner-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:14335;}s:5:\"large\";a:5:{s:4:\"file\";s:26:\"detail-banner-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:92961;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:25:\"detail-banner-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:6836;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:25:\"detail-banner-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:58874;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:27:\"detail-banner-1536x1025.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1025;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:178411;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (1045,185,'_wp_attached_file','2022/08/contact-banner.jpg');
INSERT INTO `wp_postmeta` VALUES (1046,185,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1920;s:6:\"height\";i:1280;s:4:\"file\";s:26:\"2022/08/contact-banner.jpg\";s:8:\"filesize\";i:136381;s:5:\"sizes\";a:5:{s:6:\"medium\";a:5:{s:4:\"file\";s:26:\"contact-banner-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:9725;}s:5:\"large\";a:5:{s:4:\"file\";s:27:\"contact-banner-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:59952;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:26:\"contact-banner-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4880;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:26:\"contact-banner-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:37980;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:28:\"contact-banner-1536x1024.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:117270;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (1047,186,'_wp_attached_file','2022/08/footer-logo.svg');
INSERT INTO `wp_postmeta` VALUES (1048,186,'_wp_attachment_metadata','a:4:{s:5:\"width\";i:246;s:6:\"height\";i:118;s:4:\"file\";s:15:\"footer-logo.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";d:72;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"footer-logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";d:144;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"footer-logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";d:369;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"footer-logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";d:492;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"footer-logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"footer-logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"footer-logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}');
INSERT INTO `wp_postmeta` VALUES (1049,187,'_wp_attached_file','2022/08/article-banner-4-1.png');
INSERT INTO `wp_postmeta` VALUES (1050,187,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:468;s:6:\"height\";i:400;s:4:\"file\";s:30:\"2022/08/article-banner-4-1.png\";s:8:\"filesize\";i:57652;s:5:\"sizes\";a:2:{s:6:\"medium\";a:5:{s:4:\"file\";s:30:\"article-banner-4-1-300x256.png\";s:5:\"width\";i:300;s:6:\"height\";i:256;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:64826;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:30:\"article-banner-4-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:21909;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (1051,188,'_wp_attached_file','2022/08/article-banner-5-1.png');
INSERT INTO `wp_postmeta` VALUES (1052,188,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:906;s:6:\"height\";i:400;s:4:\"file\";s:30:\"2022/08/article-banner-5-1.png\";s:8:\"filesize\";i:123099;s:5:\"sizes\";a:3:{s:6:\"medium\";a:5:{s:4:\"file\";s:30:\"article-banner-5-1-300x132.png\";s:5:\"width\";i:300;s:6:\"height\";i:132;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:48680;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:30:\"article-banner-5-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:30623;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:30:\"article-banner-5-1-768x339.png\";s:5:\"width\";i:768;s:6:\"height\";i:339;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:278542;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (1053,189,'_wp_attached_file','2022/08/article-detail-1.jpg');
INSERT INTO `wp_postmeta` VALUES (1054,189,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:900;s:6:\"height\";i:390;s:4:\"file\";s:28:\"2022/08/article-detail-1.jpg\";s:8:\"filesize\";i:329288;s:5:\"sizes\";a:3:{s:6:\"medium\";a:5:{s:4:\"file\";s:28:\"article-detail-1-300x130.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:130;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:12096;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:28:\"article-detail-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:6954;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:28:\"article-detail-1-768x333.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:333;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:51880;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (1055,190,'_wp_attached_file','2022/08/article-represent-face-1.png');
INSERT INTO `wp_postmeta` VALUES (1056,190,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:110;s:6:\"height\";i:110;s:4:\"file\";s:36:\"2022/08/article-represent-face-1.png\";s:8:\"filesize\";i:17213;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (1057,191,'_wp_attached_file','2022/08/banner.png');
INSERT INTO `wp_postmeta` VALUES (1058,191,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1728;s:6:\"height\";i:650;s:4:\"file\";s:18:\"2022/08/banner.png\";s:8:\"filesize\";i:739910;s:5:\"sizes\";a:5:{s:6:\"medium\";a:5:{s:4:\"file\";s:18:\"banner-300x113.png\";s:5:\"width\";i:300;s:6:\"height\";i:113;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:22560;}s:5:\"large\";a:5:{s:4:\"file\";s:19:\"banner-1024x385.png\";s:5:\"width\";i:1024;s:6:\"height\";i:385;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:215516;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:18:\"banner-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:15104;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:18:\"banner-768x289.png\";s:5:\"width\";i:768;s:6:\"height\";i:289;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:125066;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:19:\"banner-1536x578.png\";s:5:\"width\";i:1536;s:6:\"height\";i:578;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:468626;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (1059,192,'_wp_attached_file','2022/08/bg-who-we-serve.png');
INSERT INTO `wp_postmeta` VALUES (1060,192,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1728;s:6:\"height\";i:531;s:4:\"file\";s:27:\"2022/08/bg-who-we-serve.png\";s:8:\"filesize\";i:1190605;s:5:\"sizes\";a:5:{s:6:\"medium\";a:5:{s:4:\"file\";s:26:\"bg-who-we-serve-300x92.png\";s:5:\"width\";i:300;s:6:\"height\";i:92;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:43400;}s:5:\"large\";a:5:{s:4:\"file\";s:28:\"bg-who-we-serve-1024x315.png\";s:5:\"width\";i:1024;s:6:\"height\";i:315;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:377664;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:27:\"bg-who-we-serve-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:33947;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:27:\"bg-who-we-serve-768x236.png\";s:5:\"width\";i:768;s:6:\"height\";i:236;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:224027;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:28:\"bg-who-we-serve-1536x472.png\";s:5:\"width\";i:1536;s:6:\"height\";i:472;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:806693;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (1061,193,'_wp_attached_file','2022/08/btn-discover-who-we-serve-1.svg');
INSERT INTO `wp_postmeta` VALUES (1062,193,'_wp_attachment_metadata','a:4:{s:5:\"width\";i:436;s:6:\"height\";i:423;s:4:\"file\";s:31:\"btn-discover-who-we-serve-1.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";d:146;s:4:\"crop\";b:0;s:4:\"file\";s:31:\"btn-discover-who-we-serve-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";d:291;s:4:\"crop\";b:0;s:4:\"file\";s:31:\"btn-discover-who-we-serve-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";d:746;s:4:\"crop\";b:0;s:4:\"file\";s:31:\"btn-discover-who-we-serve-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";d:994;s:4:\"crop\";b:0;s:4:\"file\";s:31:\"btn-discover-who-we-serve-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:31:\"btn-discover-who-we-serve-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:31:\"btn-discover-who-we-serve-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}');
INSERT INTO `wp_postmeta` VALUES (1063,194,'_wp_attached_file','2022/08/company-1-1.svg');
INSERT INTO `wp_postmeta` VALUES (1064,194,'_wp_attachment_metadata','a:4:{s:5:\"width\";i:83;s:6:\"height\";i:83;s:4:\"file\";s:15:\"company-1-1.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";d:150;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"company-1-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";d:300;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"company-1-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";d:768;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"company-1-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";d:1024;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"company-1-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"company-1-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"company-1-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}');
INSERT INTO `wp_postmeta` VALUES (1065,195,'_wp_attached_file','2022/08/company-2-1.svg');
INSERT INTO `wp_postmeta` VALUES (1066,195,'_wp_attachment_metadata','a:4:{s:5:\"width\";i:84;s:6:\"height\";i:84;s:4:\"file\";s:15:\"company-2-1.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";d:150;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"company-2-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";d:300;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"company-2-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";d:768;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"company-2-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";d:1024;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"company-2-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"company-2-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"company-2-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}');
INSERT INTO `wp_postmeta` VALUES (1067,196,'_wp_attached_file','2022/08/company-3-1.svg');
INSERT INTO `wp_postmeta` VALUES (1068,196,'_wp_attachment_metadata','a:4:{s:5:\"width\";i:83;s:6:\"height\";i:83;s:4:\"file\";s:15:\"company-3-1.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";d:150;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"company-3-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";d:300;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"company-3-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";d:768;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"company-3-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";d:1024;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"company-3-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"company-3-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"company-3-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}');
INSERT INTO `wp_postmeta` VALUES (1069,197,'_wp_attached_file','2022/08/company-4-1.svg');
INSERT INTO `wp_postmeta` VALUES (1070,197,'_wp_attachment_metadata','a:4:{s:5:\"width\";i:83;s:6:\"height\";i:83;s:4:\"file\";s:15:\"company-4-1.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";d:150;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"company-4-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";d:300;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"company-4-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";d:768;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"company-4-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";d:1024;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"company-4-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"company-4-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"company-4-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}');
INSERT INTO `wp_postmeta` VALUES (1071,198,'_wp_attached_file','2022/08/company-5-1.svg');
INSERT INTO `wp_postmeta` VALUES (1072,198,'_wp_attachment_metadata','a:4:{s:5:\"width\";i:83;s:6:\"height\";i:83;s:4:\"file\";s:15:\"company-5-1.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";d:150;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"company-5-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";d:300;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"company-5-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";d:768;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"company-5-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";d:1024;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"company-5-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"company-5-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"company-5-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}');
INSERT INTO `wp_postmeta` VALUES (1073,199,'_wp_attached_file','2022/08/company-6-1.svg');
INSERT INTO `wp_postmeta` VALUES (1074,199,'_wp_attachment_metadata','a:4:{s:5:\"width\";i:83;s:6:\"height\";i:83;s:4:\"file\";s:15:\"company-6-1.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";d:150;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"company-6-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";d:300;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"company-6-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";d:768;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"company-6-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";d:1024;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"company-6-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"company-6-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"company-6-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}');
INSERT INTO `wp_postmeta` VALUES (1075,200,'_wp_attached_file','2022/08/contact-banner-1.jpg');
INSERT INTO `wp_postmeta` VALUES (1076,200,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1920;s:6:\"height\";i:1280;s:4:\"file\";s:28:\"2022/08/contact-banner-1.jpg\";s:8:\"filesize\";i:136381;s:5:\"sizes\";a:5:{s:6:\"medium\";a:5:{s:4:\"file\";s:28:\"contact-banner-1-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:9725;}s:5:\"large\";a:5:{s:4:\"file\";s:29:\"contact-banner-1-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:59952;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:28:\"contact-banner-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4880;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:28:\"contact-banner-1-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:37980;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:30:\"contact-banner-1-1536x1024.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:117270;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (1077,201,'_wp_attached_file','2022/08/contact-email-logo.svg');
INSERT INTO `wp_postmeta` VALUES (1078,201,'_wp_attachment_metadata','a:4:{s:5:\"width\";i:16;s:6:\"height\";i:13;s:4:\"file\";s:22:\"contact-email-logo.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";d:122;s:4:\"crop\";b:0;s:4:\"file\";s:22:\"contact-email-logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";d:244;s:4:\"crop\";b:0;s:4:\"file\";s:22:\"contact-email-logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";d:624;s:4:\"crop\";b:0;s:4:\"file\";s:22:\"contact-email-logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";d:833;s:4:\"crop\";b:0;s:4:\"file\";s:22:\"contact-email-logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:22:\"contact-email-logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:22:\"contact-email-logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}');
INSERT INTO `wp_postmeta` VALUES (1079,202,'_wp_attached_file','2022/08/contact-human-logo.svg');
INSERT INTO `wp_postmeta` VALUES (1080,202,'_wp_attachment_metadata','a:4:{s:5:\"width\";i:14;s:6:\"height\";i:16;s:4:\"file\";s:22:\"contact-human-logo.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";d:171;s:4:\"crop\";b:0;s:4:\"file\";s:22:\"contact-human-logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";d:342;s:4:\"crop\";b:0;s:4:\"file\";s:22:\"contact-human-logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";d:876;s:4:\"crop\";b:0;s:4:\"file\";s:22:\"contact-human-logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";d:1167;s:4:\"crop\";b:0;s:4:\"file\";s:22:\"contact-human-logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:22:\"contact-human-logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:22:\"contact-human-logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}');
INSERT INTO `wp_postmeta` VALUES (1081,203,'_wp_attached_file','2022/08/contact-phone-logo.svg');
INSERT INTO `wp_postmeta` VALUES (1082,203,'_wp_attachment_metadata','a:4:{s:5:\"width\";i:16;s:6:\"height\";i:16;s:4:\"file\";s:22:\"contact-phone-logo.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";d:150;s:4:\"crop\";b:0;s:4:\"file\";s:22:\"contact-phone-logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";d:300;s:4:\"crop\";b:0;s:4:\"file\";s:22:\"contact-phone-logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";d:768;s:4:\"crop\";b:0;s:4:\"file\";s:22:\"contact-phone-logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";d:1024;s:4:\"crop\";b:0;s:4:\"file\";s:22:\"contact-phone-logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:22:\"contact-phone-logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:22:\"contact-phone-logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}');
INSERT INTO `wp_postmeta` VALUES (1083,204,'_wp_attached_file','2022/08/detail-banner-1.jpg');
INSERT INTO `wp_postmeta` VALUES (1084,204,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1920;s:6:\"height\";i:1281;s:4:\"file\";s:27:\"2022/08/detail-banner-1.jpg\";s:8:\"filesize\";i:207775;s:5:\"sizes\";a:5:{s:6:\"medium\";a:5:{s:4:\"file\";s:27:\"detail-banner-1-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:14335;}s:5:\"large\";a:5:{s:4:\"file\";s:28:\"detail-banner-1-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:92961;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:27:\"detail-banner-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:6836;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:27:\"detail-banner-1-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:58874;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:29:\"detail-banner-1-1536x1025.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1025;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:178411;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (1085,205,'_wp_attached_file','2022/08/footer-logo-1.svg');
INSERT INTO `wp_postmeta` VALUES (1086,205,'_wp_attachment_metadata','a:4:{s:5:\"width\";i:246;s:6:\"height\";i:118;s:4:\"file\";s:17:\"footer-logo-1.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";d:72;s:4:\"crop\";b:0;s:4:\"file\";s:17:\"footer-logo-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";d:144;s:4:\"crop\";b:0;s:4:\"file\";s:17:\"footer-logo-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";d:369;s:4:\"crop\";b:0;s:4:\"file\";s:17:\"footer-logo-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";d:492;s:4:\"crop\";b:0;s:4:\"file\";s:17:\"footer-logo-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:17:\"footer-logo-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:17:\"footer-logo-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}');
INSERT INTO `wp_postmeta` VALUES (1087,206,'_wp_attached_file','2022/08/icon-arrow-right.svg');
INSERT INTO `wp_postmeta` VALUES (1088,206,'_wp_attachment_metadata','a:4:{s:5:\"width\";i:30;s:6:\"height\";i:31;s:4:\"file\";s:20:\"icon-arrow-right.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";d:155;s:4:\"crop\";b:0;s:4:\"file\";s:20:\"icon-arrow-right.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";d:309;s:4:\"crop\";b:0;s:4:\"file\";s:20:\"icon-arrow-right.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";d:791;s:4:\"crop\";b:0;s:4:\"file\";s:20:\"icon-arrow-right.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";d:1055;s:4:\"crop\";b:0;s:4:\"file\";s:20:\"icon-arrow-right.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:20:\"icon-arrow-right.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:20:\"icon-arrow-right.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}');
INSERT INTO `wp_postmeta` VALUES (1089,207,'_wp_attached_file','2022/08/logo.svg');
INSERT INTO `wp_postmeta` VALUES (1090,207,'_wp_attachment_metadata','a:4:{s:5:\"width\";i:735;s:6:\"height\";i:673;s:4:\"file\";s:8:\"logo.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";d:138;s:4:\"crop\";b:0;s:4:\"file\";s:8:\"logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";d:275;s:4:\"crop\";b:0;s:4:\"file\";s:8:\"logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";d:705;s:4:\"crop\";b:0;s:4:\"file\";s:8:\"logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";d:939;s:4:\"crop\";b:0;s:4:\"file\";s:8:\"logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:8:\"logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:8:\"logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}');
INSERT INTO `wp_postmeta` VALUES (1091,208,'_wp_attached_file','2022/08/service-1-1.svg');
INSERT INTO `wp_postmeta` VALUES (1092,208,'_wp_attachment_metadata','a:4:{s:5:\"width\";i:252;s:6:\"height\";i:253;s:4:\"file\";s:15:\"service-1-1.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";d:150;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"service-1-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";d:300;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"service-1-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";d:768;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"service-1-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";d:1024;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"service-1-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"service-1-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"service-1-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}');
INSERT INTO `wp_postmeta` VALUES (1093,209,'_wp_attached_file','2022/08/service-2-1.svg');
INSERT INTO `wp_postmeta` VALUES (1094,209,'_wp_attachment_metadata','a:4:{s:5:\"width\";i:252;s:6:\"height\";i:253;s:4:\"file\";s:15:\"service-2-1.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";d:150;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"service-2-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";d:300;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"service-2-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";d:768;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"service-2-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";d:1024;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"service-2-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"service-2-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"service-2-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}');
INSERT INTO `wp_postmeta` VALUES (1095,210,'_wp_attached_file','2022/08/service-3-1.svg');
INSERT INTO `wp_postmeta` VALUES (1096,210,'_wp_attachment_metadata','a:4:{s:5:\"width\";i:252;s:6:\"height\";i:254;s:4:\"file\";s:15:\"service-3-1.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";d:152;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"service-3-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";d:303;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"service-3-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";d:776;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"service-3-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";d:1034;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"service-3-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"service-3-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"service-3-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}');
INSERT INTO `wp_postmeta` VALUES (1097,211,'_wp_attached_file','2022/08/service-4-1.svg');
INSERT INTO `wp_postmeta` VALUES (1098,211,'_wp_attachment_metadata','a:4:{s:5:\"width\";i:252;s:6:\"height\";i:253;s:4:\"file\";s:15:\"service-4-1.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";d:150;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"service-4-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";d:300;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"service-4-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";d:768;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"service-4-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";d:1024;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"service-4-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"service-4-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:15:\"service-4-1.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}');
INSERT INTO `wp_postmeta` VALUES (1099,212,'_wp_attached_file','2022/08/services-logo.svg');
INSERT INTO `wp_postmeta` VALUES (1100,212,'_wp_attachment_metadata','a:4:{s:5:\"width\";i:44;s:6:\"height\";i:24;s:4:\"file\";s:17:\"services-logo.svg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:5:{s:5:\"width\";s:3:\"150\";s:6:\"height\";d:82;s:4:\"crop\";b:0;s:4:\"file\";s:17:\"services-logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";s:3:\"300\";s:6:\"height\";d:164;s:4:\"crop\";b:0;s:4:\"file\";s:17:\"services-logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";s:3:\"768\";s:6:\"height\";d:420;s:4:\"crop\";b:0;s:4:\"file\";s:17:\"services-logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";d:560;s:4:\"crop\";b:0;s:4:\"file\";s:17:\"services-logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:17:\"services-logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";b:0;s:6:\"height\";d:0;s:4:\"crop\";b:0;s:4:\"file\";s:17:\"services-logo.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}');
INSERT INTO `wp_postmeta` VALUES (1101,213,'_wp_attached_file','2022/08/work-with-us-1.png');
INSERT INTO `wp_postmeta` VALUES (1102,213,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:540;s:6:\"height\";i:610;s:4:\"file\";s:26:\"2022/08/work-with-us-1.png\";s:8:\"filesize\";i:415446;s:5:\"sizes\";a:2:{s:6:\"medium\";a:5:{s:4:\"file\";s:26:\"work-with-us-1-266x300.png\";s:5:\"width\";i:266;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:108996;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:26:\"work-with-us-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:36324;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (1103,214,'_wp_attached_file','2022/08/article-banner-1-1.png');
INSERT INTO `wp_postmeta` VALUES (1104,214,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:906;s:6:\"height\";i:400;s:4:\"file\";s:30:\"2022/08/article-banner-1-1.png\";s:8:\"filesize\";i:198134;s:5:\"sizes\";a:3:{s:6:\"medium\";a:5:{s:4:\"file\";s:30:\"article-banner-1-1-300x132.png\";s:5:\"width\";i:300;s:6:\"height\";i:132;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:62872;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:30:\"article-banner-1-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:35352;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:30:\"article-banner-1-1-768x339.png\";s:5:\"width\";i:768;s:6:\"height\";i:339;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:360795;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (1105,215,'_wp_attached_file','2022/08/article-banner-2-1.png');
INSERT INTO `wp_postmeta` VALUES (1106,215,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:710;s:6:\"height\";i:400;s:4:\"file\";s:30:\"2022/08/article-banner-2-1.png\";s:8:\"filesize\";i:165164;s:5:\"sizes\";a:2:{s:6:\"medium\";a:5:{s:4:\"file\";s:30:\"article-banner-2-1-300x169.png\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:65385;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:30:\"article-banner-2-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:30378;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (1107,216,'_wp_attached_file','2022/08/article-banner-3-1.png');
INSERT INTO `wp_postmeta` VALUES (1108,216,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:468;s:6:\"height\";i:400;s:4:\"file\";s:30:\"2022/08/article-banner-3-1.png\";s:8:\"filesize\";i:102181;s:5:\"sizes\";a:2:{s:6:\"medium\";a:5:{s:4:\"file\";s:30:\"article-banner-3-1-300x256.png\";s:5:\"width\";i:300;s:6:\"height\";i:256;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:124971;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:30:\"article-banner-3-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:42161;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (1109,28,'flexible_content_5_title','Articles');
INSERT INTO `wp_postmeta` VALUES (1110,28,'_flexible_content_5_title','field_630b5eae1a8fc');
INSERT INTO `wp_postmeta` VALUES (1111,28,'flexible_content_5_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum maximus. Pellentesque et neque rhoncus, sagittis ex eu, tincidunt leo. Donec eu placerat orci, nec congue lacus. Maecenas pellentesque orci risus, sed mollis nisl pellentesque porttitor. Donec eget dolor laoreet, sagittis orci nec, scelerisque lorem.');
INSERT INTO `wp_postmeta` VALUES (1112,28,'_flexible_content_5_headline','field_630b5eb41a8fd');
INSERT INTO `wp_postmeta` VALUES (1113,28,'flexible_content_5_posts_0_post','182');
INSERT INTO `wp_postmeta` VALUES (1114,28,'_flexible_content_5_posts_0_post','field_630b5ec91a8ff');
INSERT INTO `wp_postmeta` VALUES (1115,28,'flexible_content_5_posts_1_post','215');
INSERT INTO `wp_postmeta` VALUES (1116,28,'_flexible_content_5_posts_1_post','field_630b5ec91a8ff');
INSERT INTO `wp_postmeta` VALUES (1117,28,'flexible_content_5_posts_2_post','216');
INSERT INTO `wp_postmeta` VALUES (1118,28,'_flexible_content_5_posts_2_post','field_630b5ec91a8ff');
INSERT INTO `wp_postmeta` VALUES (1119,28,'flexible_content_5_posts_3_post','187');
INSERT INTO `wp_postmeta` VALUES (1120,28,'_flexible_content_5_posts_3_post','field_630b5ec91a8ff');
INSERT INTO `wp_postmeta` VALUES (1121,28,'flexible_content_5_posts_4_post','188');
INSERT INTO `wp_postmeta` VALUES (1122,28,'_flexible_content_5_posts_4_post','field_630b5ec91a8ff');
INSERT INTO `wp_postmeta` VALUES (1123,28,'flexible_content_5_posts_5_post','184');
INSERT INTO `wp_postmeta` VALUES (1124,28,'_flexible_content_5_posts_5_post','field_630b5ec91a8ff');
INSERT INTO `wp_postmeta` VALUES (1125,28,'flexible_content_5_posts_6_post','187');
INSERT INTO `wp_postmeta` VALUES (1126,28,'_flexible_content_5_posts_6_post','field_630b5ec91a8ff');
INSERT INTO `wp_postmeta` VALUES (1127,28,'flexible_content_5_posts','7');
INSERT INTO `wp_postmeta` VALUES (1128,28,'_flexible_content_5_posts','field_630b5ec01a8fe');
INSERT INTO `wp_postmeta` VALUES (1129,28,'flexible_contact_content','');
INSERT INTO `wp_postmeta` VALUES (1130,28,'_flexible_contact_content','field_630b3f3756f43');
INSERT INTO `wp_postmeta` VALUES (1131,217,'flexible_content_0_title','ABC Software Solutions');
INSERT INTO `wp_postmeta` VALUES (1132,217,'_flexible_content_0_title','field_63004ba19c354');
INSERT INTO `wp_postmeta` VALUES (1133,217,'flexible_content_0_headine','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.                     Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.');
INSERT INTO `wp_postmeta` VALUES (1134,217,'_flexible_content_0_headine','field_63004c3f9c355');
INSERT INTO `wp_postmeta` VALUES (1135,217,'flexible_content_0_link','htttps://google.com');
INSERT INTO `wp_postmeta` VALUES (1136,217,'_flexible_content_0_link','field_63004c4b9c356');
INSERT INTO `wp_postmeta` VALUES (1137,217,'flexible_content_0_logo','112');
INSERT INTO `wp_postmeta` VALUES (1138,217,'_flexible_content_0_logo','field_63004c5c9c357');
INSERT INTO `wp_postmeta` VALUES (1139,217,'flexible_content','a:6:{i:0;s:6:\"banner\";i:1;s:14:\"who_trusted_us\";i:2;s:12:\"who_we_serve\";i:3;s:8:\"services\";i:4;s:12:\"work_with_us\";i:5;s:8:\"articles\";}');
INSERT INTO `wp_postmeta` VALUES (1140,217,'_flexible_content','field_63004ae978f3c');
INSERT INTO `wp_postmeta` VALUES (1141,217,'flexible_content_0_headline','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.  Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.');
INSERT INTO `wp_postmeta` VALUES (1142,217,'_flexible_content_0_headline','field_63004c3f9c355');
INSERT INTO `wp_postmeta` VALUES (1143,217,'flexible_content_1_title','Who Trusted Us');
INSERT INTO `wp_postmeta` VALUES (1144,217,'_flexible_content_1_title','field_630b24fc6d745');
INSERT INTO `wp_postmeta` VALUES (1145,217,'flexible_content_1_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum.');
INSERT INTO `wp_postmeta` VALUES (1146,217,'_flexible_content_1_headline','field_630b25016d746');
INSERT INTO `wp_postmeta` VALUES (1147,217,'flexible_content_1_partner_0_logo','121');
INSERT INTO `wp_postmeta` VALUES (1148,217,'_flexible_content_1_partner_0_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (1149,217,'flexible_content_1_partner_1_logo','122');
INSERT INTO `wp_postmeta` VALUES (1150,217,'_flexible_content_1_partner_1_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (1151,217,'flexible_content_1_partner_2_logo','123');
INSERT INTO `wp_postmeta` VALUES (1152,217,'_flexible_content_1_partner_2_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (1153,217,'flexible_content_1_partner_3_logo','124');
INSERT INTO `wp_postmeta` VALUES (1154,217,'_flexible_content_1_partner_3_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (1155,217,'flexible_content_1_partner_4_logo','125');
INSERT INTO `wp_postmeta` VALUES (1156,217,'_flexible_content_1_partner_4_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (1157,217,'flexible_content_1_partner_5_logo','126');
INSERT INTO `wp_postmeta` VALUES (1158,217,'_flexible_content_1_partner_5_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (1159,217,'flexible_content_1_partner','6');
INSERT INTO `wp_postmeta` VALUES (1160,217,'_flexible_content_1_partner','field_630b250d6d747');
INSERT INTO `wp_postmeta` VALUES (1161,217,'flexible_content_2_title','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.');
INSERT INTO `wp_postmeta` VALUES (1162,217,'_flexible_content_2_title','field_630b33abc7a8e');
INSERT INTO `wp_postmeta` VALUES (1163,217,'flexible_content_2_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum maximus. Pellentesque et neque rhoncus, sagittis ex eu, tincidunt leo. Donec eu placerat orci, nec congue lacus. Maecenas pellentesque orci risus, sed mollis nisl pellentesque porttitor. Donec eget dolor laoreet, sagittis orci nec, scelerisque lorem.');
INSERT INTO `wp_postmeta` VALUES (1164,217,'_flexible_content_2_headline','field_630b33bdc7a8f');
INSERT INTO `wp_postmeta` VALUES (1165,217,'flexible_content_2_link','https://www.abcsoftwarecompany.com/');
INSERT INTO `wp_postmeta` VALUES (1166,217,'_flexible_content_2_link','field_630b33efc7a90');
INSERT INTO `wp_postmeta` VALUES (1167,217,'flexible_content_3_title','Services');
INSERT INTO `wp_postmeta` VALUES (1168,217,'_flexible_content_3_title','field_630b29518b3e2');
INSERT INTO `wp_postmeta` VALUES (1169,217,'flexible_content_3_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum maximus. Pellentesque et neque rhoncus, sagittis ex eu, tincidunt leo');
INSERT INTO `wp_postmeta` VALUES (1170,217,'_flexible_content_3_headline','field_630b29638b3e3');
INSERT INTO `wp_postmeta` VALUES (1171,217,'flexible_content_3_services_0_logo','132');
INSERT INTO `wp_postmeta` VALUES (1172,217,'_flexible_content_3_services_0_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (1173,217,'flexible_content_3_services_1_logo','133');
INSERT INTO `wp_postmeta` VALUES (1174,217,'_flexible_content_3_services_1_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (1175,217,'flexible_content_3_services_2_logo','134');
INSERT INTO `wp_postmeta` VALUES (1176,217,'_flexible_content_3_services_2_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (1177,217,'flexible_content_3_services_3_logo','135');
INSERT INTO `wp_postmeta` VALUES (1178,217,'_flexible_content_3_services_3_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (1179,217,'flexible_content_3_services','4');
INSERT INTO `wp_postmeta` VALUES (1180,217,'_flexible_content_3_services','field_630b297c8b3e4');
INSERT INTO `wp_postmeta` VALUES (1181,217,'flexible_content_2_logo','145');
INSERT INTO `wp_postmeta` VALUES (1182,217,'_flexible_content_2_logo','field_630b369948254');
INSERT INTO `wp_postmeta` VALUES (1183,217,'flexible_content_2_link_title','Discover Who We Serve');
INSERT INTO `wp_postmeta` VALUES (1184,217,'_flexible_content_2_link_title','field_630b3872d34f9');
INSERT INTO `wp_postmeta` VALUES (1185,217,'flexible_content_4_title','We create amazing digital products');
INSERT INTO `wp_postmeta` VALUES (1186,217,'_flexible_content_4_title','field_630b39b92a1e2');
INSERT INTO `wp_postmeta` VALUES (1187,217,'flexible_content_4_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum maximus. Pellentesque et neque rhoncus, sagittis ex eu, tincidunt leo. Donec eu placerat orci, nec congue lacus. Maecenas pellentesque orci risus, sed mollis nisl pellentesque porttitor. Donec eget dolor laoreet, sagittis orci nec, scelerisque lorem.');
INSERT INTO `wp_postmeta` VALUES (1188,217,'_flexible_content_4_headline','field_630b3a0e2a1e3');
INSERT INTO `wp_postmeta` VALUES (1189,217,'flexible_content_4_logo','155');
INSERT INTO `wp_postmeta` VALUES (1190,217,'_flexible_content_4_logo','field_630b3a202a1e4');
INSERT INTO `wp_postmeta` VALUES (1191,217,'flexible_content_4_link','https://www.abcsoftwarecompany.com/');
INSERT INTO `wp_postmeta` VALUES (1192,217,'_flexible_content_4_link','field_630b3a302a1e5');
INSERT INTO `wp_postmeta` VALUES (1193,217,'flexible_content_4_link_title','Work with us');
INSERT INTO `wp_postmeta` VALUES (1194,217,'_flexible_content_4_link_title','field_630b3a3b2a1e6');
INSERT INTO `wp_postmeta` VALUES (1195,217,'flexible_content_5_title','Articles');
INSERT INTO `wp_postmeta` VALUES (1196,217,'_flexible_content_5_title','field_630b5eae1a8fc');
INSERT INTO `wp_postmeta` VALUES (1197,217,'flexible_content_5_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum maximus. Pellentesque et neque rhoncus, sagittis ex eu, tincidunt leo. Donec eu placerat orci, nec congue lacus. Maecenas pellentesque orci risus, sed mollis nisl pellentesque porttitor. Donec eget dolor laoreet, sagittis orci nec, scelerisque lorem.');
INSERT INTO `wp_postmeta` VALUES (1198,217,'_flexible_content_5_headline','field_630b5eb41a8fd');
INSERT INTO `wp_postmeta` VALUES (1199,217,'flexible_content_5_posts_0_post','182');
INSERT INTO `wp_postmeta` VALUES (1200,217,'_flexible_content_5_posts_0_post','field_630b5ec91a8ff');
INSERT INTO `wp_postmeta` VALUES (1201,217,'flexible_content_5_posts_1_post','215');
INSERT INTO `wp_postmeta` VALUES (1202,217,'_flexible_content_5_posts_1_post','field_630b5ec91a8ff');
INSERT INTO `wp_postmeta` VALUES (1203,217,'flexible_content_5_posts_2_post','216');
INSERT INTO `wp_postmeta` VALUES (1204,217,'_flexible_content_5_posts_2_post','field_630b5ec91a8ff');
INSERT INTO `wp_postmeta` VALUES (1205,217,'flexible_content_5_posts_3_post','187');
INSERT INTO `wp_postmeta` VALUES (1206,217,'_flexible_content_5_posts_3_post','field_630b5ec91a8ff');
INSERT INTO `wp_postmeta` VALUES (1207,217,'flexible_content_5_posts_4_post','188');
INSERT INTO `wp_postmeta` VALUES (1208,217,'_flexible_content_5_posts_4_post','field_630b5ec91a8ff');
INSERT INTO `wp_postmeta` VALUES (1209,217,'flexible_content_5_posts_5_post','');
INSERT INTO `wp_postmeta` VALUES (1210,217,'_flexible_content_5_posts_5_post','field_630b5ec91a8ff');
INSERT INTO `wp_postmeta` VALUES (1211,217,'flexible_content_5_posts_6_post','');
INSERT INTO `wp_postmeta` VALUES (1212,217,'_flexible_content_5_posts_6_post','field_630b5ec91a8ff');
INSERT INTO `wp_postmeta` VALUES (1213,217,'flexible_content_5_posts','7');
INSERT INTO `wp_postmeta` VALUES (1214,217,'_flexible_content_5_posts','field_630b5ec01a8fe');
INSERT INTO `wp_postmeta` VALUES (1215,217,'flexible_contact_content','');
INSERT INTO `wp_postmeta` VALUES (1216,217,'_flexible_contact_content','field_630b3f3756f43');
INSERT INTO `wp_postmeta` VALUES (1217,218,'flexible_content_0_title','ABC Software Solutions');
INSERT INTO `wp_postmeta` VALUES (1218,218,'_flexible_content_0_title','field_63004ba19c354');
INSERT INTO `wp_postmeta` VALUES (1219,218,'flexible_content_0_headine','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.                     Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.');
INSERT INTO `wp_postmeta` VALUES (1220,218,'_flexible_content_0_headine','field_63004c3f9c355');
INSERT INTO `wp_postmeta` VALUES (1221,218,'flexible_content_0_link','htttps://google.com');
INSERT INTO `wp_postmeta` VALUES (1222,218,'_flexible_content_0_link','field_63004c4b9c356');
INSERT INTO `wp_postmeta` VALUES (1223,218,'flexible_content_0_logo','112');
INSERT INTO `wp_postmeta` VALUES (1224,218,'_flexible_content_0_logo','field_63004c5c9c357');
INSERT INTO `wp_postmeta` VALUES (1225,218,'flexible_content','a:6:{i:0;s:6:\"banner\";i:1;s:14:\"who_trusted_us\";i:2;s:12:\"who_we_serve\";i:3;s:8:\"services\";i:4;s:12:\"work_with_us\";i:5;s:8:\"articles\";}');
INSERT INTO `wp_postmeta` VALUES (1226,218,'_flexible_content','field_63004ae978f3c');
INSERT INTO `wp_postmeta` VALUES (1227,218,'flexible_content_0_headline','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.  Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.');
INSERT INTO `wp_postmeta` VALUES (1228,218,'_flexible_content_0_headline','field_63004c3f9c355');
INSERT INTO `wp_postmeta` VALUES (1229,218,'flexible_content_1_title','Who Trusted Us');
INSERT INTO `wp_postmeta` VALUES (1230,218,'_flexible_content_1_title','field_630b24fc6d745');
INSERT INTO `wp_postmeta` VALUES (1231,218,'flexible_content_1_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum.');
INSERT INTO `wp_postmeta` VALUES (1232,218,'_flexible_content_1_headline','field_630b25016d746');
INSERT INTO `wp_postmeta` VALUES (1233,218,'flexible_content_1_partner_0_logo','121');
INSERT INTO `wp_postmeta` VALUES (1234,218,'_flexible_content_1_partner_0_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (1235,218,'flexible_content_1_partner_1_logo','122');
INSERT INTO `wp_postmeta` VALUES (1236,218,'_flexible_content_1_partner_1_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (1237,218,'flexible_content_1_partner_2_logo','123');
INSERT INTO `wp_postmeta` VALUES (1238,218,'_flexible_content_1_partner_2_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (1239,218,'flexible_content_1_partner_3_logo','124');
INSERT INTO `wp_postmeta` VALUES (1240,218,'_flexible_content_1_partner_3_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (1241,218,'flexible_content_1_partner_4_logo','125');
INSERT INTO `wp_postmeta` VALUES (1242,218,'_flexible_content_1_partner_4_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (1243,218,'flexible_content_1_partner_5_logo','126');
INSERT INTO `wp_postmeta` VALUES (1244,218,'_flexible_content_1_partner_5_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (1245,218,'flexible_content_1_partner','6');
INSERT INTO `wp_postmeta` VALUES (1246,218,'_flexible_content_1_partner','field_630b250d6d747');
INSERT INTO `wp_postmeta` VALUES (1247,218,'flexible_content_2_title','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.');
INSERT INTO `wp_postmeta` VALUES (1248,218,'_flexible_content_2_title','field_630b33abc7a8e');
INSERT INTO `wp_postmeta` VALUES (1249,218,'flexible_content_2_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum maximus. Pellentesque et neque rhoncus, sagittis ex eu, tincidunt leo. Donec eu placerat orci, nec congue lacus. Maecenas pellentesque orci risus, sed mollis nisl pellentesque porttitor. Donec eget dolor laoreet, sagittis orci nec, scelerisque lorem.');
INSERT INTO `wp_postmeta` VALUES (1250,218,'_flexible_content_2_headline','field_630b33bdc7a8f');
INSERT INTO `wp_postmeta` VALUES (1251,218,'flexible_content_2_link','https://www.abcsoftwarecompany.com/');
INSERT INTO `wp_postmeta` VALUES (1252,218,'_flexible_content_2_link','field_630b33efc7a90');
INSERT INTO `wp_postmeta` VALUES (1253,218,'flexible_content_3_title','Services');
INSERT INTO `wp_postmeta` VALUES (1254,218,'_flexible_content_3_title','field_630b29518b3e2');
INSERT INTO `wp_postmeta` VALUES (1255,218,'flexible_content_3_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum maximus. Pellentesque et neque rhoncus, sagittis ex eu, tincidunt leo');
INSERT INTO `wp_postmeta` VALUES (1256,218,'_flexible_content_3_headline','field_630b29638b3e3');
INSERT INTO `wp_postmeta` VALUES (1257,218,'flexible_content_3_services_0_logo','132');
INSERT INTO `wp_postmeta` VALUES (1258,218,'_flexible_content_3_services_0_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (1259,218,'flexible_content_3_services_1_logo','133');
INSERT INTO `wp_postmeta` VALUES (1260,218,'_flexible_content_3_services_1_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (1261,218,'flexible_content_3_services_2_logo','134');
INSERT INTO `wp_postmeta` VALUES (1262,218,'_flexible_content_3_services_2_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (1263,218,'flexible_content_3_services_3_logo','135');
INSERT INTO `wp_postmeta` VALUES (1264,218,'_flexible_content_3_services_3_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (1265,218,'flexible_content_3_services','4');
INSERT INTO `wp_postmeta` VALUES (1266,218,'_flexible_content_3_services','field_630b297c8b3e4');
INSERT INTO `wp_postmeta` VALUES (1267,218,'flexible_content_2_logo','145');
INSERT INTO `wp_postmeta` VALUES (1268,218,'_flexible_content_2_logo','field_630b369948254');
INSERT INTO `wp_postmeta` VALUES (1269,218,'flexible_content_2_link_title','Discover Who We Serve');
INSERT INTO `wp_postmeta` VALUES (1270,218,'_flexible_content_2_link_title','field_630b3872d34f9');
INSERT INTO `wp_postmeta` VALUES (1271,218,'flexible_content_4_title','We create amazing digital products');
INSERT INTO `wp_postmeta` VALUES (1272,218,'_flexible_content_4_title','field_630b39b92a1e2');
INSERT INTO `wp_postmeta` VALUES (1273,218,'flexible_content_4_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum maximus. Pellentesque et neque rhoncus, sagittis ex eu, tincidunt leo. Donec eu placerat orci, nec congue lacus. Maecenas pellentesque orci risus, sed mollis nisl pellentesque porttitor. Donec eget dolor laoreet, sagittis orci nec, scelerisque lorem.');
INSERT INTO `wp_postmeta` VALUES (1274,218,'_flexible_content_4_headline','field_630b3a0e2a1e3');
INSERT INTO `wp_postmeta` VALUES (1275,218,'flexible_content_4_logo','155');
INSERT INTO `wp_postmeta` VALUES (1276,218,'_flexible_content_4_logo','field_630b3a202a1e4');
INSERT INTO `wp_postmeta` VALUES (1277,218,'flexible_content_4_link','https://www.abcsoftwarecompany.com/');
INSERT INTO `wp_postmeta` VALUES (1278,218,'_flexible_content_4_link','field_630b3a302a1e5');
INSERT INTO `wp_postmeta` VALUES (1279,218,'flexible_content_4_link_title','Work with us');
INSERT INTO `wp_postmeta` VALUES (1280,218,'_flexible_content_4_link_title','field_630b3a3b2a1e6');
INSERT INTO `wp_postmeta` VALUES (1281,218,'flexible_content_5_title','Articles');
INSERT INTO `wp_postmeta` VALUES (1282,218,'_flexible_content_5_title','field_630b5eae1a8fc');
INSERT INTO `wp_postmeta` VALUES (1283,218,'flexible_content_5_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum maximus. Pellentesque et neque rhoncus, sagittis ex eu, tincidunt leo. Donec eu placerat orci, nec congue lacus. Maecenas pellentesque orci risus, sed mollis nisl pellentesque porttitor. Donec eget dolor laoreet, sagittis orci nec, scelerisque lorem.');
INSERT INTO `wp_postmeta` VALUES (1284,218,'_flexible_content_5_headline','field_630b5eb41a8fd');
INSERT INTO `wp_postmeta` VALUES (1285,218,'flexible_content_5_posts_0_post','182');
INSERT INTO `wp_postmeta` VALUES (1286,218,'_flexible_content_5_posts_0_post','field_630b5ec91a8ff');
INSERT INTO `wp_postmeta` VALUES (1287,218,'flexible_content_5_posts_1_post','215');
INSERT INTO `wp_postmeta` VALUES (1288,218,'_flexible_content_5_posts_1_post','field_630b5ec91a8ff');
INSERT INTO `wp_postmeta` VALUES (1289,218,'flexible_content_5_posts_2_post','216');
INSERT INTO `wp_postmeta` VALUES (1290,218,'_flexible_content_5_posts_2_post','field_630b5ec91a8ff');
INSERT INTO `wp_postmeta` VALUES (1291,218,'flexible_content_5_posts_3_post','187');
INSERT INTO `wp_postmeta` VALUES (1292,218,'_flexible_content_5_posts_3_post','field_630b5ec91a8ff');
INSERT INTO `wp_postmeta` VALUES (1293,218,'flexible_content_5_posts_4_post','188');
INSERT INTO `wp_postmeta` VALUES (1294,218,'_flexible_content_5_posts_4_post','field_630b5ec91a8ff');
INSERT INTO `wp_postmeta` VALUES (1295,218,'flexible_content_5_posts_5_post','184');
INSERT INTO `wp_postmeta` VALUES (1296,218,'_flexible_content_5_posts_5_post','field_630b5ec91a8ff');
INSERT INTO `wp_postmeta` VALUES (1297,218,'flexible_content_5_posts_6_post','187');
INSERT INTO `wp_postmeta` VALUES (1298,218,'_flexible_content_5_posts_6_post','field_630b5ec91a8ff');
INSERT INTO `wp_postmeta` VALUES (1299,218,'flexible_content_5_posts','7');
INSERT INTO `wp_postmeta` VALUES (1300,218,'_flexible_content_5_posts','field_630b5ec01a8fe');
INSERT INTO `wp_postmeta` VALUES (1301,218,'flexible_contact_content','');
INSERT INTO `wp_postmeta` VALUES (1302,218,'_flexible_contact_content','field_630b3f3756f43');
INSERT INTO `wp_postmeta` VALUES (1303,66,'flexible_content','');
INSERT INTO `wp_postmeta` VALUES (1304,66,'_flexible_content','field_63004ae978f3c');
INSERT INTO `wp_postmeta` VALUES (1305,66,'flexible_contact_content','');
INSERT INTO `wp_postmeta` VALUES (1306,66,'_flexible_contact_content','field_630b3f3756f43');
INSERT INTO `wp_postmeta` VALUES (1307,220,'flexible_content','');
INSERT INTO `wp_postmeta` VALUES (1308,220,'_flexible_content','field_63004ae978f3c');
INSERT INTO `wp_postmeta` VALUES (1309,220,'flexible_contact_content','');
INSERT INTO `wp_postmeta` VALUES (1310,220,'_flexible_contact_content','field_630b3f3756f43');
INSERT INTO `wp_postmeta` VALUES (1311,66,'inline_featured_image','0');
INSERT INTO `wp_postmeta` VALUES (1312,221,'flexible_content','');
INSERT INTO `wp_postmeta` VALUES (1313,221,'_flexible_content','field_63004ae978f3c');
INSERT INTO `wp_postmeta` VALUES (1314,221,'flexible_contact_content','');
INSERT INTO `wp_postmeta` VALUES (1315,221,'_flexible_contact_content','field_630b3f3756f43');
INSERT INTO `wp_postmeta` VALUES (1316,28,'flexible_content_0_banner','191');
INSERT INTO `wp_postmeta` VALUES (1317,28,'_flexible_content_0_banner','field_630bf563dbc4e');
INSERT INTO `wp_postmeta` VALUES (1318,222,'flexible_content_0_title','ABC Software Solutions');
INSERT INTO `wp_postmeta` VALUES (1319,222,'_flexible_content_0_title','field_63004ba19c354');
INSERT INTO `wp_postmeta` VALUES (1320,222,'flexible_content_0_headine','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.                     Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.');
INSERT INTO `wp_postmeta` VALUES (1321,222,'_flexible_content_0_headine','field_63004c3f9c355');
INSERT INTO `wp_postmeta` VALUES (1322,222,'flexible_content_0_link','htttps://google.com');
INSERT INTO `wp_postmeta` VALUES (1323,222,'_flexible_content_0_link','field_63004c4b9c356');
INSERT INTO `wp_postmeta` VALUES (1324,222,'flexible_content_0_logo','112');
INSERT INTO `wp_postmeta` VALUES (1325,222,'_flexible_content_0_logo','field_63004c5c9c357');
INSERT INTO `wp_postmeta` VALUES (1326,222,'flexible_content','a:6:{i:0;s:6:\"banner\";i:1;s:14:\"who_trusted_us\";i:2;s:12:\"who_we_serve\";i:3;s:8:\"services\";i:4;s:12:\"work_with_us\";i:5;s:8:\"articles\";}');
INSERT INTO `wp_postmeta` VALUES (1327,222,'_flexible_content','field_63004ae978f3c');
INSERT INTO `wp_postmeta` VALUES (1328,222,'flexible_content_0_headline','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.  Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.');
INSERT INTO `wp_postmeta` VALUES (1329,222,'_flexible_content_0_headline','field_63004c3f9c355');
INSERT INTO `wp_postmeta` VALUES (1330,222,'flexible_content_1_title','Who Trusted Us');
INSERT INTO `wp_postmeta` VALUES (1331,222,'_flexible_content_1_title','field_630b24fc6d745');
INSERT INTO `wp_postmeta` VALUES (1332,222,'flexible_content_1_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum.');
INSERT INTO `wp_postmeta` VALUES (1333,222,'_flexible_content_1_headline','field_630b25016d746');
INSERT INTO `wp_postmeta` VALUES (1334,222,'flexible_content_1_partner_0_logo','121');
INSERT INTO `wp_postmeta` VALUES (1335,222,'_flexible_content_1_partner_0_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (1336,222,'flexible_content_1_partner_1_logo','122');
INSERT INTO `wp_postmeta` VALUES (1337,222,'_flexible_content_1_partner_1_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (1338,222,'flexible_content_1_partner_2_logo','123');
INSERT INTO `wp_postmeta` VALUES (1339,222,'_flexible_content_1_partner_2_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (1340,222,'flexible_content_1_partner_3_logo','124');
INSERT INTO `wp_postmeta` VALUES (1341,222,'_flexible_content_1_partner_3_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (1342,222,'flexible_content_1_partner_4_logo','125');
INSERT INTO `wp_postmeta` VALUES (1343,222,'_flexible_content_1_partner_4_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (1344,222,'flexible_content_1_partner_5_logo','126');
INSERT INTO `wp_postmeta` VALUES (1345,222,'_flexible_content_1_partner_5_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (1346,222,'flexible_content_1_partner','6');
INSERT INTO `wp_postmeta` VALUES (1347,222,'_flexible_content_1_partner','field_630b250d6d747');
INSERT INTO `wp_postmeta` VALUES (1348,222,'flexible_content_2_title','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.');
INSERT INTO `wp_postmeta` VALUES (1349,222,'_flexible_content_2_title','field_630b33abc7a8e');
INSERT INTO `wp_postmeta` VALUES (1350,222,'flexible_content_2_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum maximus. Pellentesque et neque rhoncus, sagittis ex eu, tincidunt leo. Donec eu placerat orci, nec congue lacus. Maecenas pellentesque orci risus, sed mollis nisl pellentesque porttitor. Donec eget dolor laoreet, sagittis orci nec, scelerisque lorem.');
INSERT INTO `wp_postmeta` VALUES (1351,222,'_flexible_content_2_headline','field_630b33bdc7a8f');
INSERT INTO `wp_postmeta` VALUES (1352,222,'flexible_content_2_link','https://www.abcsoftwarecompany.com/');
INSERT INTO `wp_postmeta` VALUES (1353,222,'_flexible_content_2_link','field_630b33efc7a90');
INSERT INTO `wp_postmeta` VALUES (1354,222,'flexible_content_3_title','Services');
INSERT INTO `wp_postmeta` VALUES (1355,222,'_flexible_content_3_title','field_630b29518b3e2');
INSERT INTO `wp_postmeta` VALUES (1356,222,'flexible_content_3_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum maximus. Pellentesque et neque rhoncus, sagittis ex eu, tincidunt leo');
INSERT INTO `wp_postmeta` VALUES (1357,222,'_flexible_content_3_headline','field_630b29638b3e3');
INSERT INTO `wp_postmeta` VALUES (1358,222,'flexible_content_3_services_0_logo','132');
INSERT INTO `wp_postmeta` VALUES (1359,222,'_flexible_content_3_services_0_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (1360,222,'flexible_content_3_services_1_logo','133');
INSERT INTO `wp_postmeta` VALUES (1361,222,'_flexible_content_3_services_1_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (1362,222,'flexible_content_3_services_2_logo','134');
INSERT INTO `wp_postmeta` VALUES (1363,222,'_flexible_content_3_services_2_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (1364,222,'flexible_content_3_services_3_logo','135');
INSERT INTO `wp_postmeta` VALUES (1365,222,'_flexible_content_3_services_3_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (1366,222,'flexible_content_3_services','4');
INSERT INTO `wp_postmeta` VALUES (1367,222,'_flexible_content_3_services','field_630b297c8b3e4');
INSERT INTO `wp_postmeta` VALUES (1368,222,'flexible_content_2_logo','145');
INSERT INTO `wp_postmeta` VALUES (1369,222,'_flexible_content_2_logo','field_630b369948254');
INSERT INTO `wp_postmeta` VALUES (1370,222,'flexible_content_2_link_title','Discover Who We Serve');
INSERT INTO `wp_postmeta` VALUES (1371,222,'_flexible_content_2_link_title','field_630b3872d34f9');
INSERT INTO `wp_postmeta` VALUES (1372,222,'flexible_content_4_title','We create amazing digital products');
INSERT INTO `wp_postmeta` VALUES (1373,222,'_flexible_content_4_title','field_630b39b92a1e2');
INSERT INTO `wp_postmeta` VALUES (1374,222,'flexible_content_4_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum maximus. Pellentesque et neque rhoncus, sagittis ex eu, tincidunt leo. Donec eu placerat orci, nec congue lacus. Maecenas pellentesque orci risus, sed mollis nisl pellentesque porttitor. Donec eget dolor laoreet, sagittis orci nec, scelerisque lorem.');
INSERT INTO `wp_postmeta` VALUES (1375,222,'_flexible_content_4_headline','field_630b3a0e2a1e3');
INSERT INTO `wp_postmeta` VALUES (1376,222,'flexible_content_4_logo','155');
INSERT INTO `wp_postmeta` VALUES (1377,222,'_flexible_content_4_logo','field_630b3a202a1e4');
INSERT INTO `wp_postmeta` VALUES (1378,222,'flexible_content_4_link','https://www.abcsoftwarecompany.com/');
INSERT INTO `wp_postmeta` VALUES (1379,222,'_flexible_content_4_link','field_630b3a302a1e5');
INSERT INTO `wp_postmeta` VALUES (1380,222,'flexible_content_4_link_title','Work with us');
INSERT INTO `wp_postmeta` VALUES (1381,222,'_flexible_content_4_link_title','field_630b3a3b2a1e6');
INSERT INTO `wp_postmeta` VALUES (1382,222,'flexible_content_5_title','Articles');
INSERT INTO `wp_postmeta` VALUES (1383,222,'_flexible_content_5_title','field_630b5eae1a8fc');
INSERT INTO `wp_postmeta` VALUES (1384,222,'flexible_content_5_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum maximus. Pellentesque et neque rhoncus, sagittis ex eu, tincidunt leo. Donec eu placerat orci, nec congue lacus. Maecenas pellentesque orci risus, sed mollis nisl pellentesque porttitor. Donec eget dolor laoreet, sagittis orci nec, scelerisque lorem.');
INSERT INTO `wp_postmeta` VALUES (1385,222,'_flexible_content_5_headline','field_630b5eb41a8fd');
INSERT INTO `wp_postmeta` VALUES (1386,222,'flexible_content_5_posts_0_post','182');
INSERT INTO `wp_postmeta` VALUES (1387,222,'_flexible_content_5_posts_0_post','field_630b5ec91a8ff');
INSERT INTO `wp_postmeta` VALUES (1388,222,'flexible_content_5_posts_1_post','215');
INSERT INTO `wp_postmeta` VALUES (1389,222,'_flexible_content_5_posts_1_post','field_630b5ec91a8ff');
INSERT INTO `wp_postmeta` VALUES (1390,222,'flexible_content_5_posts_2_post','216');
INSERT INTO `wp_postmeta` VALUES (1391,222,'_flexible_content_5_posts_2_post','field_630b5ec91a8ff');
INSERT INTO `wp_postmeta` VALUES (1392,222,'flexible_content_5_posts_3_post','187');
INSERT INTO `wp_postmeta` VALUES (1393,222,'_flexible_content_5_posts_3_post','field_630b5ec91a8ff');
INSERT INTO `wp_postmeta` VALUES (1394,222,'flexible_content_5_posts_4_post','188');
INSERT INTO `wp_postmeta` VALUES (1395,222,'_flexible_content_5_posts_4_post','field_630b5ec91a8ff');
INSERT INTO `wp_postmeta` VALUES (1396,222,'flexible_content_5_posts_5_post','184');
INSERT INTO `wp_postmeta` VALUES (1397,222,'_flexible_content_5_posts_5_post','field_630b5ec91a8ff');
INSERT INTO `wp_postmeta` VALUES (1398,222,'flexible_content_5_posts_6_post','187');
INSERT INTO `wp_postmeta` VALUES (1399,222,'_flexible_content_5_posts_6_post','field_630b5ec91a8ff');
INSERT INTO `wp_postmeta` VALUES (1400,222,'flexible_content_5_posts','7');
INSERT INTO `wp_postmeta` VALUES (1401,222,'_flexible_content_5_posts','field_630b5ec01a8fe');
INSERT INTO `wp_postmeta` VALUES (1402,222,'flexible_contact_content','');
INSERT INTO `wp_postmeta` VALUES (1403,222,'_flexible_contact_content','field_630b3f3756f43');
INSERT INTO `wp_postmeta` VALUES (1404,222,'flexible_content_0_banner','');
INSERT INTO `wp_postmeta` VALUES (1405,222,'_flexible_content_0_banner','field_630bf563dbc4e');
INSERT INTO `wp_postmeta` VALUES (1406,223,'flexible_content_0_title','ABC Software Solutions');
INSERT INTO `wp_postmeta` VALUES (1407,223,'_flexible_content_0_title','field_63004ba19c354');
INSERT INTO `wp_postmeta` VALUES (1408,223,'flexible_content_0_headine','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.                     Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.');
INSERT INTO `wp_postmeta` VALUES (1409,223,'_flexible_content_0_headine','field_63004c3f9c355');
INSERT INTO `wp_postmeta` VALUES (1410,223,'flexible_content_0_link','htttps://google.com');
INSERT INTO `wp_postmeta` VALUES (1411,223,'_flexible_content_0_link','field_63004c4b9c356');
INSERT INTO `wp_postmeta` VALUES (1412,223,'flexible_content_0_logo','112');
INSERT INTO `wp_postmeta` VALUES (1413,223,'_flexible_content_0_logo','field_63004c5c9c357');
INSERT INTO `wp_postmeta` VALUES (1414,223,'flexible_content','a:6:{i:0;s:6:\"banner\";i:1;s:14:\"who_trusted_us\";i:2;s:12:\"who_we_serve\";i:3;s:8:\"services\";i:4;s:12:\"work_with_us\";i:5;s:8:\"articles\";}');
INSERT INTO `wp_postmeta` VALUES (1415,223,'_flexible_content','field_63004ae978f3c');
INSERT INTO `wp_postmeta` VALUES (1416,223,'flexible_content_0_headline','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.  Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.');
INSERT INTO `wp_postmeta` VALUES (1417,223,'_flexible_content_0_headline','field_63004c3f9c355');
INSERT INTO `wp_postmeta` VALUES (1418,223,'flexible_content_1_title','Who Trusted Us');
INSERT INTO `wp_postmeta` VALUES (1419,223,'_flexible_content_1_title','field_630b24fc6d745');
INSERT INTO `wp_postmeta` VALUES (1420,223,'flexible_content_1_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum.');
INSERT INTO `wp_postmeta` VALUES (1421,223,'_flexible_content_1_headline','field_630b25016d746');
INSERT INTO `wp_postmeta` VALUES (1422,223,'flexible_content_1_partner_0_logo','121');
INSERT INTO `wp_postmeta` VALUES (1423,223,'_flexible_content_1_partner_0_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (1424,223,'flexible_content_1_partner_1_logo','122');
INSERT INTO `wp_postmeta` VALUES (1425,223,'_flexible_content_1_partner_1_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (1426,223,'flexible_content_1_partner_2_logo','123');
INSERT INTO `wp_postmeta` VALUES (1427,223,'_flexible_content_1_partner_2_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (1428,223,'flexible_content_1_partner_3_logo','124');
INSERT INTO `wp_postmeta` VALUES (1429,223,'_flexible_content_1_partner_3_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (1430,223,'flexible_content_1_partner_4_logo','125');
INSERT INTO `wp_postmeta` VALUES (1431,223,'_flexible_content_1_partner_4_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (1432,223,'flexible_content_1_partner_5_logo','126');
INSERT INTO `wp_postmeta` VALUES (1433,223,'_flexible_content_1_partner_5_logo','field_630b25916d748');
INSERT INTO `wp_postmeta` VALUES (1434,223,'flexible_content_1_partner','6');
INSERT INTO `wp_postmeta` VALUES (1435,223,'_flexible_content_1_partner','field_630b250d6d747');
INSERT INTO `wp_postmeta` VALUES (1436,223,'flexible_content_2_title','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.');
INSERT INTO `wp_postmeta` VALUES (1437,223,'_flexible_content_2_title','field_630b33abc7a8e');
INSERT INTO `wp_postmeta` VALUES (1438,223,'flexible_content_2_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum maximus. Pellentesque et neque rhoncus, sagittis ex eu, tincidunt leo. Donec eu placerat orci, nec congue lacus. Maecenas pellentesque orci risus, sed mollis nisl pellentesque porttitor. Donec eget dolor laoreet, sagittis orci nec, scelerisque lorem.');
INSERT INTO `wp_postmeta` VALUES (1439,223,'_flexible_content_2_headline','field_630b33bdc7a8f');
INSERT INTO `wp_postmeta` VALUES (1440,223,'flexible_content_2_link','https://www.abcsoftwarecompany.com/');
INSERT INTO `wp_postmeta` VALUES (1441,223,'_flexible_content_2_link','field_630b33efc7a90');
INSERT INTO `wp_postmeta` VALUES (1442,223,'flexible_content_3_title','Services');
INSERT INTO `wp_postmeta` VALUES (1443,223,'_flexible_content_3_title','field_630b29518b3e2');
INSERT INTO `wp_postmeta` VALUES (1444,223,'flexible_content_3_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum maximus. Pellentesque et neque rhoncus, sagittis ex eu, tincidunt leo');
INSERT INTO `wp_postmeta` VALUES (1445,223,'_flexible_content_3_headline','field_630b29638b3e3');
INSERT INTO `wp_postmeta` VALUES (1446,223,'flexible_content_3_services_0_logo','132');
INSERT INTO `wp_postmeta` VALUES (1447,223,'_flexible_content_3_services_0_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (1448,223,'flexible_content_3_services_1_logo','133');
INSERT INTO `wp_postmeta` VALUES (1449,223,'_flexible_content_3_services_1_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (1450,223,'flexible_content_3_services_2_logo','134');
INSERT INTO `wp_postmeta` VALUES (1451,223,'_flexible_content_3_services_2_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (1452,223,'flexible_content_3_services_3_logo','135');
INSERT INTO `wp_postmeta` VALUES (1453,223,'_flexible_content_3_services_3_logo','field_630b29b38b3e5');
INSERT INTO `wp_postmeta` VALUES (1454,223,'flexible_content_3_services','4');
INSERT INTO `wp_postmeta` VALUES (1455,223,'_flexible_content_3_services','field_630b297c8b3e4');
INSERT INTO `wp_postmeta` VALUES (1456,223,'flexible_content_2_logo','145');
INSERT INTO `wp_postmeta` VALUES (1457,223,'_flexible_content_2_logo','field_630b369948254');
INSERT INTO `wp_postmeta` VALUES (1458,223,'flexible_content_2_link_title','Discover Who We Serve');
INSERT INTO `wp_postmeta` VALUES (1459,223,'_flexible_content_2_link_title','field_630b3872d34f9');
INSERT INTO `wp_postmeta` VALUES (1460,223,'flexible_content_4_title','We create amazing digital products');
INSERT INTO `wp_postmeta` VALUES (1461,223,'_flexible_content_4_title','field_630b39b92a1e2');
INSERT INTO `wp_postmeta` VALUES (1462,223,'flexible_content_4_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum maximus. Pellentesque et neque rhoncus, sagittis ex eu, tincidunt leo. Donec eu placerat orci, nec congue lacus. Maecenas pellentesque orci risus, sed mollis nisl pellentesque porttitor. Donec eget dolor laoreet, sagittis orci nec, scelerisque lorem.');
INSERT INTO `wp_postmeta` VALUES (1463,223,'_flexible_content_4_headline','field_630b3a0e2a1e3');
INSERT INTO `wp_postmeta` VALUES (1464,223,'flexible_content_4_logo','155');
INSERT INTO `wp_postmeta` VALUES (1465,223,'_flexible_content_4_logo','field_630b3a202a1e4');
INSERT INTO `wp_postmeta` VALUES (1466,223,'flexible_content_4_link','https://www.abcsoftwarecompany.com/');
INSERT INTO `wp_postmeta` VALUES (1467,223,'_flexible_content_4_link','field_630b3a302a1e5');
INSERT INTO `wp_postmeta` VALUES (1468,223,'flexible_content_4_link_title','Work with us');
INSERT INTO `wp_postmeta` VALUES (1469,223,'_flexible_content_4_link_title','field_630b3a3b2a1e6');
INSERT INTO `wp_postmeta` VALUES (1470,223,'flexible_content_5_title','Articles');
INSERT INTO `wp_postmeta` VALUES (1471,223,'_flexible_content_5_title','field_630b5eae1a8fc');
INSERT INTO `wp_postmeta` VALUES (1472,223,'flexible_content_5_headline','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper a. Sed pretium egestas urna in posuere. Pellentesque scelerisque nec ante elementum maximus. Pellentesque et neque rhoncus, sagittis ex eu, tincidunt leo. Donec eu placerat orci, nec congue lacus. Maecenas pellentesque orci risus, sed mollis nisl pellentesque porttitor. Donec eget dolor laoreet, sagittis orci nec, scelerisque lorem.');
INSERT INTO `wp_postmeta` VALUES (1473,223,'_flexible_content_5_headline','field_630b5eb41a8fd');
INSERT INTO `wp_postmeta` VALUES (1474,223,'flexible_content_5_posts_0_post','182');
INSERT INTO `wp_postmeta` VALUES (1475,223,'_flexible_content_5_posts_0_post','field_630b5ec91a8ff');
INSERT INTO `wp_postmeta` VALUES (1476,223,'flexible_content_5_posts_1_post','215');
INSERT INTO `wp_postmeta` VALUES (1477,223,'_flexible_content_5_posts_1_post','field_630b5ec91a8ff');
INSERT INTO `wp_postmeta` VALUES (1478,223,'flexible_content_5_posts_2_post','216');
INSERT INTO `wp_postmeta` VALUES (1479,223,'_flexible_content_5_posts_2_post','field_630b5ec91a8ff');
INSERT INTO `wp_postmeta` VALUES (1480,223,'flexible_content_5_posts_3_post','187');
INSERT INTO `wp_postmeta` VALUES (1481,223,'_flexible_content_5_posts_3_post','field_630b5ec91a8ff');
INSERT INTO `wp_postmeta` VALUES (1482,223,'flexible_content_5_posts_4_post','188');
INSERT INTO `wp_postmeta` VALUES (1483,223,'_flexible_content_5_posts_4_post','field_630b5ec91a8ff');
INSERT INTO `wp_postmeta` VALUES (1484,223,'flexible_content_5_posts_5_post','184');
INSERT INTO `wp_postmeta` VALUES (1485,223,'_flexible_content_5_posts_5_post','field_630b5ec91a8ff');
INSERT INTO `wp_postmeta` VALUES (1486,223,'flexible_content_5_posts_6_post','187');
INSERT INTO `wp_postmeta` VALUES (1487,223,'_flexible_content_5_posts_6_post','field_630b5ec91a8ff');
INSERT INTO `wp_postmeta` VALUES (1488,223,'flexible_content_5_posts','7');
INSERT INTO `wp_postmeta` VALUES (1489,223,'_flexible_content_5_posts','field_630b5ec01a8fe');
INSERT INTO `wp_postmeta` VALUES (1490,223,'flexible_contact_content','');
INSERT INTO `wp_postmeta` VALUES (1491,223,'_flexible_contact_content','field_630b3f3756f43');
INSERT INTO `wp_postmeta` VALUES (1492,223,'flexible_content_0_banner','191');
INSERT INTO `wp_postmeta` VALUES (1493,223,'_flexible_content_0_banner','field_630bf563dbc4e');
INSERT INTO `wp_postmeta` VALUES (1494,224,'_wp_attached_file','2022/08/contact-banner-2.jpg');
INSERT INTO `wp_postmeta` VALUES (1495,224,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1920;s:6:\"height\";i:1280;s:4:\"file\";s:28:\"2022/08/contact-banner-2.jpg\";s:8:\"filesize\";i:136381;s:5:\"sizes\";a:5:{s:6:\"medium\";a:5:{s:4:\"file\";s:28:\"contact-banner-2-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:9725;}s:5:\"large\";a:5:{s:4:\"file\";s:29:\"contact-banner-2-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:59952;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:28:\"contact-banner-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4880;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:28:\"contact-banner-2-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:37980;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:30:\"contact-banner-2-1536x1024.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:117270;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (1496,225,'flexible_content','');
INSERT INTO `wp_postmeta` VALUES (1497,225,'_flexible_content','field_63004ae978f3c');
INSERT INTO `wp_postmeta` VALUES (1498,225,'flexible_contact_content_0_contact_form','168');
INSERT INTO `wp_postmeta` VALUES (1499,225,'_flexible_contact_content_0_contact_form','field_630b3f9e56f5b');
INSERT INTO `wp_postmeta` VALUES (1500,225,'flexible_contact_content_0_','');
INSERT INTO `wp_postmeta` VALUES (1501,225,'_flexible_contact_content_0_','field_630b4065a1106');
INSERT INTO `wp_postmeta` VALUES (1502,225,'flexible_contact_content','a:2:{i:0;s:6:\"banner\";i:1;s:12:\"contact_form\";}');
INSERT INTO `wp_postmeta` VALUES (1503,225,'_flexible_contact_content','field_630b3f3756f43');
INSERT INTO `wp_postmeta` VALUES (1504,225,'flexible_contact_content_0_title','Get In Touch!');
INSERT INTO `wp_postmeta` VALUES (1505,225,'_flexible_contact_content_0_title','field_630b3f3756f44');
INSERT INTO `wp_postmeta` VALUES (1506,225,'flexible_contact_content_0_headline','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.');
INSERT INTO `wp_postmeta` VALUES (1507,225,'_flexible_contact_content_0_headline','field_630b3f3756f45');
INSERT INTO `wp_postmeta` VALUES (1508,225,'flexible_contact_content_0_link','');
INSERT INTO `wp_postmeta` VALUES (1509,225,'_flexible_contact_content_0_link','field_630b3f3756f46');
INSERT INTO `wp_postmeta` VALUES (1510,225,'flexible_contact_content_0_logo','224');
INSERT INTO `wp_postmeta` VALUES (1511,225,'_flexible_contact_content_0_logo','field_630b3f3756f47');
INSERT INTO `wp_postmeta` VALUES (1512,225,'flexible_contact_content_1_form','168');
INSERT INTO `wp_postmeta` VALUES (1513,225,'_flexible_contact_content_1_form','field_630b3f9e56f5b');
INSERT INTO `wp_postmeta` VALUES (1514,225,'flexible_contact_content_1_','');
INSERT INTO `wp_postmeta` VALUES (1515,225,'_flexible_contact_content_1_','field_630b4065a1106');
INSERT INTO `wp_postmeta` VALUES (1516,226,'flexible_content','');
INSERT INTO `wp_postmeta` VALUES (1517,226,'_flexible_content','field_63004ae978f3c');
INSERT INTO `wp_postmeta` VALUES (1518,226,'flexible_contact_content_0_contact_form','168');
INSERT INTO `wp_postmeta` VALUES (1519,226,'_flexible_contact_content_0_contact_form','field_630b3f9e56f5b');
INSERT INTO `wp_postmeta` VALUES (1520,226,'flexible_contact_content_0_','');
INSERT INTO `wp_postmeta` VALUES (1521,226,'_flexible_contact_content_0_','field_630b4065a1106');
INSERT INTO `wp_postmeta` VALUES (1522,226,'flexible_contact_content','a:2:{i:0;s:6:\"banner\";i:1;s:12:\"contact_form\";}');
INSERT INTO `wp_postmeta` VALUES (1523,226,'_flexible_contact_content','field_630b3f3756f43');
INSERT INTO `wp_postmeta` VALUES (1524,226,'flexible_contact_content_0_title','Get In Touch!');
INSERT INTO `wp_postmeta` VALUES (1525,226,'_flexible_contact_content_0_title','field_630b3f3756f44');
INSERT INTO `wp_postmeta` VALUES (1526,226,'flexible_contact_content_0_headline','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.');
INSERT INTO `wp_postmeta` VALUES (1527,226,'_flexible_contact_content_0_headline','field_630b3f3756f45');
INSERT INTO `wp_postmeta` VALUES (1528,226,'flexible_contact_content_0_link','');
INSERT INTO `wp_postmeta` VALUES (1529,226,'_flexible_contact_content_0_link','field_630b3f3756f46');
INSERT INTO `wp_postmeta` VALUES (1530,226,'flexible_contact_content_0_logo','');
INSERT INTO `wp_postmeta` VALUES (1531,226,'_flexible_contact_content_0_logo','field_630b3f3756f47');
INSERT INTO `wp_postmeta` VALUES (1532,226,'flexible_contact_content_1_form','168');
INSERT INTO `wp_postmeta` VALUES (1533,226,'_flexible_contact_content_1_form','field_630b3f9e56f5b');
INSERT INTO `wp_postmeta` VALUES (1534,226,'flexible_contact_content_1_','');
INSERT INTO `wp_postmeta` VALUES (1535,226,'_flexible_contact_content_1_','field_630b4065a1106');
INSERT INTO `wp_postmeta` VALUES (1536,157,'flexible_contact_content_0_banner','224');
INSERT INTO `wp_postmeta` VALUES (1537,157,'_flexible_contact_content_0_banner','field_630bf6db8861b');
INSERT INTO `wp_postmeta` VALUES (1538,228,'flexible_content','');
INSERT INTO `wp_postmeta` VALUES (1539,228,'_flexible_content','field_63004ae978f3c');
INSERT INTO `wp_postmeta` VALUES (1540,228,'flexible_contact_content_0_contact_form','168');
INSERT INTO `wp_postmeta` VALUES (1541,228,'_flexible_contact_content_0_contact_form','field_630b3f9e56f5b');
INSERT INTO `wp_postmeta` VALUES (1542,228,'flexible_contact_content_0_','');
INSERT INTO `wp_postmeta` VALUES (1543,228,'_flexible_contact_content_0_','field_630b4065a1106');
INSERT INTO `wp_postmeta` VALUES (1544,228,'flexible_contact_content','a:2:{i:0;s:6:\"banner\";i:1;s:12:\"contact_form\";}');
INSERT INTO `wp_postmeta` VALUES (1545,228,'_flexible_contact_content','field_630b3f3756f43');
INSERT INTO `wp_postmeta` VALUES (1546,228,'flexible_contact_content_0_title','Get In Touch!');
INSERT INTO `wp_postmeta` VALUES (1547,228,'_flexible_contact_content_0_title','field_630b3f3756f44');
INSERT INTO `wp_postmeta` VALUES (1548,228,'flexible_contact_content_0_headline','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.');
INSERT INTO `wp_postmeta` VALUES (1549,228,'_flexible_contact_content_0_headline','field_630b3f3756f45');
INSERT INTO `wp_postmeta` VALUES (1550,228,'flexible_contact_content_0_link','');
INSERT INTO `wp_postmeta` VALUES (1551,228,'_flexible_contact_content_0_link','field_630b3f3756f46');
INSERT INTO `wp_postmeta` VALUES (1552,228,'flexible_contact_content_0_logo','');
INSERT INTO `wp_postmeta` VALUES (1553,228,'_flexible_contact_content_0_logo','field_630b3f3756f47');
INSERT INTO `wp_postmeta` VALUES (1554,228,'flexible_contact_content_1_form','168');
INSERT INTO `wp_postmeta` VALUES (1555,228,'_flexible_contact_content_1_form','field_630b3f9e56f5b');
INSERT INTO `wp_postmeta` VALUES (1556,228,'flexible_contact_content_1_','');
INSERT INTO `wp_postmeta` VALUES (1557,228,'_flexible_contact_content_1_','field_630b4065a1106');
INSERT INTO `wp_postmeta` VALUES (1558,228,'flexible_contact_content_0_banner','224');
INSERT INTO `wp_postmeta` VALUES (1559,228,'_flexible_contact_content_0_banner','field_630bf6db8861b');
INSERT INTO `wp_postmeta` VALUES (1572,229,'flexible_content','');
INSERT INTO `wp_postmeta` VALUES (1573,229,'_flexible_content','field_63004ae978f3c');
INSERT INTO `wp_postmeta` VALUES (1574,229,'flexible_contact_content_0_contact_form','168');
INSERT INTO `wp_postmeta` VALUES (1575,229,'_flexible_contact_content_0_contact_form','field_630b3f9e56f5b');
INSERT INTO `wp_postmeta` VALUES (1576,229,'flexible_contact_content_0_','');
INSERT INTO `wp_postmeta` VALUES (1577,229,'_flexible_contact_content_0_','field_630b4065a1106');
INSERT INTO `wp_postmeta` VALUES (1578,229,'flexible_contact_content','a:2:{i:0;s:12:\"contact_form\";i:1;s:14:\"contact_banner\";}');
INSERT INTO `wp_postmeta` VALUES (1579,229,'_flexible_contact_content','field_630b3f3756f43');
INSERT INTO `wp_postmeta` VALUES (1580,229,'flexible_contact_content_0_title','Get In Touch!');
INSERT INTO `wp_postmeta` VALUES (1581,229,'_flexible_contact_content_0_title','field_630b3f3756f44');
INSERT INTO `wp_postmeta` VALUES (1582,229,'flexible_contact_content_0_headline','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.');
INSERT INTO `wp_postmeta` VALUES (1583,229,'_flexible_contact_content_0_headline','field_630b3f3756f45');
INSERT INTO `wp_postmeta` VALUES (1584,229,'flexible_contact_content_0_link','');
INSERT INTO `wp_postmeta` VALUES (1585,229,'_flexible_contact_content_0_link','field_630b3f3756f46');
INSERT INTO `wp_postmeta` VALUES (1586,229,'flexible_contact_content_0_logo','');
INSERT INTO `wp_postmeta` VALUES (1587,229,'_flexible_contact_content_0_logo','field_630b3f3756f47');
INSERT INTO `wp_postmeta` VALUES (1588,229,'flexible_contact_content_0_banner','224');
INSERT INTO `wp_postmeta` VALUES (1589,229,'_flexible_contact_content_0_banner','field_630bf6db8861b');
INSERT INTO `wp_postmeta` VALUES (1590,229,'flexible_contact_content_0_form','168');
INSERT INTO `wp_postmeta` VALUES (1591,229,'_flexible_contact_content_0_form','field_630b3f9e56f5b');
INSERT INTO `wp_postmeta` VALUES (1592,229,'flexible_contact_content_1_title','Get In Touch!');
INSERT INTO `wp_postmeta` VALUES (1593,229,'_flexible_contact_content_1_title','field_630b3f3756f44');
INSERT INTO `wp_postmeta` VALUES (1594,229,'flexible_contact_content_1_headline','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.');
INSERT INTO `wp_postmeta` VALUES (1595,229,'_flexible_contact_content_1_headline','field_630b3f3756f45');
INSERT INTO `wp_postmeta` VALUES (1596,229,'flexible_contact_content_1_link','');
INSERT INTO `wp_postmeta` VALUES (1597,229,'_flexible_contact_content_1_link','field_630b3f3756f46');
INSERT INTO `wp_postmeta` VALUES (1598,229,'flexible_contact_content_1_logo','');
INSERT INTO `wp_postmeta` VALUES (1599,229,'_flexible_contact_content_1_logo','field_630b3f3756f47');
INSERT INTO `wp_postmeta` VALUES (1600,229,'flexible_contact_content_1_banner','224');
INSERT INTO `wp_postmeta` VALUES (1601,229,'_flexible_contact_content_1_banner','field_630bf6db8861b');
INSERT INTO `wp_postmeta` VALUES (1602,157,'flexible_contact_content_1_form','168');
INSERT INTO `wp_postmeta` VALUES (1603,157,'_flexible_contact_content_1_form','field_630b3f9e56f5b');
INSERT INTO `wp_postmeta` VALUES (1604,157,'flexible_contact_content_1_','');
INSERT INTO `wp_postmeta` VALUES (1605,157,'_flexible_contact_content_1_','field_630b4065a1106');
INSERT INTO `wp_postmeta` VALUES (1606,230,'flexible_content','');
INSERT INTO `wp_postmeta` VALUES (1607,230,'_flexible_content','field_63004ae978f3c');
INSERT INTO `wp_postmeta` VALUES (1608,230,'flexible_contact_content_0_contact_form','168');
INSERT INTO `wp_postmeta` VALUES (1609,230,'_flexible_contact_content_0_contact_form','field_630b3f9e56f5b');
INSERT INTO `wp_postmeta` VALUES (1610,230,'flexible_contact_content','a:2:{i:0;s:14:\"contact_banner\";i:1;s:12:\"contact_form\";}');
INSERT INTO `wp_postmeta` VALUES (1611,230,'_flexible_contact_content','field_630b3f3756f43');
INSERT INTO `wp_postmeta` VALUES (1612,230,'flexible_contact_content_0_title','Get In Touch!');
INSERT INTO `wp_postmeta` VALUES (1613,230,'_flexible_contact_content_0_title','field_630b3f3756f44');
INSERT INTO `wp_postmeta` VALUES (1614,230,'flexible_contact_content_0_headline','Morbi ornare justo eget massa faucibus, in condimentum enim convallis.');
INSERT INTO `wp_postmeta` VALUES (1615,230,'_flexible_contact_content_0_headline','field_630b3f3756f45');
INSERT INTO `wp_postmeta` VALUES (1616,230,'flexible_contact_content_0_link','');
INSERT INTO `wp_postmeta` VALUES (1617,230,'_flexible_contact_content_0_link','field_630b3f3756f46');
INSERT INTO `wp_postmeta` VALUES (1618,230,'flexible_contact_content_0_logo','');
INSERT INTO `wp_postmeta` VALUES (1619,230,'_flexible_contact_content_0_logo','field_630b3f3756f47');
INSERT INTO `wp_postmeta` VALUES (1620,230,'flexible_contact_content_0_banner','224');
INSERT INTO `wp_postmeta` VALUES (1621,230,'_flexible_contact_content_0_banner','field_630bf6db8861b');
INSERT INTO `wp_postmeta` VALUES (1622,230,'flexible_contact_content_1_form','168');
INSERT INTO `wp_postmeta` VALUES (1623,230,'_flexible_contact_content_1_form','field_630b3f9e56f5b');
INSERT INTO `wp_postmeta` VALUES (1624,230,'flexible_contact_content_1_','');
INSERT INTO `wp_postmeta` VALUES (1625,230,'_flexible_contact_content_1_','field_630b4065a1106');
/*!40000 ALTER TABLE `wp_postmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_posts`
--

DROP TABLE IF EXISTS `wp_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=231 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_posts`
--

LOCK TABLES `wp_posts` WRITE;
/*!40000 ALTER TABLE `wp_posts` DISABLE KEYS */;
INSERT INTO `wp_posts` VALUES (1,1,'2022-07-29 15:14:18','2022-07-29 15:14:18','<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->','Hello world!','','trash','open','open','','hello-world__trashed','','','2022-08-19 08:26:10','2022-08-19 08:26:10','',0,'http://lamminhthien.local/?p=1',0,'post','',1);
INSERT INTO `wp_posts` VALUES (2,1,'2022-07-29 15:14:18','2022-07-29 15:14:18','<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href=\"http://lamminhthien.local/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->','Sample Page','','trash','closed','open','','sample-page__trashed','','','2022-07-30 02:22:37','2022-07-30 02:22:37','',0,'http://lamminhthien.local/?page_id=2',0,'page','',0);
INSERT INTO `wp_posts` VALUES (3,1,'2022-07-29 15:14:18','2022-07-29 15:14:18','<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Our website address is: http://lamminhthien.local.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Comments</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Media</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookies</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Embedded content from other websites</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where your data is sent</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph -->','Privacy Policy','','trash','closed','open','','privacy-policy__trashed','','','2022-07-30 02:22:37','2022-07-30 02:22:37','',0,'http://lamminhthien.local/?page_id=3',0,'page','',0);
INSERT INTO `wp_posts` VALUES (5,1,'2022-07-30 02:22:37','2022-07-30 02:22:37','<!-- wp:video {\"align\":\"full\"} -->\n<figure class=\"wp-block-video alignfull\"></figure>\n<!-- /wp:video -->','','','trash','closed','closed','','__trashed','','','2022-07-30 02:22:37','2022-07-30 02:22:37','',0,'http://lamminhthien.local/?page_id=5',0,'page','',0);
INSERT INTO `wp_posts` VALUES (6,1,'2022-07-29 15:26:25','2022-07-29 15:26:25','{\"version\": 2, \"isGlobalStylesUserThemeJSON\": true }','Custom Styles','','publish','closed','closed','','wp-global-styles-twentytwentytwo','','','2022-07-29 15:26:25','2022-07-29 15:26:25','',0,'http://lamminhthien.local/wp-global-styles-twentytwentytwo/',0,'wp_global_styles','',0);
INSERT INTO `wp_posts` VALUES (7,1,'2022-07-29 15:26:52','2022-07-29 15:26:52','','12','','inherit','open','closed','','12','','','2022-07-29 15:26:52','2022-07-29 15:26:52','',5,'http://lamminhthien.local/wp-content/uploads/2022/07/12.gif',0,'attachment','image/gif',0);
INSERT INTO `wp_posts` VALUES (8,1,'2022-07-29 15:27:13','2022-07-29 15:27:13','<!-- wp:image {\"id\":7,\"sizeSlug\":\"full\",\"linkDestination\":\"none\"} -->\n<figure class=\"wp-block-image size-full\"><img src=\"http://lamminhthien.local/wp-content/uploads/2022/07/12.gif\" alt=\"\" class=\"wp-image-7\"/></figure>\n<!-- /wp:image -->','','','inherit','closed','closed','','5-revision-v1','','','2022-07-29 15:27:13','2022-07-29 15:27:13','',5,'http://lamminhthien.local/?p=8',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (9,1,'2022-07-30 02:22:37','2022-07-30 02:22:37','<!-- wp:video {\"align\":\"full\"} -->\n<figure class=\"wp-block-video alignfull\"></figure>\n<!-- /wp:video -->','','','inherit','closed','closed','','5-revision-v1','','','2022-07-30 02:22:37','2022-07-30 02:22:37','',5,'http://lamminhthien.local/?p=9',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (10,1,'2022-07-30 02:22:37','2022-07-30 02:22:37','<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Our website address is: http://lamminhthien.local.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Comments</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Media</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookies</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Embedded content from other websites</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where your data is sent</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph -->','Privacy Policy','','inherit','closed','closed','','3-revision-v1','','','2022-07-30 02:22:37','2022-07-30 02:22:37','',3,'http://lamminhthien.local/?p=10',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (11,1,'2022-07-30 02:22:37','2022-07-30 02:22:37','<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href=\"http://lamminhthien.local/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->','Sample Page','','inherit','closed','closed','','2-revision-v1','','','2022-07-30 02:22:37','2022-07-30 02:22:37','',2,'http://lamminhthien.local/?p=11',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (19,1,'2022-08-01 08:12:18','2022-08-01 08:12:18','{\"version\": 2, \"isGlobalStylesUserThemeJSON\": true }','Custom Styles','','publish','closed','closed','','wp-global-styles-code-theme','','','2022-08-01 08:12:18','2022-08-01 08:12:18','',0,'http://lamminhthien.local/wp-global-styles-code-theme/',0,'wp_global_styles','',0);
INSERT INTO `wp_posts` VALUES (23,1,'2022-08-13 02:21:12','2022-08-13 02:21:12','{\"version\": 2, \"isGlobalStylesUserThemeJSON\": true }','Custom Styles','','publish','closed','closed','','wp-global-styles-abc-demo','','','2022-08-13 02:21:12','2022-08-13 02:21:12','',0,'http://lamminhthien.local/wp-global-styles-abc-demo/',0,'wp_global_styles','',0);
INSERT INTO `wp_posts` VALUES (27,1,'2022-08-19 04:51:35','2022-08-19 04:51:35','','About','','trash','closed','closed','','__trashed-2','','','2022-08-19 04:51:35','2022-08-19 04:51:35','',0,'http://lamminhthien.local/?page_id=27',0,'page','',0);
INSERT INTO `wp_posts` VALUES (28,1,'2022-08-13 02:27:52','2022-08-13 02:27:52','','Home','','publish','closed','closed','','about','','','2022-08-29 06:10:02','2022-08-28 23:10:02','',0,'http://lamminhthien.local/?page_id=28',0,'page','',0);
INSERT INTO `wp_posts` VALUES (29,1,'2022-08-13 02:27:52','2022-08-13 02:27:52','','','','inherit','closed','closed','','28-revision-v1','','','2022-08-13 02:27:52','2022-08-13 02:27:52','',28,'http://lamminhthien.local/?p=29',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (31,1,'2022-08-13 02:45:54','2022-08-13 02:45:54','<div>\r\n<div>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>','','','inherit','closed','closed','','28-revision-v1','','','2022-08-13 02:45:54','2022-08-13 02:45:54','',28,'http://lamminhthien.local/?p=31',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (32,1,'2022-08-13 02:47:26','2022-08-13 02:47:26','','13','','inherit','open','closed','','13','','','2022-08-13 02:47:26','2022-08-13 02:47:26','',28,'http://lamminhthien.local/wp-content/uploads/2022/08/13.gif',0,'attachment','image/gif',0);
INSERT INTO `wp_posts` VALUES (33,1,'2022-08-13 02:52:35','2022-08-13 02:52:35','<div>\r\n<div>\r\n\r\n<img class=\"alignnone size-medium wp-image-32\" src=\"http://lamminhthien.local/wp-content/uploads/2022/08/13-300x300.gif\" alt=\"\" width=\"300\" height=\"300\" />Lorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>','','','inherit','closed','closed','','28-revision-v1','','','2022-08-13 02:52:35','2022-08-13 02:52:35','',28,'http://lamminhthien.local/?p=33',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (34,1,'2022-08-13 02:53:12','2022-08-13 02:53:12','<div>\r\n<div>\r\n\r\n<img class=\"alignnone size-medium wp-image-32\" src=\"http://lamminhthien.local/wp-content/uploads/2022/08/13-300x300.gif\" alt=\"\" width=\"300\" height=\"300\" />Lorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>','About','','inherit','closed','closed','','28-revision-v1','','','2022-08-13 02:53:12','2022-08-13 02:53:12','',28,'http://lamminhthien.local/?p=34',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (35,1,'2022-08-19 04:48:35','2022-08-19 04:48:35','Một con gà tây tán gẫu với con bò: “Mình cực kì yêu thích leo lên ngọn của cái cây kia, nhưng lại không có đủ sức (gà tây thở dài).\n\nCon bò góp ý: “Vậy bạn thử ăn chất thải của mình coi sao? Chúng chứa rất nhiều dưỡng chất đấy!”.\n\nGà tây gặm một miếng phân bò và đúng thật là nó cung cấp cho chú nhiều dưỡng chất đủ để leo lên nhánh thấp nhất của cái cây đấy. Ngày tiếp theo, sau khi thưởng thức thêm phân bò, gà tây leo lên được nhánh thứ 2. Cuối cùng sau bốn đêm leo trèo, gà tây đã chễm chệ ngồi trên ngọn cây cao nhất. Tuy nhiên chưa tận hưởng được niềm vui chiến thắng bao lâu, gà tây đã bị bắn chết bởi người nông dân khi ông phát hiện ra nó lấp ló ở ngọn cây.','About','','inherit','closed','closed','','28-autosave-v1','','','2022-08-19 04:48:35','2022-08-19 04:48:35','',28,'http://lamminhthien.local/?p=35',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (36,1,'2022-08-13 02:59:39','2022-08-13 02:59:39','<div>\r\n<div>\r\n\r\n<img class=\"alignnone size-medium wp-image-32\" src=\"http://lamminhthien.local/wp-content/uploads/2022/08/13-300x300.gif\" alt=\"\" width=\"300\" height=\"300\" />Lorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>','about','','inherit','closed','closed','','28-revision-v1','','','2022-08-13 02:59:39','2022-08-13 02:59:39','',28,'http://lamminhthien.local/?p=36',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (37,1,'2022-08-13 02:59:53','2022-08-13 02:59:53','<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>','about','','inherit','closed','closed','','28-revision-v1','','','2022-08-13 02:59:53','2022-08-13 02:59:53','',28,'http://lamminhthien.local/?p=37',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (38,1,'2022-08-13 03:01:42','2022-08-13 03:01:42','<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>','About','','inherit','closed','closed','','28-revision-v1','','','2022-08-13 03:01:42','2022-08-13 03:01:42','',28,'http://lamminhthien.local/?p=38',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (39,1,'2022-08-13 03:02:01','2022-08-13 03:02:01','Ông nội và người cháu đích tôn 3 tuổi đang ngồi chơi trò bán hàng.\r\n\r\n<strong>- Cháu:</strong> Đây tôi đưa bác 5.000 đồng, nhưng với một điều kiện.\r\n<strong>- Ông:</strong> Điều kiện gì cũng được.\r\n<strong>- Cháu:</strong> Thật không?\r\n<strong>- Ông:</strong> Thật. Bác cứ nói đi.\r\n<strong>- Cháu:</strong> Bác phải về dạy lại con bác đi nhé, con bác hay đánh tôi lắm đấy.','What We Do','','publish','closed','closed','','what-we-do','','','2022-08-19 04:51:59','2022-08-19 04:51:59','',0,'http://lamminhthien.local/?page_id=39',0,'page','',0);
INSERT INTO `wp_posts` VALUES (40,1,'2022-08-13 03:02:01','2022-08-13 03:02:01','','What We Do','','inherit','closed','closed','','39-revision-v1','','','2022-08-13 03:02:01','2022-08-13 03:02:01','',39,'http://lamminhthien.local/?p=40',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (41,1,'2022-08-13 03:02:30','2022-08-13 03:02:30','Lorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>\r\n\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.\r\n<div>\r\n<div>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>','What We Do','','inherit','closed','closed','','39-revision-v1','','','2022-08-13 03:02:30','2022-08-13 03:02:30','',39,'http://lamminhthien.local/?p=41',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (42,1,'2022-08-13 03:22:33','2022-08-13 03:22:33','','What We Do','','inherit','closed','closed','','39-revision-v1','','','2022-08-13 03:22:33','2022-08-13 03:22:33','',39,'http://lamminhthien.local/?p=42',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (43,1,'2022-08-18 13:40:06','2022-08-18 13:40:06','Quê hương là một tiếng ve\r\nLời ru của mẹ trưa hè à ơi\r\nDòng sông con nước đầy vơi\r\nQuê hương là một góc trời tuổi thơ\r\nQuê hương ngày ấy như mơ\r\nTôi là cậu bé dại khờ đáng yêu\r\nQuê hương là tiếng sáo diều\r\nLà cánh cò trắng chiều chiều chân đê\r\nQuê hương là phiên chợ quê\r\nChợ trưa mong mẹ mang về bánh đa\r\nQuê hương là một tiếng gà\r\nBình minh gáy sáng ngân nga xóm làng\r\nQuê hương là cánh đồng vàng\r\nHương thơm lúa chín mênh mang trời chiều\r\nQuê hương là dáng mẹ yêu\r\nÁo nâu nón lá liêu siêu đi về\r\nQuê hương nhắc tới nhớ ghê\r\nAi đi xa cũng mong về chốn xưa\r\nQuê hương là những cơn mưa\r\nQuê hương là những hàng dừa ven kinh\r\nQuê hương mang nặng nghĩa tình\r\nQuê hương tôi đó đẹp xinh tuyệt vời\r\nQuê hương ta đó là nơi\r\nChôn rau cắt rốn người ơi nhớ về.','Post 1','','publish','open','open','','post-1','','','2022-08-19 10:11:18','2022-08-19 10:11:18','',0,'http://lamminhthien.local/?p=43',0,'post','',0);
INSERT INTO `wp_posts` VALUES (44,1,'2022-08-13 03:29:22','2022-08-13 03:29:22','','Post 1','','inherit','closed','closed','','43-revision-v1','','','2022-08-13 03:29:22','2022-08-13 03:29:22','',43,'http://lamminhthien.local/?p=44',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (45,1,'2022-08-13 03:30:45','2022-08-13 03:30:45','Quê hương là một tiếng ve\r\nLời ru của mẹ trưa hè à ơi\r\nDòng sông con nước đầy vơi\r\nQuê hương là một góc trời tuổi thơ\r\nQuê hương ngày ấy như mơ\r\nTôi là cậu bé dại khờ đáng yêu\r\nQuê hương là tiếng sáo diều\r\nLà cánh cò trắng chiều chiều chân đê\r\nQuê hương là phiên chợ quê\r\nChợ trưa mong mẹ mang về bánh đa\r\nQuê hương là một tiếng gà\r\nBình minh gáy sáng ngân nga xóm làng\r\nQuê hương là cánh đồng vàng\r\nHương thơm lúa chín mênh mang trời chiều\r\nQuê hương là dáng mẹ yêu\r\nÁo nâu nón lá liêu siêu đi về\r\nQuê hương nhắc tới nhớ ghê\r\nAi đi xa cũng mong về chốn xưa\r\nQuê hương là những cơn mưa\r\nQuê hương là những hàng dừa ven kinh\r\nQuê hương mang nặng nghĩa tình\r\nQuê hương tôi đó đẹp xinh tuyệt vời\r\nQuê hương ta đó là nơi\r\nChôn rau cắt rốn người ơi nhớ về.','Post 2','','publish','open','open','','post-2','','','2022-08-19 10:11:46','2022-08-19 10:11:46','',0,'http://lamminhthien.local/?p=45',0,'post','',0);
INSERT INTO `wp_posts` VALUES (46,1,'2022-08-13 03:29:28','2022-08-13 03:29:28','','Post 2','','inherit','closed','closed','','45-revision-v1','','','2022-08-13 03:29:28','2022-08-13 03:29:28','',45,'http://lamminhthien.local/?p=46',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (47,1,'2022-08-13 03:30:35','2022-08-13 03:30:35','Quê hương là một tiếng ve\r\nLời ru của mẹ trưa hè à ơi\r\nDòng sông con nước đầy vơi\r\nQuê hương là một góc trời tuổi thơ\r\nQuê hương ngày ấy như mơ\r\nTôi là cậu bé dại khờ đáng yêu\r\nQuê hương là tiếng sáo diều\r\nLà cánh cò trắng chiều chiều chân đê\r\nQuê hương là phiên chợ quê\r\nChợ trưa mong mẹ mang về bánh đa\r\nQuê hương là một tiếng gà\r\nBình minh gáy sáng ngân nga xóm làng\r\nQuê hương là cánh đồng vàng\r\nHương thơm lúa chín mênh mang trời chiều\r\nQuê hương là dáng mẹ yêu\r\nÁo nâu nón lá liêu siêu đi về\r\nQuê hương nhắc tới nhớ ghê\r\nAi đi xa cũng mong về chốn xưa\r\nQuê hương là những cơn mưa\r\nQuê hương là những hàng dừa ven kinh\r\nQuê hương mang nặng nghĩa tình\r\nQuê hương tôi đó đẹp xinh tuyệt vời\r\nQuê hương ta đó là nơi\r\nChôn rau cắt rốn người ơi nhớ về.','Post 3','','publish','open','open','','post-3','','','2022-08-19 10:14:27','2022-08-19 10:14:27','',0,'http://lamminhthien.local/?p=47',0,'post','',0);
INSERT INTO `wp_posts` VALUES (48,1,'2022-08-13 03:29:33','2022-08-13 03:29:33','','Post 3','','inherit','closed','closed','','47-revision-v1','','','2022-08-13 03:29:33','2022-08-13 03:29:33','',47,'http://lamminhthien.local/?p=48',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (49,1,'2022-08-13 03:30:24','2022-08-13 03:30:24','Quê hương là một tiếng ve\r\nLời ru của mẹ trưa hè à ơi\r\nDòng sông con nước đầy vơi\r\nQuê hương là một góc trời tuổi thơ\r\nQuê hương ngày ấy như mơ\r\nTôi là cậu bé dại khờ đáng yêu\r\nQuê hương là tiếng sáo diều\r\nLà cánh cò trắng chiều chiều chân đê\r\nQuê hương là phiên chợ quê\r\nChợ trưa mong mẹ mang về bánh đa\r\nQuê hương là một tiếng gà\r\nBình minh gáy sáng ngân nga xóm làng\r\nQuê hương là cánh đồng vàng\r\nHương thơm lúa chín mênh mang trời chiều\r\nQuê hương là dáng mẹ yêu\r\nÁo nâu nón lá liêu siêu đi về\r\nQuê hương nhắc tới nhớ ghê\r\nAi đi xa cũng mong về chốn xưa\r\nQuê hương là những cơn mưa\r\nQuê hương là những hàng dừa ven kinh\r\nQuê hương mang nặng nghĩa tình\r\nQuê hương tôi đó đẹp xinh tuyệt vời\r\nQuê hương ta đó là nơi\r\nChôn rau cắt rốn người ơi nhớ về.','Post 4','','publish','open','open','','post-4','','','2022-08-19 10:12:06','2022-08-19 10:12:06','',0,'http://lamminhthien.local/?p=49',0,'post','',0);
INSERT INTO `wp_posts` VALUES (50,1,'2022-08-13 03:29:39','2022-08-13 03:29:39','','Post 4','','inherit','closed','closed','','49-revision-v1','','','2022-08-13 03:29:39','2022-08-13 03:29:39','',49,'http://lamminhthien.local/?p=50',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (51,1,'2022-08-13 03:30:11','2022-08-13 03:30:11','Quê hương là một tiếng ve\r\nLời ru của mẹ trưa hè à ơi\r\nDòng sông con nước đầy vơi\r\nQuê hương là một góc trời tuổi thơ\r\nQuê hương ngày ấy như mơ\r\nTôi là cậu bé dại khờ đáng yêu\r\nQuê hương là tiếng sáo diều\r\nLà cánh cò trắng chiều chiều chân đê\r\nQuê hương là phiên chợ quê\r\nChợ trưa mong mẹ mang về bánh đa\r\nQuê hương là một tiếng gà\r\nBình minh gáy sáng ngân nga xóm làng\r\nQuê hương là cánh đồng vàng\r\nHương thơm lúa chín mênh mang trời chiều\r\nQuê hương là dáng mẹ yêu\r\nÁo nâu nón lá liêu siêu đi về\r\nQuê hương nhắc tới nhớ ghê\r\nAi đi xa cũng mong về chốn xưa\r\nQuê hương là những cơn mưa\r\nQuê hương là những hàng dừa ven kinh\r\nQuê hương mang nặng nghĩa tình\r\nQuê hương tôi đó đẹp xinh tuyệt vời\r\nQuê hương ta đó là nơi\r\nChôn rau cắt rốn người ơi nhớ về.','Post 5','','publish','open','open','','post-5','','','2022-08-19 10:15:06','2022-08-19 10:15:06','',0,'http://lamminhthien.local/?p=51',0,'post','',0);
INSERT INTO `wp_posts` VALUES (52,1,'2022-08-13 03:29:43','2022-08-13 03:29:43','','Post 5','','inherit','closed','closed','','51-revision-v1','','','2022-08-13 03:29:43','2022-08-13 03:29:43','',51,'http://lamminhthien.local/?p=52',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (53,1,'2022-08-13 03:29:54','2022-08-13 03:29:54','Quê hương là một tiếng ve\r\nLời ru của mẹ trưa hè à ơi\r\nDòng sông con nước đầy vơi\r\nQuê hương là một góc trời tuổi thơ\r\nQuê hương ngày ấy như mơ\r\nTôi là cậu bé dại khờ đáng yêu\r\nQuê hương là tiếng sáo diều\r\nLà cánh cò trắng chiều chiều chân đê\r\nQuê hương là phiên chợ quê\r\nChợ trưa mong mẹ mang về bánh đa\r\nQuê hương là một tiếng gà\r\nBình minh gáy sáng ngân nga xóm làng\r\nQuê hương là cánh đồng vàng\r\nHương thơm lúa chín mênh mang trời chiều\r\nQuê hương là dáng mẹ yêu\r\nÁo nâu nón lá liêu siêu đi về\r\nQuê hương nhắc tới nhớ ghê\r\nAi đi xa cũng mong về chốn xưa\r\nQuê hương là những cơn mưa\r\nQuê hương là những hàng dừa ven kinh\r\nQuê hương mang nặng nghĩa tình\r\nQuê hương tôi đó đẹp xinh tuyệt vời\r\nQuê hương ta đó là nơi\r\nChôn rau cắt rốn người ơi nhớ về.','Post 6','','publish','open','open','','post-6','','','2022-08-19 10:16:20','2022-08-19 10:16:20','',0,'http://lamminhthien.local/?p=53',0,'post','',0);
INSERT INTO `wp_posts` VALUES (54,1,'2022-08-13 03:29:48','2022-08-13 03:29:48','','Post 6','','inherit','closed','closed','','53-revision-v1','','','2022-08-13 03:29:48','2022-08-13 03:29:48','',53,'http://lamminhthien.local/?p=54',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (55,1,'2022-08-13 03:51:59','2022-08-13 03:51:59','Quê hương là một tiếng ve\r\nLời ru của mẹ trưa hè à ơi\r\nDòng sông con nước đầy vơi\r\nQuê hương là một góc trời tuổi thơ\r\nQuê hương ngày ấy như mơ\r\nTôi là cậu bé dại khờ đáng yêu\r\nQuê hương là tiếng sáo diều\r\nLà cánh cò trắng chiều chiều chân đê\r\nQuê hương là phiên chợ quê\r\nChợ trưa mong mẹ mang về bánh đa\r\nQuê hương là một tiếng gà\r\nBình minh gáy sáng ngân nga xóm làng\r\nQuê hương là cánh đồng vàng\r\nHương thơm lúa chín mênh mang trời chiều\r\nQuê hương là dáng mẹ yêu\r\nÁo nâu nón lá liêu siêu đi về\r\nQuê hương nhắc tới nhớ ghê\r\nAi đi xa cũng mong về chốn xưa\r\nQuê hương là những cơn mưa\r\nQuê hương là những hàng dừa ven kinh\r\nQuê hương mang nặng nghĩa tình\r\nQuê hương tôi đó đẹp xinh tuyệt vời\r\nQuê hương ta đó là nơi\r\nChôn rau cắt rốn người ơi nhớ về.','Post 7','','publish','open','open','','post-7','','','2022-08-19 10:11:38','2022-08-19 10:11:38','',0,'http://lamminhthien.local/?p=55',0,'post','',0);
INSERT INTO `wp_posts` VALUES (56,1,'2022-08-13 03:51:59','2022-08-13 03:51:59','','Post 7','','inherit','closed','closed','','55-revision-v1','','','2022-08-13 03:51:59','2022-08-13 03:51:59','',55,'http://lamminhthien.local/?p=56',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (57,1,'2022-08-13 03:52:09','2022-08-13 03:52:09','Quê hương là một tiếng ve\r\nLời ru của mẹ trưa hè à ơi\r\nDòng sông con nước đầy vơi\r\nQuê hương là một góc trời tuổi thơ\r\nQuê hương ngày ấy như mơ\r\nTôi là cậu bé dại khờ đáng yêu\r\nQuê hương là tiếng sáo diều\r\nLà cánh cò trắng chiều chiều chân đê\r\nQuê hương là phiên chợ quê\r\nChợ trưa mong mẹ mang về bánh đa\r\nQuê hương là một tiếng gà\r\nBình minh gáy sáng ngân nga xóm làng\r\nQuê hương là cánh đồng vàng\r\nHương thơm lúa chín mênh mang trời chiều\r\nQuê hương là dáng mẹ yêu\r\nÁo nâu nón lá liêu siêu đi về\r\nQuê hương nhắc tới nhớ ghê\r\nAi đi xa cũng mong về chốn xưa\r\nQuê hương là những cơn mưa\r\nQuê hương là những hàng dừa ven kinh\r\nQuê hương mang nặng nghĩa tình\r\nQuê hương tôi đó đẹp xinh tuyệt vời\r\nQuê hương ta đó là nơi\r\nChôn rau cắt rốn người ơi nhớ về.','Post 8','','publish','open','open','','post-8','','','2022-08-19 10:11:28','2022-08-19 10:11:28','',0,'http://lamminhthien.local/?p=57',0,'post','',0);
INSERT INTO `wp_posts` VALUES (58,1,'2022-08-13 03:52:09','2022-08-13 03:52:09','','Post 8','','inherit','closed','closed','','57-revision-v1','','','2022-08-13 03:52:09','2022-08-13 03:52:09','',57,'http://lamminhthien.local/?p=58',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (59,1,'2022-08-28 09:57:54','2022-08-13 04:12:48',' ','','','publish','closed','closed','','59','','','2022-08-28 09:57:54','2022-08-28 09:57:54','',0,'http://lamminhthien.local/?p=59',2,'nav_menu_item','',0);
INSERT INTO `wp_posts` VALUES (61,1,'2022-08-13 04:17:04','2022-08-13 04:17:04','Lorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus hic fuga, temporibus aperiam voluptatum neque accusamus animi quasi vitae odio totam, earum placeat consequuntur quo ratione facilis iure necessitatibus possimus.R','What We Do','','inherit','closed','closed','','39-revision-v1','','','2022-08-13 04:17:04','2022-08-13 04:17:04','',39,'http://lamminhthien.local/?p=61',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (66,1,'2022-08-13 04:36:06','2022-08-13 04:36:06','','Not Home','','publish','closed','closed','','not_home','','','2022-08-29 06:09:28','2022-08-28 23:09:28','',0,'http://lamminhthien.local/?page_id=66',0,'page','',0);
INSERT INTO `wp_posts` VALUES (67,1,'2022-08-13 04:36:06','2022-08-13 04:36:06','','Home','','inherit','closed','closed','','66-revision-v1','','','2022-08-13 04:36:06','2022-08-13 04:36:06','',66,'http://lamminhthien.local/?p=67',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (68,1,'2022-08-18 13:39:52','2022-08-18 13:39:52','','anh-anime-nu-7','','inherit','open','closed','','anh-anime-nu-7','','','2022-08-18 13:39:52','2022-08-18 13:39:52','',43,'http://lamminhthien.local/wp-content/uploads/2022/08/anh-anime-nu-7.jpeg',0,'attachment','image/jpeg',0);
INSERT INTO `wp_posts` VALUES (69,1,'2022-08-18 13:39:53','2022-08-18 13:39:53','','anime-chibi-6','','inherit','open','closed','','anime-chibi-6','','','2022-08-18 13:39:53','2022-08-18 13:39:53','',43,'http://lamminhthien.local/wp-content/uploads/2022/08/anime-chibi-6.jpg',0,'attachment','image/jpeg',0);
INSERT INTO `wp_posts` VALUES (71,1,'2022-08-18 13:40:06','2022-08-18 13:40:06','<div>\r\n<div> Lorem ipsum dolor sit amet consectetur, adipisicing elit. Tempora modi necessitatibus dolor! Quae minima est dolores vero, officiis possimus sint aspernatur iste dolor blanditiis nesciunt et deserunt aliquid facere alias.</div>\r\n</div>','Post 1','','inherit','closed','closed','','43-revision-v1','','','2022-08-18 13:40:06','2022-08-18 13:40:06','',43,'http://lamminhthien.local/?p=71',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (72,1,'2022-08-18 13:40:28','2022-08-18 13:40:28','<div>\r\n<div> Lorem ipsum dolor sit amet consectetur, adipisicing elit. Tempora modi necessitatibus dolor! Quae minima est dolores vero, officiis possimus sint aspernatur iste dolor blanditiis nesciunt et deserunt aliquid facere alias.</div>\r\n</div>','Post 2','','inherit','closed','closed','','45-revision-v1','','','2022-08-18 13:40:28','2022-08-18 13:40:28','',45,'http://lamminhthien.local/?p=72',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (73,1,'2022-08-18 13:41:57','2022-08-18 13:41:57','Lorem ipsum dolor sit amet consectetur, adipisicing elit. Tempora modi necessitatibus dolor! Quae minima est dolores vero, officiis possimus sint aspernatur iste dolor blanditiis nesciunt et deserunt aliquid facere alias.','Post 3','','inherit','closed','closed','','47-revision-v1','','','2022-08-18 13:41:57','2022-08-18 13:41:57','',47,'http://lamminhthien.local/?p=73',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (74,1,'2022-08-18 13:42:16','2022-08-18 13:42:16','Lorem ipsum dolor sit amet consectetur, adipisicing elit. Tempora modi necessitatibus dolor! Quae minima est dolores vero, officiis possimus sint aspernatur iste dolor blanditiis nesciunt et deserunt aliquid facere alias.','Post 4','','inherit','closed','closed','','49-revision-v1','','','2022-08-18 13:42:16','2022-08-18 13:42:16','',49,'http://lamminhthien.local/?p=74',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (75,1,'2022-08-18 13:47:03','2022-08-18 13:47:03','Lorem ipsum dolor sit amet consectetur, adipisicing elit. Tempora modi necessitatibus dolor! Quae minima est dolores vero, officiis possimus sint aspernatur iste dolor blanditiis nesciunt et deserunt aliquid facere alias.','Post 8','','inherit','closed','closed','','57-autosave-v1','','','2022-08-18 13:47:03','2022-08-18 13:47:03','',57,'http://lamminhthien.local/?p=75',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (76,1,'2022-08-18 13:48:06','2022-08-18 13:48:06','Lorem ipsum dolor sit amet consectetur, adipisicing elit. Tempora modi necessitatibus dolor! Quae minima est dolores vero, officiis possimus sint aspernatur iste dolor blanditiis nesciunt et deserunt aliquid facere alias.','Post 8','','inherit','closed','closed','','57-revision-v1','','','2022-08-18 13:48:06','2022-08-18 13:48:06','',57,'http://lamminhthien.local/?p=76',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (77,1,'2022-08-18 13:48:21','2022-08-18 13:48:21','Lorem ipsum dolor sit amet consectetur, adipisicing elit. Tempora modi necessitatibus dolor! Quae minima est dolores vero, officiis possimus sint aspernatur iste dolor blanditiis nesciunt et deserunt aliquid facere alias.','Post 7','','inherit','closed','closed','','55-revision-v1','','','2022-08-18 13:48:21','2022-08-18 13:48:21','',55,'http://lamminhthien.local/?p=77',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (78,1,'2022-08-18 13:48:44','2022-08-18 13:48:44','Lorem ipsum dolor sit amet consectetur, adipisicing elit. Tempora modi necessitatibus dolor! Quae minima est dolores vero, officiis possimus sint aspernatur iste dolor blanditiis nesciunt et deserunt aliquid facere alias.','Post 5','','inherit','closed','closed','','51-revision-v1','','','2022-08-18 13:48:44','2022-08-18 13:48:44','',51,'http://lamminhthien.local/?p=78',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (79,1,'2022-08-18 13:49:06','2022-08-18 13:49:06','Lorem ipsum dolor sit amet consectetur, adipisicing elit. Tempora modi necessitatibus dolor! Quae minima est dolores vero, officiis possimus sint aspernatur iste dolor blanditiis nesciunt et deserunt aliquid facere alias.','Post 6','','inherit','closed','closed','','53-revision-v1','','','2022-08-18 13:49:06','2022-08-18 13:49:06','',53,'http://lamminhthien.local/?p=79',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (80,1,'2022-08-19 04:44:06','0000-00-00 00:00:00',' ','','','draft','closed','closed','','','','','2022-08-19 04:44:06','0000-00-00 00:00:00','',0,'http://lamminhthien.local/?p=80',1,'nav_menu_item','',0);
INSERT INTO `wp_posts` VALUES (82,1,'2022-08-19 04:50:09','2022-08-19 04:50:09','Một con gà tây tán gẫu với con bò: “Mình cực kì yêu thích leo lên ngọn của cái cây kia, nhưng lại không có đủ sức (gà tây thở dài).\r\n\r\nCon bò góp ý: “Vậy bạn thử ăn chất thải của mình coi sao? Chúng chứa rất nhiều dưỡng chất đấy!”.\r\n\r\nGà tây gặm một miếng phân bò và đúng thật là nó cung cấp cho chú nhiều dưỡng chất đủ để leo lên nhánh thấp nhất của cái cây đấy. Ngày tiếp theo, sau khi thưởng thức thêm phân bò, gà tây leo lên được nhánh thứ 2. Cuối cùng sau bốn đêm leo trèo, gà tây đã chễm chệ ngồi trên ngọn cây cao nhất. Tuy nhiên chưa tận hưởng được niềm vui chiến thắng bao lâu, gà tây đã bị bắn chết bởi người nông dân khi ông phát hiện ra nó lấp ló ở ngọn cây.','About','','inherit','closed','closed','','28-revision-v1','','','2022-08-19 04:50:09','2022-08-19 04:50:09','',28,'http://lamminhthien.local/?p=82',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (83,1,'2022-08-19 04:51:35','2022-08-19 04:51:35','','About','','inherit','closed','closed','','27-revision-v1','','','2022-08-19 04:51:35','2022-08-19 04:51:35','',27,'http://lamminhthien.local/?p=83',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (84,1,'2022-08-19 04:51:59','2022-08-19 04:51:59','Ông nội và người cháu đích tôn 3 tuổi đang ngồi chơi trò bán hàng.\r\n\r\n<strong>- Cháu:</strong> Đây tôi đưa bác 5.000 đồng, nhưng với một điều kiện.\r\n<strong>- Ông:</strong> Điều kiện gì cũng được.\r\n<strong>- Cháu:</strong> Thật không?\r\n<strong>- Ông:</strong> Thật. Bác cứ nói đi.\r\n<strong>- Cháu:</strong> Bác phải về dạy lại con bác đi nhé, con bác hay đánh tôi lắm đấy.','What We Do','','inherit','closed','closed','','39-revision-v1','','','2022-08-19 04:51:59','2022-08-19 04:51:59','',39,'http://lamminhthien.local/?p=84',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (86,1,'2022-08-19 04:53:01','2022-08-19 04:53:01','','anime-chibi-6','','inherit','open','closed','','anime-chibi-6-2','','','2022-08-19 04:53:01','2022-08-19 04:53:01','',66,'http://lamminhthien.local/wp-content/uploads/2022/08/anime-chibi-6-1.jpg',0,'attachment','image/jpeg',0);
INSERT INTO `wp_posts` VALUES (87,1,'2022-08-19 04:53:47','2022-08-19 04:53:47','Bob đi ăn uống liên hoan về say khướt. Anh ta về nhà, đập cửa:\r\n\r\n- Ồ, Bob! Anh đã về đấy ư?\r\n\r\n- Ừ, em yêu ạ, anh gặp bạn cũ.\r\n\r\n- Anh nhậu hết lương tháng rồi.\r\n\r\n- À, em có thể hiểu.\r\n\r\n- Xe lại bị giữ...\r\n\r\n- Chuyện đương nhiên mà.\r\n\r\n- Ôi, em đúng là người phụ nữ hiền dịu nhất trần đời. Ừm... Ờ... Hình như cái dây chuyền em đưa hôm qua, anh trót tặng một cô gái.\r\n\r\n- Lạy Chúa, em thật là may mắn!\r\n\r\n- Sao, em định nói là em rất hài lòng ư?\r\n\r\n- Vâng, vì em chỉ là... Hàng xóm của anh. Hãy can đảm lên, chỉ còn vài bước chân nữa thôi. Cầu Chúa phù hộ cho anh!','Home','','inherit','closed','closed','','66-revision-v1','','','2022-08-19 04:53:47','2022-08-19 04:53:47','',66,'http://lamminhthien.local/?p=87',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (88,1,'2022-08-28 09:57:54','2022-08-19 04:54:30',' ','','','publish','closed','closed','','88','','','2022-08-28 09:57:54','2022-08-28 09:57:54','',0,'http://lamminhthien.local/?p=88',1,'nav_menu_item','',0);
INSERT INTO `wp_posts` VALUES (89,1,'2022-08-19 08:26:10','2022-08-19 08:26:10','<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->','Hello world!','','inherit','closed','closed','','1-revision-v1','','','2022-08-19 08:26:10','2022-08-19 08:26:10','',1,'http://lamminhthien.local/?p=89',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (90,1,'2022-08-28 09:57:18','2022-08-19 09:11:53',' ','','','publish','closed','closed','','90','','','2022-08-28 09:57:18','2022-08-28 09:57:18','',0,'http://lamminhthien.local/?p=90',1,'nav_menu_item','',0);
INSERT INTO `wp_posts` VALUES (91,1,'2022-08-28 09:57:18','2022-08-19 09:11:53',' ','','','publish','closed','closed','','91','','','2022-08-28 09:57:18','2022-08-28 09:57:18','',0,'http://lamminhthien.local/?p=91',2,'nav_menu_item','',0);
INSERT INTO `wp_posts` VALUES (92,1,'2022-08-28 09:57:18','2022-08-19 09:11:53',' ','','','publish','closed','closed','','92','','','2022-08-28 09:57:18','2022-08-28 09:57:18','',0,'http://lamminhthien.local/?p=92',3,'nav_menu_item','',0);
INSERT INTO `wp_posts` VALUES (93,1,'2022-08-28 09:57:18','2022-08-19 09:12:13',' ','','','publish','closed','closed','','93','','','2022-08-28 09:57:18','2022-08-28 09:57:18','',0,'http://lamminhthien.local/?p=93',4,'nav_menu_item','',0);
INSERT INTO `wp_posts` VALUES (94,1,'2022-08-19 10:11:18','2022-08-19 10:11:18','Quê hương là một tiếng ve\r\nLời ru của mẹ trưa hè à ơi\r\nDòng sông con nước đầy vơi\r\nQuê hương là một góc trời tuổi thơ\r\nQuê hương ngày ấy như mơ\r\nTôi là cậu bé dại khờ đáng yêu\r\nQuê hương là tiếng sáo diều\r\nLà cánh cò trắng chiều chiều chân đê\r\nQuê hương là phiên chợ quê\r\nChợ trưa mong mẹ mang về bánh đa\r\nQuê hương là một tiếng gà\r\nBình minh gáy sáng ngân nga xóm làng\r\nQuê hương là cánh đồng vàng\r\nHương thơm lúa chín mênh mang trời chiều\r\nQuê hương là dáng mẹ yêu\r\nÁo nâu nón lá liêu siêu đi về\r\nQuê hương nhắc tới nhớ ghê\r\nAi đi xa cũng mong về chốn xưa\r\nQuê hương là những cơn mưa\r\nQuê hương là những hàng dừa ven kinh\r\nQuê hương mang nặng nghĩa tình\r\nQuê hương tôi đó đẹp xinh tuyệt vời\r\nQuê hương ta đó là nơi\r\nChôn rau cắt rốn người ơi nhớ về.','Post 1','','inherit','closed','closed','','43-revision-v1','','','2022-08-19 10:11:18','2022-08-19 10:11:18','',43,'http://lamminhthien.local/?p=94',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (95,1,'2022-08-19 10:11:28','2022-08-19 10:11:28','Quê hương là một tiếng ve\r\nLời ru của mẹ trưa hè à ơi\r\nDòng sông con nước đầy vơi\r\nQuê hương là một góc trời tuổi thơ\r\nQuê hương ngày ấy như mơ\r\nTôi là cậu bé dại khờ đáng yêu\r\nQuê hương là tiếng sáo diều\r\nLà cánh cò trắng chiều chiều chân đê\r\nQuê hương là phiên chợ quê\r\nChợ trưa mong mẹ mang về bánh đa\r\nQuê hương là một tiếng gà\r\nBình minh gáy sáng ngân nga xóm làng\r\nQuê hương là cánh đồng vàng\r\nHương thơm lúa chín mênh mang trời chiều\r\nQuê hương là dáng mẹ yêu\r\nÁo nâu nón lá liêu siêu đi về\r\nQuê hương nhắc tới nhớ ghê\r\nAi đi xa cũng mong về chốn xưa\r\nQuê hương là những cơn mưa\r\nQuê hương là những hàng dừa ven kinh\r\nQuê hương mang nặng nghĩa tình\r\nQuê hương tôi đó đẹp xinh tuyệt vời\r\nQuê hương ta đó là nơi\r\nChôn rau cắt rốn người ơi nhớ về.','Post 8','','inherit','closed','closed','','57-revision-v1','','','2022-08-19 10:11:28','2022-08-19 10:11:28','',57,'http://lamminhthien.local/?p=95',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (96,1,'2022-08-19 10:11:38','2022-08-19 10:11:38','Quê hương là một tiếng ve\r\nLời ru của mẹ trưa hè à ơi\r\nDòng sông con nước đầy vơi\r\nQuê hương là một góc trời tuổi thơ\r\nQuê hương ngày ấy như mơ\r\nTôi là cậu bé dại khờ đáng yêu\r\nQuê hương là tiếng sáo diều\r\nLà cánh cò trắng chiều chiều chân đê\r\nQuê hương là phiên chợ quê\r\nChợ trưa mong mẹ mang về bánh đa\r\nQuê hương là một tiếng gà\r\nBình minh gáy sáng ngân nga xóm làng\r\nQuê hương là cánh đồng vàng\r\nHương thơm lúa chín mênh mang trời chiều\r\nQuê hương là dáng mẹ yêu\r\nÁo nâu nón lá liêu siêu đi về\r\nQuê hương nhắc tới nhớ ghê\r\nAi đi xa cũng mong về chốn xưa\r\nQuê hương là những cơn mưa\r\nQuê hương là những hàng dừa ven kinh\r\nQuê hương mang nặng nghĩa tình\r\nQuê hương tôi đó đẹp xinh tuyệt vời\r\nQuê hương ta đó là nơi\r\nChôn rau cắt rốn người ơi nhớ về.','Post 7','','inherit','closed','closed','','55-revision-v1','','','2022-08-19 10:11:38','2022-08-19 10:11:38','',55,'http://lamminhthien.local/?p=96',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (97,1,'2022-08-19 10:11:46','2022-08-19 10:11:46','Quê hương là một tiếng ve\r\nLời ru của mẹ trưa hè à ơi\r\nDòng sông con nước đầy vơi\r\nQuê hương là một góc trời tuổi thơ\r\nQuê hương ngày ấy như mơ\r\nTôi là cậu bé dại khờ đáng yêu\r\nQuê hương là tiếng sáo diều\r\nLà cánh cò trắng chiều chiều chân đê\r\nQuê hương là phiên chợ quê\r\nChợ trưa mong mẹ mang về bánh đa\r\nQuê hương là một tiếng gà\r\nBình minh gáy sáng ngân nga xóm làng\r\nQuê hương là cánh đồng vàng\r\nHương thơm lúa chín mênh mang trời chiều\r\nQuê hương là dáng mẹ yêu\r\nÁo nâu nón lá liêu siêu đi về\r\nQuê hương nhắc tới nhớ ghê\r\nAi đi xa cũng mong về chốn xưa\r\nQuê hương là những cơn mưa\r\nQuê hương là những hàng dừa ven kinh\r\nQuê hương mang nặng nghĩa tình\r\nQuê hương tôi đó đẹp xinh tuyệt vời\r\nQuê hương ta đó là nơi\r\nChôn rau cắt rốn người ơi nhớ về.','Post 2','','inherit','closed','closed','','45-revision-v1','','','2022-08-19 10:11:46','2022-08-19 10:11:46','',45,'http://lamminhthien.local/?p=97',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (98,1,'2022-08-19 10:12:06','2022-08-19 10:12:06','Quê hương là một tiếng ve\r\nLời ru của mẹ trưa hè à ơi\r\nDòng sông con nước đầy vơi\r\nQuê hương là một góc trời tuổi thơ\r\nQuê hương ngày ấy như mơ\r\nTôi là cậu bé dại khờ đáng yêu\r\nQuê hương là tiếng sáo diều\r\nLà cánh cò trắng chiều chiều chân đê\r\nQuê hương là phiên chợ quê\r\nChợ trưa mong mẹ mang về bánh đa\r\nQuê hương là một tiếng gà\r\nBình minh gáy sáng ngân nga xóm làng\r\nQuê hương là cánh đồng vàng\r\nHương thơm lúa chín mênh mang trời chiều\r\nQuê hương là dáng mẹ yêu\r\nÁo nâu nón lá liêu siêu đi về\r\nQuê hương nhắc tới nhớ ghê\r\nAi đi xa cũng mong về chốn xưa\r\nQuê hương là những cơn mưa\r\nQuê hương là những hàng dừa ven kinh\r\nQuê hương mang nặng nghĩa tình\r\nQuê hương tôi đó đẹp xinh tuyệt vời\r\nQuê hương ta đó là nơi\r\nChôn rau cắt rốn người ơi nhớ về.','Post 4','','inherit','closed','closed','','49-revision-v1','','','2022-08-19 10:12:06','2022-08-19 10:12:06','',49,'http://lamminhthien.local/?p=98',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (99,1,'2022-08-19 10:14:27','2022-08-19 10:14:27','Quê hương là một tiếng ve\r\nLời ru của mẹ trưa hè à ơi\r\nDòng sông con nước đầy vơi\r\nQuê hương là một góc trời tuổi thơ\r\nQuê hương ngày ấy như mơ\r\nTôi là cậu bé dại khờ đáng yêu\r\nQuê hương là tiếng sáo diều\r\nLà cánh cò trắng chiều chiều chân đê\r\nQuê hương là phiên chợ quê\r\nChợ trưa mong mẹ mang về bánh đa\r\nQuê hương là một tiếng gà\r\nBình minh gáy sáng ngân nga xóm làng\r\nQuê hương là cánh đồng vàng\r\nHương thơm lúa chín mênh mang trời chiều\r\nQuê hương là dáng mẹ yêu\r\nÁo nâu nón lá liêu siêu đi về\r\nQuê hương nhắc tới nhớ ghê\r\nAi đi xa cũng mong về chốn xưa\r\nQuê hương là những cơn mưa\r\nQuê hương là những hàng dừa ven kinh\r\nQuê hương mang nặng nghĩa tình\r\nQuê hương tôi đó đẹp xinh tuyệt vời\r\nQuê hương ta đó là nơi\r\nChôn rau cắt rốn người ơi nhớ về.','Post 3','','inherit','closed','closed','','47-revision-v1','','','2022-08-19 10:14:27','2022-08-19 10:14:27','',47,'http://lamminhthien.local/?p=99',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (100,1,'2022-08-19 10:15:06','2022-08-19 10:15:06','Quê hương là một tiếng ve\r\nLời ru của mẹ trưa hè à ơi\r\nDòng sông con nước đầy vơi\r\nQuê hương là một góc trời tuổi thơ\r\nQuê hương ngày ấy như mơ\r\nTôi là cậu bé dại khờ đáng yêu\r\nQuê hương là tiếng sáo diều\r\nLà cánh cò trắng chiều chiều chân đê\r\nQuê hương là phiên chợ quê\r\nChợ trưa mong mẹ mang về bánh đa\r\nQuê hương là một tiếng gà\r\nBình minh gáy sáng ngân nga xóm làng\r\nQuê hương là cánh đồng vàng\r\nHương thơm lúa chín mênh mang trời chiều\r\nQuê hương là dáng mẹ yêu\r\nÁo nâu nón lá liêu siêu đi về\r\nQuê hương nhắc tới nhớ ghê\r\nAi đi xa cũng mong về chốn xưa\r\nQuê hương là những cơn mưa\r\nQuê hương là những hàng dừa ven kinh\r\nQuê hương mang nặng nghĩa tình\r\nQuê hương tôi đó đẹp xinh tuyệt vời\r\nQuê hương ta đó là nơi\r\nChôn rau cắt rốn người ơi nhớ về.','Post 5','','inherit','closed','closed','','51-revision-v1','','','2022-08-19 10:15:06','2022-08-19 10:15:06','',51,'http://lamminhthien.local/?p=100',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (101,1,'2022-08-19 10:16:20','2022-08-19 10:16:20','Quê hương là một tiếng ve\r\nLời ru của mẹ trưa hè à ơi\r\nDòng sông con nước đầy vơi\r\nQuê hương là một góc trời tuổi thơ\r\nQuê hương ngày ấy như mơ\r\nTôi là cậu bé dại khờ đáng yêu\r\nQuê hương là tiếng sáo diều\r\nLà cánh cò trắng chiều chiều chân đê\r\nQuê hương là phiên chợ quê\r\nChợ trưa mong mẹ mang về bánh đa\r\nQuê hương là một tiếng gà\r\nBình minh gáy sáng ngân nga xóm làng\r\nQuê hương là cánh đồng vàng\r\nHương thơm lúa chín mênh mang trời chiều\r\nQuê hương là dáng mẹ yêu\r\nÁo nâu nón lá liêu siêu đi về\r\nQuê hương nhắc tới nhớ ghê\r\nAi đi xa cũng mong về chốn xưa\r\nQuê hương là những cơn mưa\r\nQuê hương là những hàng dừa ven kinh\r\nQuê hương mang nặng nghĩa tình\r\nQuê hương tôi đó đẹp xinh tuyệt vời\r\nQuê hương ta đó là nơi\r\nChôn rau cắt rốn người ơi nhớ về.','Post 6','','inherit','closed','closed','','53-revision-v1','','','2022-08-19 10:16:20','2022-08-19 10:16:20','',53,'http://lamminhthien.local/?p=101',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (103,1,'2022-08-20 02:45:19','2022-08-20 02:45:19','a:8:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:4:\"post\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";s:12:\"show_in_rest\";i:0;}','Flexible content','flexible-content','trash','closed','closed','','group_63004a8f7900f__trashed','','','2022-08-20 02:54:54','2022-08-20 02:54:54','',0,'http://lamminhthien.local/?post_type=acf-field-group&#038;p=103',0,'acf-field-group','',0);
INSERT INTO `wp_posts` VALUES (104,1,'2022-08-20 02:45:19','2022-08-20 02:45:19','a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}','','','trash','closed','closed','','field_63004ab48119c__trashed','','','2022-08-20 02:54:54','2022-08-20 02:54:54','',103,'http://lamminhthien.local/?post_type=acf-field&#038;p=104',0,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (105,1,'2022-08-20 02:46:22','2022-08-20 02:46:22','a:8:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:4:\"page\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";s:12:\"show_in_rest\";i:0;}','Flexible content','flexible-content','publish','closed','closed','','group_63004ad1169a2','','','2022-08-29 06:43:10','2022-08-28 23:43:10','',0,'http://lamminhthien.local/?post_type=acf-field-group&#038;p=105',0,'acf-field-group','',0);
INSERT INTO `wp_posts` VALUES (106,1,'2022-08-20 02:46:22','2022-08-20 02:46:22','a:9:{s:4:\"type\";s:16:\"flexible_content\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"layouts\";a:6:{s:20:\"layout_63004af8cb9c1\";a:6:{s:3:\"key\";s:20:\"layout_63004af8cb9c1\";s:5:\"label\";s:6:\"Banner\";s:4:\"name\";s:6:\"banner\";s:7:\"display\";s:5:\"block\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";}s:20:\"layout_630b24986d744\";a:6:{s:3:\"key\";s:20:\"layout_630b24986d744\";s:5:\"label\";s:14:\"Who Trusted Us\";s:4:\"name\";s:14:\"who_trusted_us\";s:7:\"display\";s:5:\"block\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";}s:20:\"layout_630b338ac7a8d\";a:6:{s:3:\"key\";s:20:\"layout_630b338ac7a8d\";s:5:\"label\";s:12:\"Who We Serve\";s:4:\"name\";s:12:\"who_we_serve\";s:7:\"display\";s:5:\"block\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";}s:20:\"layout_630b29488b3e1\";a:6:{s:3:\"key\";s:20:\"layout_630b29488b3e1\";s:5:\"label\";s:8:\"Services\";s:4:\"name\";s:8:\"services\";s:7:\"display\";s:5:\"block\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";}s:20:\"layout_630b399a2a1e1\";a:6:{s:3:\"key\";s:20:\"layout_630b399a2a1e1\";s:5:\"label\";s:12:\"Work With Us\";s:4:\"name\";s:12:\"work_with_us\";s:7:\"display\";s:5:\"block\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";}s:20:\"layout_630b5ea41a8fb\";a:6:{s:3:\"key\";s:20:\"layout_630b5ea41a8fb\";s:5:\"label\";s:8:\"Articles\";s:4:\"name\";s:8:\"articles\";s:7:\"display\";s:5:\"block\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";}}s:12:\"button_label\";s:7:\"Add Row\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";}','Flexible content','flexible_content','publish','closed','closed','','field_63004ae978f3c','','','2022-08-28 12:26:11','2022-08-28 12:26:11','',105,'http://lamminhthien.local/?post_type=acf-field&#038;p=106',0,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (107,1,'2022-08-20 02:53:20','2022-08-20 02:53:20','a:11:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"parent_layout\";s:20:\"layout_63004af8cb9c1\";s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}','Title','title','publish','closed','closed','','field_63004ba19c354','','','2022-08-20 02:53:20','2022-08-20 02:53:20','',106,'http://lamminhthien.local/?post_type=acf-field&p=107',0,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (108,1,'2022-08-20 02:53:20','2022-08-20 02:53:20','a:11:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"parent_layout\";s:20:\"layout_63004af8cb9c1\";s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}','Headline','headline','publish','closed','closed','','field_63004c3f9c355','','','2022-08-28 08:10:18','2022-08-28 08:10:18','',106,'http://lamminhthien.local/?post_type=acf-field&#038;p=108',1,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (109,1,'2022-08-20 02:53:20','2022-08-20 02:53:20','a:8:{s:4:\"type\";s:3:\"url\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"parent_layout\";s:20:\"layout_63004af8cb9c1\";s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";}','Link','link','publish','closed','closed','','field_63004c4b9c356','','','2022-08-20 02:53:20','2022-08-20 02:53:20','',106,'http://lamminhthien.local/?post_type=acf-field&p=109',2,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (110,1,'2022-08-20 02:53:20','2022-08-20 02:53:20','a:16:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"parent_layout\";s:20:\"layout_63004af8cb9c1\";s:13:\"return_format\";s:5:\"array\";s:12:\"preview_size\";s:6:\"medium\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}','Logo','logo','publish','closed','closed','','field_63004c5c9c357','','','2022-08-20 02:53:20','2022-08-20 02:53:20','',106,'http://lamminhthien.local/?post_type=acf-field&p=110',3,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (111,1,'2022-08-20 02:58:08','2022-08-20 02:58:08','Một con gà tây tán gẫu với con bò: “Mình cực kì yêu thích leo lên ngọn của cái cây kia, nhưng lại không có đủ sức (gà tây thở dài).\r\n\r\nCon bò góp ý: “Vậy bạn thử ăn chất thải của mình coi sao? Chúng chứa rất nhiều dưỡng chất đấy!”.\r\n\r\nGà tây gặm một miếng phân bò và đúng thật là nó cung cấp cho chú nhiều dưỡng chất đủ để leo lên nhánh thấp nhất của cái cây đấy. Ngày tiếp theo, sau khi thưởng thức thêm phân bò, gà tây leo lên được nhánh thứ 2. Cuối cùng sau bốn đêm leo trèo, gà tây đã chễm chệ ngồi trên ngọn cây cao nhất. Tuy nhiên chưa tận hưởng được niềm vui chiến thắng bao lâu, gà tây đã bị bắn chết bởi người nông dân khi ông phát hiện ra nó lấp ló ở ngọn cây.','About','','inherit','closed','closed','','28-revision-v1','','','2022-08-20 02:58:08','2022-08-20 02:58:08','',28,'http://lamminhthien.local/?p=111',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (112,1,'2022-08-20 03:02:41','2022-08-20 03:02:41','','logo-abc','','inherit','open','closed','','logo-abc','','','2022-08-20 03:06:05','2022-08-20 03:06:05','',28,'http://lamminhthien.local/wp-content/uploads/2022/08/logo-abc.svg',0,'attachment','image/svg+xml',0);
INSERT INTO `wp_posts` VALUES (113,1,'2022-08-20 03:06:05','2022-08-20 03:06:05','Một con gà tây tán gẫu với con bò: “Mình cực kì yêu thích leo lên ngọn của cái cây kia, nhưng lại không có đủ sức (gà tây thở dài).\r\n\r\nCon bò góp ý: “Vậy bạn thử ăn chất thải của mình coi sao? Chúng chứa rất nhiều dưỡng chất đấy!”.\r\n\r\nGà tây gặm một miếng phân bò và đúng thật là nó cung cấp cho chú nhiều dưỡng chất đủ để leo lên nhánh thấp nhất của cái cây đấy. Ngày tiếp theo, sau khi thưởng thức thêm phân bò, gà tây leo lên được nhánh thứ 2. Cuối cùng sau bốn đêm leo trèo, gà tây đã chễm chệ ngồi trên ngọn cây cao nhất. Tuy nhiên chưa tận hưởng được niềm vui chiến thắng bao lâu, gà tây đã bị bắn chết bởi người nông dân khi ông phát hiện ra nó lấp ló ở ngọn cây.','About','','inherit','closed','closed','','28-revision-v1','','','2022-08-20 03:06:05','2022-08-20 03:06:05','',28,'http://lamminhthien.local/?p=113',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (114,1,'2022-08-20 03:41:52','2022-08-20 03:41:52','Một con gà tây tán gẫu với con bò: “Mình cực kì yêu thích leo lên ngọn của cái cây kia, nhưng lại không có đủ sức (gà tây thở dài).\r\n\r\nCon bò góp ý: “Vậy bạn thử ăn chất thải của mình coi sao? Chúng chứa rất nhiều dưỡng chất đấy!”.\r\n\r\nGà tây gặm một miếng phân bò và đúng thật là nó cung cấp cho chú nhiều dưỡng chất đủ để leo lên nhánh thấp nhất của cái cây đấy. Ngày tiếp theo, sau khi thưởng thức thêm phân bò, gà tây leo lên được nhánh thứ 2. Cuối cùng sau bốn đêm leo trèo, gà tây đã chễm chệ ngồi trên ngọn cây cao nhất. Tuy nhiên chưa tận hưởng được niềm vui chiến thắng bao lâu, gà tây đã bị bắn chết bởi người nông dân khi ông phát hiện ra nó lấp ló ở ngọn cây.','About','','inherit','closed','closed','','28-revision-v1','','','2022-08-20 03:41:52','2022-08-20 03:41:52','',28,'http://lamminhthien.local/?p=114',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (115,1,'2022-08-27 03:17:24','0000-00-00 00:00:00','','Auto Draft','','auto-draft','open','open','','','','','2022-08-27 03:17:24','0000-00-00 00:00:00','',0,'http://lamminhthien.local/?p=115',0,'post','',0);
INSERT INTO `wp_posts` VALUES (116,1,'2022-08-28 08:10:22','2022-08-28 08:10:22','Một con gà tây tán gẫu với con bò: “Mình cực kì yêu thích leo lên ngọn của cái cây kia, nhưng lại không có đủ sức (gà tây thở dài).\r\n\r\nCon bò góp ý: “Vậy bạn thử ăn chất thải của mình coi sao? Chúng chứa rất nhiều dưỡng chất đấy!”.\r\n\r\nGà tây gặm một miếng phân bò và đúng thật là nó cung cấp cho chú nhiều dưỡng chất đủ để leo lên nhánh thấp nhất của cái cây đấy. Ngày tiếp theo, sau khi thưởng thức thêm phân bò, gà tây leo lên được nhánh thứ 2. Cuối cùng sau bốn đêm leo trèo, gà tây đã chễm chệ ngồi trên ngọn cây cao nhất. Tuy nhiên chưa tận hưởng được niềm vui chiến thắng bao lâu, gà tây đã bị bắn chết bởi người nông dân khi ông phát hiện ra nó lấp ló ở ngọn cây.','About','','inherit','closed','closed','','28-revision-v1','','','2022-08-28 08:10:22','2022-08-28 08:10:22','',28,'http://lamminhthien.local/?p=116',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (117,1,'2022-08-28 08:22:21','2022-08-28 08:22:21','a:11:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"parent_layout\";s:20:\"layout_630b24986d744\";s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}','Title','title','publish','closed','closed','','field_630b24fc6d745','','','2022-08-28 08:22:21','2022-08-28 08:22:21','',106,'http://lamminhthien.local/?post_type=acf-field&p=117',0,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (118,1,'2022-08-28 08:22:21','2022-08-28 08:22:21','a:11:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"parent_layout\";s:20:\"layout_630b24986d744\";s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}','Headline','headline','publish','closed','closed','','field_630b25016d746','','','2022-08-28 08:22:21','2022-08-28 08:22:21','',106,'http://lamminhthien.local/?post_type=acf-field&p=118',1,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (119,1,'2022-08-28 08:22:21','2022-08-28 08:22:21','a:11:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"parent_layout\";s:20:\"layout_630b24986d744\";s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:0:\"\";}','Partner','partner','publish','closed','closed','','field_630b250d6d747','','','2022-08-28 08:22:21','2022-08-28 08:22:21','',106,'http://lamminhthien.local/?post_type=acf-field&p=119',2,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (120,1,'2022-08-28 08:22:21','2022-08-28 08:22:21','a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:6:\"medium\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}','Logo','logo','publish','closed','closed','','field_630b25916d748','','','2022-08-28 08:22:21','2022-08-28 08:22:21','',119,'http://lamminhthien.local/?post_type=acf-field&p=120',0,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (121,1,'2022-08-28 08:23:31','2022-08-28 08:23:31','This is description This is description This is description This is description This is description','company-1','','inherit','open','closed','','company-1','','','2022-08-28 08:42:56','2022-08-28 08:42:56','',28,'http://lamminhthien.local/wp-content/uploads/2022/08/company-1.svg',0,'attachment','image/svg+xml',0);
INSERT INTO `wp_posts` VALUES (122,1,'2022-08-28 08:24:02','2022-08-28 08:24:02','','company-2','','inherit','open','closed','','company-2','','','2022-08-28 08:24:02','2022-08-28 08:24:02','',28,'http://lamminhthien.local/wp-content/uploads/2022/08/company-2.svg',0,'attachment','image/svg+xml',0);
INSERT INTO `wp_posts` VALUES (123,1,'2022-08-28 08:24:02','2022-08-28 08:24:02','','company-3','','inherit','open','closed','','company-3','','','2022-08-28 08:24:02','2022-08-28 08:24:02','',28,'http://lamminhthien.local/wp-content/uploads/2022/08/company-3.svg',0,'attachment','image/svg+xml',0);
INSERT INTO `wp_posts` VALUES (124,1,'2022-08-28 08:24:03','2022-08-28 08:24:03','','company-4','','inherit','open','closed','','company-4','','','2022-08-28 08:24:03','2022-08-28 08:24:03','',28,'http://lamminhthien.local/wp-content/uploads/2022/08/company-4.svg',0,'attachment','image/svg+xml',0);
INSERT INTO `wp_posts` VALUES (125,1,'2022-08-28 08:24:03','2022-08-28 08:24:03','','company-5','','inherit','open','closed','','company-5','','','2022-08-28 08:24:03','2022-08-28 08:24:03','',28,'http://lamminhthien.local/wp-content/uploads/2022/08/company-5.svg',0,'attachment','image/svg+xml',0);
INSERT INTO `wp_posts` VALUES (126,1,'2022-08-28 08:24:03','2022-08-28 08:24:03','','company-6','','inherit','open','closed','','company-6','','','2022-08-28 08:24:03','2022-08-28 08:24:03','',28,'http://lamminhthien.local/wp-content/uploads/2022/08/company-6.svg',0,'attachment','image/svg+xml',0);
INSERT INTO `wp_posts` VALUES (127,1,'2022-08-28 08:24:13','2022-08-28 08:24:13','Một con gà tây tán gẫu với con bò: “Mình cực kì yêu thích leo lên ngọn của cái cây kia, nhưng lại không có đủ sức (gà tây thở dài).\r\n\r\nCon bò góp ý: “Vậy bạn thử ăn chất thải của mình coi sao? Chúng chứa rất nhiều dưỡng chất đấy!”.\r\n\r\nGà tây gặm một miếng phân bò và đúng thật là nó cung cấp cho chú nhiều dưỡng chất đủ để leo lên nhánh thấp nhất của cái cây đấy. Ngày tiếp theo, sau khi thưởng thức thêm phân bò, gà tây leo lên được nhánh thứ 2. Cuối cùng sau bốn đêm leo trèo, gà tây đã chễm chệ ngồi trên ngọn cây cao nhất. Tuy nhiên chưa tận hưởng được niềm vui chiến thắng bao lâu, gà tây đã bị bắn chết bởi người nông dân khi ông phát hiện ra nó lấp ló ở ngọn cây.','About','','inherit','closed','closed','','28-revision-v1','','','2022-08-28 08:24:13','2022-08-28 08:24:13','',28,'http://lamminhthien.local/?p=127',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (128,1,'2022-08-28 08:39:34','2022-08-28 08:39:34','a:11:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"parent_layout\";s:20:\"layout_630b29488b3e1\";s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}','Title','title','publish','closed','closed','','field_630b29518b3e2','','','2022-08-28 08:39:34','2022-08-28 08:39:34','',106,'http://lamminhthien.local/?post_type=acf-field&p=128',0,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (129,1,'2022-08-28 08:39:34','2022-08-28 08:39:34','a:11:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"parent_layout\";s:20:\"layout_630b29488b3e1\";s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}','Headline','headline','publish','closed','closed','','field_630b29638b3e3','','','2022-08-28 08:39:34','2022-08-28 08:39:34','',106,'http://lamminhthien.local/?post_type=acf-field&p=129',1,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (130,1,'2022-08-28 08:39:34','2022-08-28 08:39:34','a:11:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"parent_layout\";s:20:\"layout_630b29488b3e1\";s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:0:\"\";}','Services','services','publish','closed','closed','','field_630b297c8b3e4','','','2022-08-28 08:39:34','2022-08-28 08:39:34','',106,'http://lamminhthien.local/?post_type=acf-field&p=130',2,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (131,1,'2022-08-28 08:39:34','2022-08-28 08:39:34','a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:12:\"preview_size\";s:6:\"medium\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}','Logo','logo','publish','closed','closed','','field_630b29b38b3e5','','','2022-08-28 08:59:17','2022-08-28 08:59:17','',130,'http://lamminhthien.local/?post_type=acf-field&#038;p=131',0,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (132,1,'2022-08-28 08:40:20','2022-08-28 08:40:20','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper.','Advice','','inherit','open','closed','','service-1','','','2022-08-28 08:57:26','2022-08-28 08:57:26','',28,'http://lamminhthien.local/wp-content/uploads/2022/08/service-1.svg',0,'attachment','image/svg+xml',0);
INSERT INTO `wp_posts` VALUES (133,1,'2022-08-28 08:40:20','2022-08-28 08:40:20','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper.','Build','','inherit','open','closed','','service-2','','','2022-08-28 08:57:53','2022-08-28 08:57:53','',28,'http://lamminhthien.local/wp-content/uploads/2022/08/service-2.svg',0,'attachment','image/svg+xml',0);
INSERT INTO `wp_posts` VALUES (134,1,'2022-08-28 08:40:21','2022-08-28 08:40:21','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper.','Run','','inherit','open','closed','','service-3','','','2022-08-28 08:58:19','2022-08-28 08:58:19','',28,'http://lamminhthien.local/wp-content/uploads/2022/08/service-3.svg',0,'attachment','image/svg+xml',0);
INSERT INTO `wp_posts` VALUES (135,1,'2022-08-28 08:40:21','2022-08-28 08:40:21','Etiam vehicula sem mauris, vitae scelerisque arcu ullamcorper.','Optimize','','inherit','open','closed','','service-4','','','2022-08-28 08:58:29','2022-08-28 08:58:29','',28,'http://lamminhthien.local/wp-content/uploads/2022/08/service-4.svg',0,'attachment','image/svg+xml',0);
INSERT INTO `wp_posts` VALUES (136,1,'2022-08-28 08:43:30','2022-08-28 08:43:30','Một con gà tây tán gẫu với con bò: “Mình cực kì yêu thích leo lên ngọn của cái cây kia, nhưng lại không có đủ sức (gà tây thở dài).\r\n\r\nCon bò góp ý: “Vậy bạn thử ăn chất thải của mình coi sao? Chúng chứa rất nhiều dưỡng chất đấy!”.\r\n\r\nGà tây gặm một miếng phân bò và đúng thật là nó cung cấp cho chú nhiều dưỡng chất đủ để leo lên nhánh thấp nhất của cái cây đấy. Ngày tiếp theo, sau khi thưởng thức thêm phân bò, gà tây leo lên được nhánh thứ 2. Cuối cùng sau bốn đêm leo trèo, gà tây đã chễm chệ ngồi trên ngọn cây cao nhất. Tuy nhiên chưa tận hưởng được niềm vui chiến thắng bao lâu, gà tây đã bị bắn chết bởi người nông dân khi ông phát hiện ra nó lấp ló ở ngọn cây.','About','','inherit','closed','closed','','28-revision-v1','','','2022-08-28 08:43:30','2022-08-28 08:43:30','',28,'http://lamminhthien.local/?p=136',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (137,1,'2022-08-28 08:43:52','2022-08-28 08:43:52','Một con gà tây tán gẫu với con bò: “Mình cực kì yêu thích leo lên ngọn của cái cây kia, nhưng lại không có đủ sức (gà tây thở dài).\r\n\r\nCon bò góp ý: “Vậy bạn thử ăn chất thải của mình coi sao? Chúng chứa rất nhiều dưỡng chất đấy!”.\r\n\r\nGà tây gặm một miếng phân bò và đúng thật là nó cung cấp cho chú nhiều dưỡng chất đủ để leo lên nhánh thấp nhất của cái cây đấy. Ngày tiếp theo, sau khi thưởng thức thêm phân bò, gà tây leo lên được nhánh thứ 2. Cuối cùng sau bốn đêm leo trèo, gà tây đã chễm chệ ngồi trên ngọn cây cao nhất. Tuy nhiên chưa tận hưởng được niềm vui chiến thắng bao lâu, gà tây đã bị bắn chết bởi người nông dân khi ông phát hiện ra nó lấp ló ở ngọn cây.','About','','inherit','closed','closed','','28-revision-v1','','','2022-08-28 08:43:52','2022-08-28 08:43:52','',28,'http://lamminhthien.local/?p=137',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (138,1,'2022-08-28 08:58:43','2022-08-28 08:58:43','Một con gà tây tán gẫu với con bò: “Mình cực kì yêu thích leo lên ngọn của cái cây kia, nhưng lại không có đủ sức (gà tây thở dài).\r\n\r\nCon bò góp ý: “Vậy bạn thử ăn chất thải của mình coi sao? Chúng chứa rất nhiều dưỡng chất đấy!”.\r\n\r\nGà tây gặm một miếng phân bò và đúng thật là nó cung cấp cho chú nhiều dưỡng chất đủ để leo lên nhánh thấp nhất của cái cây đấy. Ngày tiếp theo, sau khi thưởng thức thêm phân bò, gà tây leo lên được nhánh thứ 2. Cuối cùng sau bốn đêm leo trèo, gà tây đã chễm chệ ngồi trên ngọn cây cao nhất. Tuy nhiên chưa tận hưởng được niềm vui chiến thắng bao lâu, gà tây đã bị bắn chết bởi người nông dân khi ông phát hiện ra nó lấp ló ở ngọn cây.','About','','inherit','closed','closed','','28-revision-v1','','','2022-08-28 08:58:43','2022-08-28 08:58:43','',28,'http://lamminhthien.local/?p=138',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (139,1,'2022-08-28 09:15:46','2022-08-28 09:15:46','Một con gà tây tán gẫu với con bò: “Mình cực kì yêu thích leo lên ngọn của cái cây kia, nhưng lại không có đủ sức (gà tây thở dài).\r\n\r\nCon bò góp ý: “Vậy bạn thử ăn chất thải của mình coi sao? Chúng chứa rất nhiều dưỡng chất đấy!”.\r\n\r\nGà tây gặm một miếng phân bò và đúng thật là nó cung cấp cho chú nhiều dưỡng chất đủ để leo lên nhánh thấp nhất của cái cây đấy. Ngày tiếp theo, sau khi thưởng thức thêm phân bò, gà tây leo lên được nhánh thứ 2. Cuối cùng sau bốn đêm leo trèo, gà tây đã chễm chệ ngồi trên ngọn cây cao nhất. Tuy nhiên chưa tận hưởng được niềm vui chiến thắng bao lâu, gà tây đã bị bắn chết bởi người nông dân khi ông phát hiện ra nó lấp ló ở ngọn cây.','About','','inherit','closed','closed','','28-revision-v1','','','2022-08-28 09:15:46','2022-08-28 09:15:46','',28,'http://lamminhthien.local/?p=139',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (140,1,'2022-08-28 09:23:15','2022-08-28 09:23:15','a:11:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"parent_layout\";s:20:\"layout_630b338ac7a8d\";s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}','Title','title','publish','closed','closed','','field_630b33abc7a8e','','','2022-08-28 09:23:15','2022-08-28 09:23:15','',106,'http://lamminhthien.local/?post_type=acf-field&p=140',0,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (141,1,'2022-08-28 09:23:15','2022-08-28 09:23:15','a:11:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"parent_layout\";s:20:\"layout_630b338ac7a8d\";s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}','Headline','headline','publish','closed','closed','','field_630b33bdc7a8f','','','2022-08-28 09:23:15','2022-08-28 09:23:15','',106,'http://lamminhthien.local/?post_type=acf-field&p=141',1,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (142,1,'2022-08-28 09:23:15','2022-08-28 09:23:15','a:8:{s:4:\"type\";s:3:\"url\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"parent_layout\";s:20:\"layout_630b338ac7a8d\";s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";}','Link','link','publish','closed','closed','','field_630b33efc7a90','','','2022-08-28 09:42:32','2022-08-28 09:42:32','',106,'http://lamminhthien.local/?post_type=acf-field&#038;p=142',2,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (143,1,'2022-08-28 09:24:49','2022-08-28 09:24:49','Một con gà tây tán gẫu với con bò: “Mình cực kì yêu thích leo lên ngọn của cái cây kia, nhưng lại không có đủ sức (gà tây thở dài).\r\n\r\nCon bò góp ý: “Vậy bạn thử ăn chất thải của mình coi sao? Chúng chứa rất nhiều dưỡng chất đấy!”.\r\n\r\nGà tây gặm một miếng phân bò và đúng thật là nó cung cấp cho chú nhiều dưỡng chất đủ để leo lên nhánh thấp nhất của cái cây đấy. Ngày tiếp theo, sau khi thưởng thức thêm phân bò, gà tây leo lên được nhánh thứ 2. Cuối cùng sau bốn đêm leo trèo, gà tây đã chễm chệ ngồi trên ngọn cây cao nhất. Tuy nhiên chưa tận hưởng được niềm vui chiến thắng bao lâu, gà tây đã bị bắn chết bởi người nông dân khi ông phát hiện ra nó lấp ló ở ngọn cây.','About','','inherit','closed','closed','','28-revision-v1','','','2022-08-28 09:24:49','2022-08-28 09:24:49','',28,'http://lamminhthien.local/?p=143',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (144,1,'2022-08-28 09:34:33','2022-08-28 09:34:33','a:16:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"parent_layout\";s:20:\"layout_630b338ac7a8d\";s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:6:\"medium\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}','Logo','logo','publish','closed','closed','','field_630b369948254','','','2022-08-28 09:34:33','2022-08-28 09:34:33','',106,'http://lamminhthien.local/?post_type=acf-field&p=144',3,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (145,1,'2022-08-28 09:36:18','2022-08-28 09:36:18','','btn-discover-who-we-serve','','inherit','open','closed','','btn-discover-who-we-serve','','','2022-08-28 09:36:18','2022-08-28 09:36:18','',28,'http://lamminhthien.local/wp-content/uploads/2022/08/btn-discover-who-we-serve.svg',0,'attachment','image/svg+xml',0);
INSERT INTO `wp_posts` VALUES (146,1,'2022-08-28 09:36:27','2022-08-28 09:36:27','Một con gà tây tán gẫu với con bò: “Mình cực kì yêu thích leo lên ngọn của cái cây kia, nhưng lại không có đủ sức (gà tây thở dài).\r\n\r\nCon bò góp ý: “Vậy bạn thử ăn chất thải của mình coi sao? Chúng chứa rất nhiều dưỡng chất đấy!”.\r\n\r\nGà tây gặm một miếng phân bò và đúng thật là nó cung cấp cho chú nhiều dưỡng chất đủ để leo lên nhánh thấp nhất của cái cây đấy. Ngày tiếp theo, sau khi thưởng thức thêm phân bò, gà tây leo lên được nhánh thứ 2. Cuối cùng sau bốn đêm leo trèo, gà tây đã chễm chệ ngồi trên ngọn cây cao nhất. Tuy nhiên chưa tận hưởng được niềm vui chiến thắng bao lâu, gà tây đã bị bắn chết bởi người nông dân khi ông phát hiện ra nó lấp ló ở ngọn cây.','About','','inherit','closed','closed','','28-revision-v1','','','2022-08-28 09:36:27','2022-08-28 09:36:27','',28,'http://lamminhthien.local/?p=146',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (147,1,'2022-08-28 09:42:32','2022-08-28 09:42:32','a:11:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"parent_layout\";s:20:\"layout_630b338ac7a8d\";s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}','Link Title','link_title','publish','closed','closed','','field_630b3872d34f9','','','2022-08-28 09:42:32','2022-08-28 09:42:32','',106,'http://lamminhthien.local/?post_type=acf-field&p=147',4,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (148,1,'2022-08-28 09:43:22','2022-08-28 09:43:22','Một con gà tây tán gẫu với con bò: “Mình cực kì yêu thích leo lên ngọn của cái cây kia, nhưng lại không có đủ sức (gà tây thở dài).\r\n\r\nCon bò góp ý: “Vậy bạn thử ăn chất thải của mình coi sao? Chúng chứa rất nhiều dưỡng chất đấy!”.\r\n\r\nGà tây gặm một miếng phân bò và đúng thật là nó cung cấp cho chú nhiều dưỡng chất đủ để leo lên nhánh thấp nhất của cái cây đấy. Ngày tiếp theo, sau khi thưởng thức thêm phân bò, gà tây leo lên được nhánh thứ 2. Cuối cùng sau bốn đêm leo trèo, gà tây đã chễm chệ ngồi trên ngọn cây cao nhất. Tuy nhiên chưa tận hưởng được niềm vui chiến thắng bao lâu, gà tây đã bị bắn chết bởi người nông dân khi ông phát hiện ra nó lấp ló ở ngọn cây.','About','','inherit','closed','closed','','28-revision-v1','','','2022-08-28 09:43:22','2022-08-28 09:43:22','',28,'http://lamminhthien.local/?p=148',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (149,1,'2022-08-28 09:46:27','2022-08-28 09:46:27','Một con gà tây tán gẫu với con bò: “Mình cực kì yêu thích leo lên ngọn của cái cây kia, nhưng lại không có đủ sức (gà tây thở dài).\r\n\r\nCon bò góp ý: “Vậy bạn thử ăn chất thải của mình coi sao? Chúng chứa rất nhiều dưỡng chất đấy!”.\r\n\r\nGà tây gặm một miếng phân bò và đúng thật là nó cung cấp cho chú nhiều dưỡng chất đủ để leo lên nhánh thấp nhất của cái cây đấy. Ngày tiếp theo, sau khi thưởng thức thêm phân bò, gà tây leo lên được nhánh thứ 2. Cuối cùng sau bốn đêm leo trèo, gà tây đã chễm chệ ngồi trên ngọn cây cao nhất. Tuy nhiên chưa tận hưởng được niềm vui chiến thắng bao lâu, gà tây đã bị bắn chết bởi người nông dân khi ông phát hiện ra nó lấp ló ở ngọn cây.','About','','inherit','closed','closed','','28-revision-v1','','','2022-08-28 09:46:27','2022-08-28 09:46:27','',28,'http://lamminhthien.local/?p=149',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (150,1,'2022-08-28 09:50:07','2022-08-28 09:50:07','a:11:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"parent_layout\";s:20:\"layout_630b399a2a1e1\";s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}','Title','title','publish','closed','closed','','field_630b39b92a1e2','','','2022-08-28 09:50:07','2022-08-28 09:50:07','',106,'http://lamminhthien.local/?post_type=acf-field&p=150',0,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (151,1,'2022-08-28 09:50:07','2022-08-28 09:50:07','a:11:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"parent_layout\";s:20:\"layout_630b399a2a1e1\";s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}','Headline','headline','publish','closed','closed','','field_630b3a0e2a1e3','','','2022-08-28 09:50:07','2022-08-28 09:50:07','',106,'http://lamminhthien.local/?post_type=acf-field&p=151',1,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (152,1,'2022-08-28 09:50:07','2022-08-28 09:50:07','a:16:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"parent_layout\";s:20:\"layout_630b399a2a1e1\";s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:6:\"medium\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}','Logo','logo','publish','closed','closed','','field_630b3a202a1e4','','','2022-08-28 09:50:07','2022-08-28 09:50:07','',106,'http://lamminhthien.local/?post_type=acf-field&p=152',2,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (153,1,'2022-08-28 09:50:07','2022-08-28 09:50:07','a:8:{s:4:\"type\";s:3:\"url\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"parent_layout\";s:20:\"layout_630b399a2a1e1\";s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";}','Link','link','publish','closed','closed','','field_630b3a302a1e5','','','2022-08-28 09:50:07','2022-08-28 09:50:07','',106,'http://lamminhthien.local/?post_type=acf-field&p=153',3,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (154,1,'2022-08-28 09:50:07','2022-08-28 09:50:07','a:11:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"parent_layout\";s:20:\"layout_630b399a2a1e1\";s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}','Link Title','link_title','publish','closed','closed','','field_630b3a3b2a1e6','','','2022-08-28 09:50:07','2022-08-28 09:50:07','',106,'http://lamminhthien.local/?post_type=acf-field&p=154',4,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (155,1,'2022-08-28 09:51:02','2022-08-28 09:51:02','','work-with-us','','inherit','open','closed','','work-with-us','','','2022-08-28 09:51:02','2022-08-28 09:51:02','',28,'http://lamminhthien.local/wp-content/uploads/2022/08/work-with-us.png',0,'attachment','image/png',0);
INSERT INTO `wp_posts` VALUES (156,1,'2022-08-28 09:51:55','2022-08-28 09:51:55','Một con gà tây tán gẫu với con bò: “Mình cực kì yêu thích leo lên ngọn của cái cây kia, nhưng lại không có đủ sức (gà tây thở dài).\r\n\r\nCon bò góp ý: “Vậy bạn thử ăn chất thải của mình coi sao? Chúng chứa rất nhiều dưỡng chất đấy!”.\r\n\r\nGà tây gặm một miếng phân bò và đúng thật là nó cung cấp cho chú nhiều dưỡng chất đủ để leo lên nhánh thấp nhất của cái cây đấy. Ngày tiếp theo, sau khi thưởng thức thêm phân bò, gà tây leo lên được nhánh thứ 2. Cuối cùng sau bốn đêm leo trèo, gà tây đã chễm chệ ngồi trên ngọn cây cao nhất. Tuy nhiên chưa tận hưởng được niềm vui chiến thắng bao lâu, gà tây đã bị bắn chết bởi người nông dân khi ông phát hiện ra nó lấp ló ở ngọn cây.','About','','inherit','closed','closed','','28-revision-v1','','','2022-08-28 09:51:55','2022-08-28 09:51:55','',28,'http://lamminhthien.local/?p=156',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (157,1,'2022-08-28 10:10:46','2022-08-28 10:10:46','','Contact','','publish','closed','closed','','contact','','','2022-08-29 06:43:38','2022-08-28 23:43:38','',0,'http://lamminhthien.local/?page_id=157',0,'page','',0);
INSERT INTO `wp_posts` VALUES (158,1,'2022-08-28 10:10:46','2022-08-28 10:10:46','','Contact','','inherit','closed','closed','','157-revision-v1','','','2022-08-28 10:10:46','2022-08-28 10:10:46','',157,'http://lamminhthien.local/?p=158',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (159,1,'2022-08-28 10:13:33','2022-08-28 10:13:33','a:9:{s:4:\"type\";s:16:\"flexible_content\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"layouts\";a:2:{s:20:\"layout_63004af8cb9c1\";a:6:{s:3:\"key\";s:20:\"layout_63004af8cb9c1\";s:5:\"label\";s:6:\"Banner\";s:4:\"name\";s:14:\"contact_banner\";s:7:\"display\";s:5:\"block\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";}s:20:\"layout_630b3f9756f5a\";a:6:{s:3:\"key\";s:20:\"layout_630b3f9756f5a\";s:5:\"label\";s:12:\"Contact Form\";s:4:\"name\";s:12:\"contact_form\";s:7:\"display\";s:5:\"block\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";}}s:12:\"button_label\";s:7:\"Add Row\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";}','Flexible Contact Content','flexible_contact_content','publish','closed','closed','','field_630b3f3756f43','','','2022-08-29 06:41:15','2022-08-28 23:41:15','',105,'http://lamminhthien.local/?post_type=acf-field&#038;p=159',1,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (160,1,'2022-08-28 10:13:33','2022-08-28 10:13:33','a:11:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"parent_layout\";s:20:\"layout_63004af8cb9c1\";s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}','Title','title','publish','closed','closed','','field_630b3f3756f44','','','2022-08-28 10:13:33','2022-08-28 10:13:33','',159,'http://lamminhthien.local/?post_type=acf-field&p=160',0,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (161,1,'2022-08-28 10:13:33','2022-08-28 10:13:33','a:11:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"parent_layout\";s:20:\"layout_63004af8cb9c1\";s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}','Headline','headline','publish','closed','closed','','field_630b3f3756f45','','','2022-08-28 10:13:33','2022-08-28 10:13:33','',159,'http://lamminhthien.local/?post_type=acf-field&p=161',1,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (162,1,'2022-08-28 10:13:33','2022-08-28 10:13:33','a:8:{s:4:\"type\";s:3:\"url\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"parent_layout\";s:20:\"layout_63004af8cb9c1\";s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";}','Link','link','publish','closed','closed','','field_630b3f3756f46','','','2022-08-28 10:13:33','2022-08-28 10:13:33','',159,'http://lamminhthien.local/?post_type=acf-field&p=162',2,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (163,1,'2022-08-28 10:13:33','2022-08-28 10:13:33','a:16:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"parent_layout\";s:20:\"layout_63004af8cb9c1\";s:13:\"return_format\";s:5:\"array\";s:12:\"preview_size\";s:6:\"medium\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}','Logo','logo','publish','closed','closed','','field_630b3f3756f47','','','2022-08-28 10:13:33','2022-08-28 10:13:33','',159,'http://lamminhthien.local/?post_type=acf-field&p=163',3,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (164,1,'2022-08-28 10:13:33','2022-08-28 10:13:33','a:6:{s:4:\"type\";s:7:\"acf_cf7\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"parent_layout\";s:20:\"layout_630b3f9756f5a\";}','Form','form','publish','closed','closed','','field_630b3f9e56f5b','','','2022-08-28 10:21:17','2022-08-28 10:21:17','',159,'http://lamminhthien.local/?post_type=acf-field&#038;p=164',0,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (165,1,'2022-08-28 10:13:40','0000-00-00 00:00:00','','Auto Draft','','auto-draft','closed','closed','','','','','2022-08-28 10:13:40','0000-00-00 00:00:00','',0,'http://lamminhthien.local/?page_id=165',0,'page','',0);
INSERT INTO `wp_posts` VALUES (166,1,'2022-08-28 10:13:40','0000-00-00 00:00:00','','Auto Draft','','auto-draft','closed','closed','','','','','2022-08-28 10:13:40','0000-00-00 00:00:00','',0,'http://lamminhthien.local/?page_id=166',0,'page','',0);
INSERT INTO `wp_posts` VALUES (167,1,'2022-08-28 10:14:13','0000-00-00 00:00:00','','Auto Draft','','auto-draft','closed','closed','','','','','2022-08-28 10:14:13','0000-00-00 00:00:00','',0,'http://lamminhthien.local/?post_type=acf-field-group&p=167',0,'acf-field-group','',0);
INSERT INTO `wp_posts` VALUES (168,1,'2022-08-28 10:14:37','2022-08-28 10:14:37','<label> Your name\n    [text* your-name] </label>\n\n<label> Your email\n    [email* your-email] </label>\n\n<label> Subject\n    [text* your-subject] </label>\n\n<label> Your message (optional)\n    [textarea your-message] </label>\n\n[submit \"Submit\"]\n[_site_title] \"[your-subject]\"\n[_site_title] <wordpress@phamthiutlinhcom.local>\nFrom: [your-name] <[your-email]>\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on [_site_title] ([_site_url])\n[_site_admin_email]\nReply-To: [your-email]\n\n0\n0\n\n[_site_title] \"[your-subject]\"\n[_site_title] <wordpress@phamthiutlinhcom.local>\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on [_site_title] ([_site_url])\n[your-email]\nReply-To: [_site_admin_email]\n\n0\n0\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nPlease fill out this field.\nThis field has a too long input.\nThis field has a too short input.\nThere was an unknown error uploading the file.\nYou are not allowed to upload files of this type.\nThe uploaded file is too large.\nThere was an error uploading the file.','Contact form 1','','publish','closed','closed','','contact-form-1','','','2022-08-28 10:14:37','2022-08-28 10:14:37','',0,'http://lamminhthien.local/?post_type=wpcf7_contact_form&p=168',0,'wpcf7_contact_form','',0);
INSERT INTO `wp_posts` VALUES (169,1,'2022-08-28 10:16:40','2022-08-28 10:16:40','a:11:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"parent_layout\";s:20:\"layout_630b3f9756f5a\";s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}','','','publish','closed','closed','','field_630b4065a1106','','','2022-08-28 10:16:40','2022-08-28 10:16:40','',159,'http://lamminhthien.local/?post_type=acf-field&p=169',1,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (170,1,'2022-08-28 10:17:03','2022-08-28 10:17:03','','Contact','','inherit','closed','closed','','157-revision-v1','','','2022-08-28 10:17:03','2022-08-28 10:17:03','',157,'http://lamminhthien.local/?p=170',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (171,1,'2022-08-28 10:17:17','2022-08-28 10:17:17','','Contact','','inherit','closed','closed','','157-revision-v1','','','2022-08-28 10:17:17','2022-08-28 10:17:17','',157,'http://lamminhthien.local/?p=171',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (172,1,'2022-08-28 10:22:51','2022-08-28 10:22:51','','Contact','','inherit','closed','closed','','157-revision-v1','','','2022-08-28 10:22:51','2022-08-28 10:22:51','',157,'http://lamminhthien.local/?p=172',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (173,1,'2022-08-28 12:26:11','2022-08-28 12:26:11','a:11:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"parent_layout\";s:20:\"layout_630b5ea41a8fb\";s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}','Title','title','publish','closed','closed','','field_630b5eae1a8fc','','','2022-08-28 12:26:11','2022-08-28 12:26:11','',106,'http://lamminhthien.local/?post_type=acf-field&p=173',0,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (174,1,'2022-08-28 12:26:11','2022-08-28 12:26:11','a:11:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"parent_layout\";s:20:\"layout_630b5ea41a8fb\";s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}','Headline','headline','publish','closed','closed','','field_630b5eb41a8fd','','','2022-08-28 12:26:11','2022-08-28 12:26:11','',106,'http://lamminhthien.local/?post_type=acf-field&p=174',1,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (175,1,'2022-08-28 12:26:11','2022-08-28 12:26:11','a:11:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"parent_layout\";s:20:\"layout_630b5ea41a8fb\";s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:0:\"\";}','Posts','posts','publish','closed','closed','','field_630b5ec01a8fe','','','2022-08-28 12:26:11','2022-08-28 12:26:11','',106,'http://lamminhthien.local/?post_type=acf-field&p=175',2,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (176,1,'2022-08-28 12:26:11','2022-08-28 12:26:11','a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:12:\"preview_size\";s:6:\"medium\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}','Post','post','publish','closed','closed','','field_630b5ec91a8ff','','','2022-08-28 12:26:11','2022-08-28 12:26:11','',175,'http://lamminhthien.local/?post_type=acf-field&p=176',0,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (177,1,'2022-08-28 12:26:44','2022-08-28 12:26:44','','article-banner-3','','inherit','open','closed','','article-banner-3','','','2022-08-28 12:26:44','2022-08-28 12:26:44','',0,'http://lamminhthien.local/wp-content/uploads/2022/08/article-banner-3.png',0,'attachment','image/png',0);
INSERT INTO `wp_posts` VALUES (178,1,'2022-08-28 12:26:45','2022-08-28 12:26:45','','article-banner-4','','inherit','open','closed','','article-banner-4','','','2022-08-28 12:26:45','2022-08-28 12:26:45','',0,'http://lamminhthien.local/wp-content/uploads/2022/08/article-banner-4.png',0,'attachment','image/png',0);
INSERT INTO `wp_posts` VALUES (179,1,'2022-08-28 12:26:45','2022-08-28 12:26:45','','article-banner-5','','inherit','open','closed','','article-banner-5','','','2022-08-28 12:26:45','2022-08-28 12:26:45','',0,'http://lamminhthien.local/wp-content/uploads/2022/08/article-banner-5.png',0,'attachment','image/png',0);
INSERT INTO `wp_posts` VALUES (180,1,'2022-08-28 12:26:47','2022-08-28 12:26:47','','article-detail','','inherit','open','closed','','article-detail','','','2022-08-28 12:26:47','2022-08-28 12:26:47','',0,'http://lamminhthien.local/wp-content/uploads/2022/08/article-detail.jpg',0,'attachment','image/jpeg',0);
INSERT INTO `wp_posts` VALUES (181,1,'2022-08-28 12:26:47','2022-08-28 12:26:47','','article-represent-face','','inherit','open','closed','','article-represent-face','','','2022-08-28 12:26:47','2022-08-28 12:26:47','',0,'http://lamminhthien.local/wp-content/uploads/2022/08/article-represent-face.png',0,'attachment','image/png',0);
INSERT INTO `wp_posts` VALUES (182,1,'2022-08-28 12:26:47','2022-08-28 12:26:47','Proin elementum nisl sem, ut imperdiet urna aliquet nec.','article-banner-1','News // Lorem ipsum','inherit','open','closed','','article-banner-1','','','2022-08-28 12:32:39','2022-08-28 12:32:39','',28,'http://lamminhthien.local/wp-content/uploads/2022/08/article-banner-1.png',0,'attachment','image/png',0);
INSERT INTO `wp_posts` VALUES (183,1,'2022-08-28 12:26:48','2022-08-28 12:26:48','','article-banner-2','','inherit','open','closed','','article-banner-2','','','2022-08-28 12:26:48','2022-08-28 12:26:48','',0,'http://lamminhthien.local/wp-content/uploads/2022/08/article-banner-2.png',0,'attachment','image/png',0);
INSERT INTO `wp_posts` VALUES (184,1,'2022-08-28 12:26:54','2022-08-28 12:26:54','Proin elementum nisl sem, ut imperdiet urna aliquet nec.','detail-banner','News // Lorem ipsum','inherit','open','closed','','detail-banner','','','2022-08-28 12:37:44','2022-08-28 12:37:44','',28,'http://lamminhthien.local/wp-content/uploads/2022/08/detail-banner.jpg',0,'attachment','image/jpeg',0);
INSERT INTO `wp_posts` VALUES (185,1,'2022-08-28 12:26:56','2022-08-28 12:26:56','','contact-banner','','inherit','open','closed','','contact-banner','','','2022-08-28 12:26:56','2022-08-28 12:26:56','',0,'http://lamminhthien.local/wp-content/uploads/2022/08/contact-banner.jpg',0,'attachment','image/jpeg',0);
INSERT INTO `wp_posts` VALUES (186,1,'2022-08-28 12:26:58','2022-08-28 12:26:58','','footer-logo','','inherit','open','closed','','footer-logo','','','2022-08-28 12:26:58','2022-08-28 12:26:58','',0,'http://lamminhthien.local/wp-content/uploads/2022/08/footer-logo.svg',0,'attachment','image/svg+xml',0);
INSERT INTO `wp_posts` VALUES (187,1,'2022-08-28 12:27:03','2022-08-28 12:27:03','Proin elementum nisl sem, ut imperdiet urna aliquet nec.','article-banner-4','News // Lorem ipsum','inherit','open','closed','','article-banner-4-2','','','2022-08-28 12:32:39','2022-08-28 12:32:39','',28,'http://lamminhthien.local/wp-content/uploads/2022/08/article-banner-4-1.png',0,'attachment','image/png',0);
INSERT INTO `wp_posts` VALUES (188,1,'2022-08-28 12:27:04','2022-08-28 12:27:04','Proin elementum nisl sem, ut imperdiet urna aliquet nec.','article-banner-5','News // Lorem ipsum','inherit','open','closed','','article-banner-5-2','','','2022-08-28 12:32:39','2022-08-28 12:32:39','',28,'http://lamminhthien.local/wp-content/uploads/2022/08/article-banner-5-1.png',0,'attachment','image/png',0);
INSERT INTO `wp_posts` VALUES (189,1,'2022-08-28 12:27:05','2022-08-28 12:27:05','','article-detail','','inherit','open','closed','','article-detail-2','','','2022-08-28 12:27:05','2022-08-28 12:27:05','',0,'http://lamminhthien.local/wp-content/uploads/2022/08/article-detail-1.jpg',0,'attachment','image/jpeg',0);
INSERT INTO `wp_posts` VALUES (190,1,'2022-08-28 12:27:05','2022-08-28 12:27:05','','article-represent-face','','inherit','open','closed','','article-represent-face-2','','','2022-08-28 12:27:05','2022-08-28 12:27:05','',0,'http://lamminhthien.local/wp-content/uploads/2022/08/article-represent-face-1.png',0,'attachment','image/png',0);
INSERT INTO `wp_posts` VALUES (191,1,'2022-08-28 12:27:05','2022-08-28 12:27:05','','banner','','inherit','open','closed','','banner','','','2022-08-29 06:10:02','2022-08-28 23:10:02','',28,'http://lamminhthien.local/wp-content/uploads/2022/08/banner.png',0,'attachment','image/png',0);
INSERT INTO `wp_posts` VALUES (192,1,'2022-08-28 12:27:12','2022-08-28 12:27:12','','bg-who-we-serve','','inherit','open','closed','','bg-who-we-serve','','','2022-08-28 12:27:12','2022-08-28 12:27:12','',0,'http://lamminhthien.local/wp-content/uploads/2022/08/bg-who-we-serve.png',0,'attachment','image/png',0);
INSERT INTO `wp_posts` VALUES (193,1,'2022-08-28 12:27:18','2022-08-28 12:27:18','','btn-discover-who-we-serve','','inherit','open','closed','','btn-discover-who-we-serve-2','','','2022-08-28 12:27:18','2022-08-28 12:27:18','',0,'http://lamminhthien.local/wp-content/uploads/2022/08/btn-discover-who-we-serve-1.svg',0,'attachment','image/svg+xml',0);
INSERT INTO `wp_posts` VALUES (194,1,'2022-08-28 12:27:18','2022-08-28 12:27:18','','company-1','','inherit','open','closed','','company-1-2','','','2022-08-28 12:27:18','2022-08-28 12:27:18','',0,'http://lamminhthien.local/wp-content/uploads/2022/08/company-1-1.svg',0,'attachment','image/svg+xml',0);
INSERT INTO `wp_posts` VALUES (195,1,'2022-08-28 12:27:19','2022-08-28 12:27:19','','company-2','','inherit','open','closed','','company-2-2','','','2022-08-28 12:27:19','2022-08-28 12:27:19','',0,'http://lamminhthien.local/wp-content/uploads/2022/08/company-2-1.svg',0,'attachment','image/svg+xml',0);
INSERT INTO `wp_posts` VALUES (196,1,'2022-08-28 12:27:19','2022-08-28 12:27:19','','company-3','','inherit','open','closed','','company-3-2','','','2022-08-28 12:27:19','2022-08-28 12:27:19','',0,'http://lamminhthien.local/wp-content/uploads/2022/08/company-3-1.svg',0,'attachment','image/svg+xml',0);
INSERT INTO `wp_posts` VALUES (197,1,'2022-08-28 12:27:19','2022-08-28 12:27:19','','company-4','','inherit','open','closed','','company-4-2','','','2022-08-28 12:27:19','2022-08-28 12:27:19','',0,'http://lamminhthien.local/wp-content/uploads/2022/08/company-4-1.svg',0,'attachment','image/svg+xml',0);
INSERT INTO `wp_posts` VALUES (198,1,'2022-08-28 12:27:19','2022-08-28 12:27:19','','company-5','','inherit','open','closed','','company-5-2','','','2022-08-28 12:27:19','2022-08-28 12:27:19','',0,'http://lamminhthien.local/wp-content/uploads/2022/08/company-5-1.svg',0,'attachment','image/svg+xml',0);
INSERT INTO `wp_posts` VALUES (199,1,'2022-08-28 12:27:20','2022-08-28 12:27:20','','company-6','','inherit','open','closed','','company-6-2','','','2022-08-28 12:27:20','2022-08-28 12:27:20','',0,'http://lamminhthien.local/wp-content/uploads/2022/08/company-6-1.svg',0,'attachment','image/svg+xml',0);
INSERT INTO `wp_posts` VALUES (200,1,'2022-08-28 12:27:20','2022-08-28 12:27:20','','contact-banner','','inherit','open','closed','','contact-banner-2','','','2022-08-28 12:27:20','2022-08-28 12:27:20','',0,'http://lamminhthien.local/wp-content/uploads/2022/08/contact-banner-1.jpg',0,'attachment','image/jpeg',0);
INSERT INTO `wp_posts` VALUES (201,1,'2022-08-28 12:27:21','2022-08-28 12:27:21','','contact-email-logo','','inherit','open','closed','','contact-email-logo','','','2022-08-28 12:27:21','2022-08-28 12:27:21','',0,'http://lamminhthien.local/wp-content/uploads/2022/08/contact-email-logo.svg',0,'attachment','image/svg+xml',0);
INSERT INTO `wp_posts` VALUES (202,1,'2022-08-28 12:27:21','2022-08-28 12:27:21','','contact-human-logo','','inherit','open','closed','','contact-human-logo','','','2022-08-28 12:27:21','2022-08-28 12:27:21','',0,'http://lamminhthien.local/wp-content/uploads/2022/08/contact-human-logo.svg',0,'attachment','image/svg+xml',0);
INSERT INTO `wp_posts` VALUES (203,1,'2022-08-28 12:27:21','2022-08-28 12:27:21','','contact-phone-logo','','inherit','open','closed','','contact-phone-logo','','','2022-08-28 12:27:21','2022-08-28 12:27:21','',0,'http://lamminhthien.local/wp-content/uploads/2022/08/contact-phone-logo.svg',0,'attachment','image/svg+xml',0);
INSERT INTO `wp_posts` VALUES (204,1,'2022-08-28 12:27:21','2022-08-28 12:27:21','','detail-banner','','inherit','open','closed','','detail-banner-2','','','2022-08-28 12:27:21','2022-08-28 12:27:21','',0,'http://lamminhthien.local/wp-content/uploads/2022/08/detail-banner-1.jpg',0,'attachment','image/jpeg',0);
INSERT INTO `wp_posts` VALUES (205,1,'2022-08-28 12:27:23','2022-08-28 12:27:23','','footer-logo','','inherit','open','closed','','footer-logo-2','','','2022-08-28 12:27:23','2022-08-28 12:27:23','',0,'http://lamminhthien.local/wp-content/uploads/2022/08/footer-logo-1.svg',0,'attachment','image/svg+xml',0);
INSERT INTO `wp_posts` VALUES (206,1,'2022-08-28 12:27:24','2022-08-28 12:27:24','','icon-arrow-right','','inherit','open','closed','','icon-arrow-right','','','2022-08-28 12:27:24','2022-08-28 12:27:24','',0,'http://lamminhthien.local/wp-content/uploads/2022/08/icon-arrow-right.svg',0,'attachment','image/svg+xml',0);
INSERT INTO `wp_posts` VALUES (207,1,'2022-08-28 12:27:25','2022-08-28 12:27:25','','logo','','inherit','open','closed','','logo','','','2022-08-28 12:27:25','2022-08-28 12:27:25','',0,'http://lamminhthien.local/wp-content/uploads/2022/08/logo.svg',0,'attachment','image/svg+xml',0);
INSERT INTO `wp_posts` VALUES (208,1,'2022-08-28 12:27:26','2022-08-28 12:27:26','','service-1','','inherit','open','closed','','service-1-2','','','2022-08-28 12:27:26','2022-08-28 12:27:26','',0,'http://lamminhthien.local/wp-content/uploads/2022/08/service-1-1.svg',0,'attachment','image/svg+xml',0);
INSERT INTO `wp_posts` VALUES (209,1,'2022-08-28 12:27:27','2022-08-28 12:27:27','','service-2','','inherit','open','closed','','service-2-2','','','2022-08-28 12:27:27','2022-08-28 12:27:27','',0,'http://lamminhthien.local/wp-content/uploads/2022/08/service-2-1.svg',0,'attachment','image/svg+xml',0);
INSERT INTO `wp_posts` VALUES (210,1,'2022-08-28 12:27:28','2022-08-28 12:27:28','','service-3','','inherit','open','closed','','service-3-2','','','2022-08-28 12:27:28','2022-08-28 12:27:28','',0,'http://lamminhthien.local/wp-content/uploads/2022/08/service-3-1.svg',0,'attachment','image/svg+xml',0);
INSERT INTO `wp_posts` VALUES (211,1,'2022-08-28 12:27:29','2022-08-28 12:27:29','','service-4','','inherit','open','closed','','service-4-2','','','2022-08-28 12:27:29','2022-08-28 12:27:29','',0,'http://lamminhthien.local/wp-content/uploads/2022/08/service-4-1.svg',0,'attachment','image/svg+xml',0);
INSERT INTO `wp_posts` VALUES (212,1,'2022-08-28 12:27:30','2022-08-28 12:27:30','','services-logo','','inherit','open','closed','','services-logo','','','2022-08-28 12:27:30','2022-08-28 12:27:30','',0,'http://lamminhthien.local/wp-content/uploads/2022/08/services-logo.svg',0,'attachment','image/svg+xml',0);
INSERT INTO `wp_posts` VALUES (213,1,'2022-08-28 12:27:31','2022-08-28 12:27:31','','work-with-us','','inherit','open','closed','','work-with-us-2','','','2022-08-28 12:27:31','2022-08-28 12:27:31','',0,'http://lamminhthien.local/wp-content/uploads/2022/08/work-with-us-1.png',0,'attachment','image/png',0);
INSERT INTO `wp_posts` VALUES (214,1,'2022-08-28 12:27:32','2022-08-28 12:27:32','','article-banner-1','','inherit','open','closed','','article-banner-1-2','','','2022-08-28 12:27:32','2022-08-28 12:27:32','',0,'http://lamminhthien.local/wp-content/uploads/2022/08/article-banner-1-1.png',0,'attachment','image/png',0);
INSERT INTO `wp_posts` VALUES (215,1,'2022-08-28 12:27:34','2022-08-28 12:27:34','Proin elementum nisl sem, ut imperdiet urna aliquet nec.','article-banner-2','News // Lorem ipsum','inherit','open','closed','','article-banner-2-2','','','2022-08-28 12:32:39','2022-08-28 12:32:39','',28,'http://lamminhthien.local/wp-content/uploads/2022/08/article-banner-2-1.png',0,'attachment','image/png',0);
INSERT INTO `wp_posts` VALUES (216,1,'2022-08-28 12:27:35','2022-08-28 12:27:35','Proin elementum nisl sem, ut imperdiet urna aliquet nec.','article-banner-3','News // Lorem ipsum','inherit','open','closed','','article-banner-3-2','','','2022-08-28 12:32:39','2022-08-28 12:32:39','',28,'http://lamminhthien.local/wp-content/uploads/2022/08/article-banner-3-1.png',0,'attachment','image/png',0);
INSERT INTO `wp_posts` VALUES (217,1,'2022-08-28 12:32:38','2022-08-28 12:32:38','Một con gà tây tán gẫu với con bò: “Mình cực kì yêu thích leo lên ngọn của cái cây kia, nhưng lại không có đủ sức (gà tây thở dài).\r\n\r\nCon bò góp ý: “Vậy bạn thử ăn chất thải của mình coi sao? Chúng chứa rất nhiều dưỡng chất đấy!”.\r\n\r\nGà tây gặm một miếng phân bò và đúng thật là nó cung cấp cho chú nhiều dưỡng chất đủ để leo lên nhánh thấp nhất của cái cây đấy. Ngày tiếp theo, sau khi thưởng thức thêm phân bò, gà tây leo lên được nhánh thứ 2. Cuối cùng sau bốn đêm leo trèo, gà tây đã chễm chệ ngồi trên ngọn cây cao nhất. Tuy nhiên chưa tận hưởng được niềm vui chiến thắng bao lâu, gà tây đã bị bắn chết bởi người nông dân khi ông phát hiện ra nó lấp ló ở ngọn cây.','About','','inherit','closed','closed','','28-revision-v1','','','2022-08-28 12:32:38','2022-08-28 12:32:38','',28,'http://lamminhthien.local/?p=217',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (218,1,'2022-08-28 12:37:44','2022-08-28 12:37:44','Một con gà tây tán gẫu với con bò: “Mình cực kì yêu thích leo lên ngọn của cái cây kia, nhưng lại không có đủ sức (gà tây thở dài).\r\n\r\nCon bò góp ý: “Vậy bạn thử ăn chất thải của mình coi sao? Chúng chứa rất nhiều dưỡng chất đấy!”.\r\n\r\nGà tây gặm một miếng phân bò và đúng thật là nó cung cấp cho chú nhiều dưỡng chất đủ để leo lên nhánh thấp nhất của cái cây đấy. Ngày tiếp theo, sau khi thưởng thức thêm phân bò, gà tây leo lên được nhánh thứ 2. Cuối cùng sau bốn đêm leo trèo, gà tây đã chễm chệ ngồi trên ngọn cây cao nhất. Tuy nhiên chưa tận hưởng được niềm vui chiến thắng bao lâu, gà tây đã bị bắn chết bởi người nông dân khi ông phát hiện ra nó lấp ló ở ngọn cây.','About','','inherit','closed','closed','','28-revision-v1','','','2022-08-28 12:37:44','2022-08-28 12:37:44','',28,'http://lamminhthien.local/?p=218',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (219,1,'2022-08-29 06:08:35','2022-08-28 23:08:35','a:16:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"parent_layout\";s:20:\"layout_63004af8cb9c1\";s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:6:\"medium\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}','Banner','banner','publish','closed','closed','','field_630bf563dbc4e','','','2022-08-29 06:08:35','2022-08-28 23:08:35','',106,'http://lamminhthien.local/?post_type=acf-field&p=219',4,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (220,1,'2022-08-29 06:09:09','2022-08-28 23:09:09','Bob đi ăn uống liên hoan về say khướt. Anh ta về nhà, đập cửa:\r\n\r\n- Ồ, Bob! Anh đã về đấy ư?\r\n\r\n- Ừ, em yêu ạ, anh gặp bạn cũ.\r\n\r\n- Anh nhậu hết lương tháng rồi.\r\n\r\n- À, em có thể hiểu.\r\n\r\n- Xe lại bị giữ...\r\n\r\n- Chuyện đương nhiên mà.\r\n\r\n- Ôi, em đúng là người phụ nữ hiền dịu nhất trần đời. Ừm... Ờ... Hình như cái dây chuyền em đưa hôm qua, anh trót tặng một cô gái.\r\n\r\n- Lạy Chúa, em thật là may mắn!\r\n\r\n- Sao, em định nói là em rất hài lòng ư?\r\n\r\n- Vâng, vì em chỉ là... Hàng xóm của anh. Hãy can đảm lên, chỉ còn vài bước chân nữa thôi. Cầu Chúa phù hộ cho anh!','Not Home','','inherit','closed','closed','','66-revision-v1','','','2022-08-29 06:09:09','2022-08-28 23:09:09','',66,'http://lamminhthien.local/?p=220',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (221,1,'2022-08-29 06:09:28','2022-08-28 23:09:28','','Not Home','','inherit','closed','closed','','66-revision-v1','','','2022-08-29 06:09:28','2022-08-28 23:09:28','',66,'http://lamminhthien.local/?p=221',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (222,1,'2022-08-29 06:09:43','2022-08-28 23:09:43','','Home','','inherit','closed','closed','','28-revision-v1','','','2022-08-29 06:09:43','2022-08-28 23:09:43','',28,'http://lamminhthien.local/?p=222',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (223,1,'2022-08-29 06:10:02','2022-08-28 23:10:02','','Home','','inherit','closed','closed','','28-revision-v1','','','2022-08-29 06:10:02','2022-08-28 23:10:02','',28,'http://lamminhthien.local/?p=223',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (224,1,'2022-08-29 06:13:29','2022-08-28 23:13:29','','contact-banner','','inherit','open','closed','','contact-banner-3','','','2022-08-29 06:13:29','2022-08-28 23:13:29','',157,'http://lamminhthien.local/wp-content/uploads/2022/08/contact-banner-2.jpg',0,'attachment','image/jpeg',0);
INSERT INTO `wp_posts` VALUES (225,1,'2022-08-29 06:13:35','2022-08-28 23:13:35','','Contact','','inherit','closed','closed','','157-revision-v1','','','2022-08-29 06:13:35','2022-08-28 23:13:35','',157,'http://lamminhthien.local/?p=225',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (226,1,'2022-08-29 06:14:28','2022-08-28 23:14:28','','Contact','','inherit','closed','closed','','157-revision-v1','','','2022-08-29 06:14:28','2022-08-28 23:14:28','',157,'http://lamminhthien.local/?p=226',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (227,1,'2022-08-29 06:14:46','2022-08-28 23:14:46','a:16:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"parent_layout\";s:20:\"layout_63004af8cb9c1\";s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:6:\"medium\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}','Banner','banner','publish','closed','closed','','field_630bf6db8861b','','','2022-08-29 06:14:46','2022-08-28 23:14:46','',159,'http://lamminhthien.local/?post_type=acf-field&p=227',4,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (228,1,'2022-08-29 06:14:56','2022-08-28 23:14:56','','Contact','','inherit','closed','closed','','157-revision-v1','','','2022-08-29 06:14:56','2022-08-28 23:14:56','',157,'http://lamminhthien.local/?p=228',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (229,1,'2022-08-29 06:41:53','2022-08-28 23:41:53','','Contact','','inherit','closed','closed','','157-revision-v1','','','2022-08-29 06:41:53','2022-08-28 23:41:53','',157,'http://lamminhthien.local/?p=229',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (230,1,'2022-08-29 06:43:38','2022-08-28 23:43:38','','Contact','','inherit','closed','closed','','157-revision-v1','','','2022-08-29 06:43:38','2022-08-28 23:43:38','',157,'http://lamminhthien.local/?p=230',0,'revision','',0);
/*!40000 ALTER TABLE `wp_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_term_relationships`
--

DROP TABLE IF EXISTS `wp_term_relationships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_term_relationships`
--

LOCK TABLES `wp_term_relationships` WRITE;
/*!40000 ALTER TABLE `wp_term_relationships` DISABLE KEYS */;
INSERT INTO `wp_term_relationships` VALUES (1,1,0);
INSERT INTO `wp_term_relationships` VALUES (6,2,0);
INSERT INTO `wp_term_relationships` VALUES (19,3,0);
INSERT INTO `wp_term_relationships` VALUES (23,4,0);
INSERT INTO `wp_term_relationships` VALUES (43,5,0);
INSERT INTO `wp_term_relationships` VALUES (45,5,0);
INSERT INTO `wp_term_relationships` VALUES (47,5,0);
INSERT INTO `wp_term_relationships` VALUES (49,5,0);
INSERT INTO `wp_term_relationships` VALUES (51,5,0);
INSERT INTO `wp_term_relationships` VALUES (53,5,0);
INSERT INTO `wp_term_relationships` VALUES (55,5,0);
INSERT INTO `wp_term_relationships` VALUES (57,5,0);
INSERT INTO `wp_term_relationships` VALUES (59,6,0);
INSERT INTO `wp_term_relationships` VALUES (88,6,0);
INSERT INTO `wp_term_relationships` VALUES (90,8,0);
INSERT INTO `wp_term_relationships` VALUES (91,8,0);
INSERT INTO `wp_term_relationships` VALUES (92,8,0);
INSERT INTO `wp_term_relationships` VALUES (93,8,0);
/*!40000 ALTER TABLE `wp_term_relationships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_term_taxonomy`
--

DROP TABLE IF EXISTS `wp_term_taxonomy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_term_taxonomy`
--

LOCK TABLES `wp_term_taxonomy` WRITE;
/*!40000 ALTER TABLE `wp_term_taxonomy` DISABLE KEYS */;
INSERT INTO `wp_term_taxonomy` VALUES (1,1,'category','',0,0);
INSERT INTO `wp_term_taxonomy` VALUES (2,2,'wp_theme','',0,1);
INSERT INTO `wp_term_taxonomy` VALUES (3,3,'wp_theme','',0,1);
INSERT INTO `wp_term_taxonomy` VALUES (4,4,'wp_theme','',0,1);
INSERT INTO `wp_term_taxonomy` VALUES (5,5,'category','',0,8);
INSERT INTO `wp_term_taxonomy` VALUES (6,6,'nav_menu','',0,2);
INSERT INTO `wp_term_taxonomy` VALUES (8,8,'nav_menu','',0,4);
/*!40000 ALTER TABLE `wp_term_taxonomy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_termmeta`
--

DROP TABLE IF EXISTS `wp_termmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_termmeta`
--

LOCK TABLES `wp_termmeta` WRITE;
/*!40000 ALTER TABLE `wp_termmeta` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_termmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_terms`
--

DROP TABLE IF EXISTS `wp_terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_terms`
--

LOCK TABLES `wp_terms` WRITE;
/*!40000 ALTER TABLE `wp_terms` DISABLE KEYS */;
INSERT INTO `wp_terms` VALUES (1,'Uncategorized','uncategorized',0);
INSERT INTO `wp_terms` VALUES (2,'twentytwentytwo','twentytwentytwo',0);
INSERT INTO `wp_terms` VALUES (3,'code-theme','code-theme',0);
INSERT INTO `wp_terms` VALUES (4,'abc-demo','abc-demo',0);
INSERT INTO `wp_terms` VALUES (5,'Economy','economy',0);
INSERT INTO `wp_terms` VALUES (6,'Header Menu','header-menu',0);
INSERT INTO `wp_terms` VALUES (8,'Footer Menu','footer-menu',0);
/*!40000 ALTER TABLE `wp_terms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_usermeta`
--

DROP TABLE IF EXISTS `wp_usermeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_usermeta`
--

LOCK TABLES `wp_usermeta` WRITE;
/*!40000 ALTER TABLE `wp_usermeta` DISABLE KEYS */;
INSERT INTO `wp_usermeta` VALUES (1,1,'nickname','phamthiutlinh');
INSERT INTO `wp_usermeta` VALUES (2,1,'first_name','');
INSERT INTO `wp_usermeta` VALUES (3,1,'last_name','');
INSERT INTO `wp_usermeta` VALUES (4,1,'description','');
INSERT INTO `wp_usermeta` VALUES (5,1,'rich_editing','true');
INSERT INTO `wp_usermeta` VALUES (6,1,'syntax_highlighting','true');
INSERT INTO `wp_usermeta` VALUES (7,1,'comment_shortcuts','false');
INSERT INTO `wp_usermeta` VALUES (8,1,'admin_color','fresh');
INSERT INTO `wp_usermeta` VALUES (9,1,'use_ssl','0');
INSERT INTO `wp_usermeta` VALUES (10,1,'show_admin_bar_front','true');
INSERT INTO `wp_usermeta` VALUES (11,1,'locale','');
INSERT INTO `wp_usermeta` VALUES (12,1,'wp_capabilities','a:1:{s:13:\"administrator\";b:1;}');
INSERT INTO `wp_usermeta` VALUES (13,1,'wp_user_level','10');
INSERT INTO `wp_usermeta` VALUES (14,1,'dismissed_wp_pointers','');
INSERT INTO `wp_usermeta` VALUES (15,1,'show_welcome_panel','1');
INSERT INTO `wp_usermeta` VALUES (16,1,'session_tokens','a:4:{s:64:\"1bba9f92793142fa0cfed391c84f960ba1af570857d08d46a88c0692e39fcc89\";a:4:{s:10:\"expiration\";i:1662779843;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:111:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36\";s:5:\"login\";i:1661570243;}s:64:\"5f7095937b82e29094b04fd5ea17d06fbc1e1b975d931453d6ad9859c2feb209\";a:4:{s:10:\"expiration\";i:1662779843;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:111:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36\";s:5:\"login\";i:1661570243;}s:64:\"8bc27cdc8648e525381cfe16d3078254b865fc58c84b74f8221c25ad3c1691f4\";a:4:{s:10:\"expiration\";i:1661862218;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:111:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36\";s:5:\"login\";i:1661689418;}s:64:\"b6690fc2237ea9f5a48c11985757533526bb50de9e9ffdc01e106bdef3609840\";a:4:{s:10:\"expiration\";i:1662900519;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:111:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36\";s:5:\"login\";i:1661690919;}}');
INSERT INTO `wp_usermeta` VALUES (17,1,'wp_dashboard_quick_press_last_post_id','115');
INSERT INTO `wp_usermeta` VALUES (18,1,'wp_user-settings','mfold=o&libraryContent=browse&editor=tinymce&uploader=1&unfold=1');
INSERT INTO `wp_usermeta` VALUES (19,1,'wp_user-settings-time','1661689576');
INSERT INTO `wp_usermeta` VALUES (20,1,'meta-box-order_page','a:3:{s:4:\"side\";s:36:\"submitdiv,pageparentdiv,postimagediv\";s:6:\"normal\";s:70:\"revisionsdiv,postcustom,commentstatusdiv,commentsdiv,slugdiv,authordiv\";s:8:\"advanced\";s:37:\"post-custom-field,post-custom-field-2\";}');
INSERT INTO `wp_usermeta` VALUES (21,1,'screen_layout_page','2');
INSERT INTO `wp_usermeta` VALUES (22,1,'closedpostboxes_page','a:0:{}');
INSERT INTO `wp_usermeta` VALUES (23,1,'metaboxhidden_page','a:6:{i:0;s:12:\"revisionsdiv\";i:1;s:10:\"postcustom\";i:2;s:16:\"commentstatusdiv\";i:3;s:11:\"commentsdiv\";i:4;s:7:\"slugdiv\";i:5;s:9:\"authordiv\";}');
INSERT INTO `wp_usermeta` VALUES (24,1,'managenav-menuscolumnshidden','a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}');
INSERT INTO `wp_usermeta` VALUES (25,1,'metaboxhidden_nav-menus','a:1:{i:0;s:12:\"add-post_tag\";}');
INSERT INTO `wp_usermeta` VALUES (26,1,'nav_menu_recently_edited','6');
/*!40000 ALTER TABLE `wp_usermeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_users`
--

DROP TABLE IF EXISTS `wp_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_users`
--

LOCK TABLES `wp_users` WRITE;
/*!40000 ALTER TABLE `wp_users` DISABLE KEYS */;
INSERT INTO `wp_users` VALUES (1,'lamminhthien','$P$BSKfWiB5DwPZS2pDT51nr7RysPUYRN1','phamthiutlinh','lamminhthien02012000@gmail.com','http://lamminhthien.local','2022-07-29 15:14:18','',0,'lamminhthien');
/*!40000 ALTER TABLE `wp_users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-29  6:44:53
